#include "stdafx.h"

#include "raw_grayscale_image.h"
#include "int_types.h"

using namespace boost::gil;
using namespace boost::filesystem;

RawGrayscaleImage::RawGrayscaleImage(const path& jpeg_path) {
  rgb8_image_t img;
  jpeg_read_image(jpeg_path.string(), img);
  grayscale_image = new gray8_image_t(img.dimensions());
  copy_pixels(color_converted_view<gray8_pixel_t>(const_view(img)), view(*grayscale_image));
  pixels = interleaved_view_get_raw_data(view(*grayscale_image));
  //pixels = interleaved_view_get_raw_data(view(img));
  //pixels = reinterpret_cast<u8*>(&view(grayscale_image)[0]);
  w = static_cast<u32>(img.dimensions().x);
  h = static_cast<u32>(img.dimensions().y);
}

RawGrayscaleImage::~RawGrayscaleImage() {
  delete grayscale_image;
}
