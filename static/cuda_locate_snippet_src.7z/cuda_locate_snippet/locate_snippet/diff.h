#pragma once

// Store the result of a comparison between a big and a small image.
struct diff {
  u32 x;
  u32 y;
  u32 delta;
};
