#include "diff.h"

diff find_smallest_diff(u8* big, u32 big_w, u32 big_h, u8* small, u32 small_w, u32 small_h);
