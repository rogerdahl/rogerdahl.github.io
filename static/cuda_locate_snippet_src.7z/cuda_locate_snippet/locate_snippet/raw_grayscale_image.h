#include "stdafx.h"

class RawGrayscaleImage {
public:
  RawGrayscaleImage(const boost::filesystem::path& jpeg_path);
  ~RawGrayscaleImage();
  u32 w;
  u32 h;
  u8* pixels;
private:
  boost::gil::gray8_image_t* grayscale_image;
};
