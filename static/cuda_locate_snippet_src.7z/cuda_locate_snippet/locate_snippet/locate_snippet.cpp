#include "stdafx.h"

#include "kernels.h"
#include "diff.h"
#include "raw_grayscale_image.h"

using namespace std;

using namespace boost;
using namespace boost::gil;
using namespace boost::filesystem;

const path images_full_jpeg("pix\\full");
const path images_snippets_jpeg("pix\\snippets");
const path images_tagged_jpeg("pix\\tagged");

struct raw_grayscale_image {
  u8* pixels;
  u32 w;
  u32 h;
};

void draw_box(rgb8_view_t& v, u32 x1, u32 y1, u32 x2, u32 y2, rgb8_pixel_t& color) {
  for (u32 x(x1); x <= x2; ++x) {
    v(x, y1) = color;
    v(x, y2) = color;
  }
  for (u32 y(y1); y <= y2; ++y) {
    v(x1, y) = color;
    v(x2, y) = color;
  }
}

void draw_box_on_jpeg(const path& jpeg_in, const path& jpeg_out, u32 x1, u32 y1, u32 x2, u32 y2) {
  rgb8_image_t img;
  jpeg_read_image(jpeg_in.string(), img);
  rgb8_view_t v = view(img);
  draw_box(v, x1, y1, x2, y2, rgb8_pixel_t(255, 255, 255));
  draw_box(v, x1 + 1, y1 + 1, x2 - 1, y2 - 1, rgb8_pixel_t(0, 0, 0));
  jpeg_write_view(jpeg_out.string(), v, 90);
}

void process_single_image(const path& jpeg_big, const path& jpeg_small, const path& jpeg_write) {
  RawGrayscaleImage big(jpeg_big);
  RawGrayscaleImage small(jpeg_small);
  diff d = find_smallest_diff(big.pixels, big.w, big.h, small.pixels, small.w, small.h);
  cout << format("lowest delta(%1%) at(%2%, %3%)") % d.delta % d.x % d.y << endl;
  draw_box_on_jpeg(jpeg_big, jpeg_write, d.x, d.y, d.x + small.w, d.y + small.h);
}

void process_all_images() {
  for (directory_iterator jpeg_big_iter(images_full_jpeg); jpeg_big_iter != directory_iterator(); ++jpeg_big_iter) {
    if (!is_regular_file(*jpeg_big_iter)) {
      continue;
    }
    path jpeg_small(images_snippets_jpeg / jpeg_big_iter->path().filename());
    path jpeg_write(images_tagged_jpeg / jpeg_big_iter->path().filename());

    cout << jpeg_big_iter->path().string() << endl;

    try {
      process_single_image(*jpeg_big_iter, jpeg_small, jpeg_write);
    }
    catch(std::exception const& e) {
      std::cout << "Error: " << e.what() << std::endl; 
    }
    catch(...) {
      std::cout << "Error: Unknown exception" << std::endl; 
    }
  }
}

int main() {
  process_all_images();
  return 0;
}
