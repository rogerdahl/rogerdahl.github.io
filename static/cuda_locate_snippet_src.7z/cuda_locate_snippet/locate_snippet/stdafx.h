#pragma once

#include "targetver.h"

// App.
#include "int_types.h"

// STL.
#include <algorithm>
#include <fstream>
#include <iostream>

// Boost.
#include <boost/mpl/vector.hpp>
#include <boost/gil/image.hpp>
#include <boost/gil/typedefs.hpp>
#include <boost/gil/color_convert.hpp>
#include <boost/gil/extension/io/jpeg_io.hpp>
#include <boost/gil/extension/io/jpeg_dynamic_io.hpp>
#include <boost/filesystem/path.hpp>
#include <boost/filesystem/convenience.hpp>
#include <boost/program_options.hpp>
#include <boost/format.hpp>