Usage and additional information:

http://rd.gnus.org/software/overcomplete_wavelet/


Requirements:

- A 64 bit version of Windows.
- A CUDA compatible graphics card.


Install:

This app does not come with an installer.

- Move this folder to somewhere convenient such as the Desktop
- Run the .exe file

If an error message such as, "This application has failed to start 
because MSVCRxxx.dll was not found. Re-installing the application may 
fix this problem.", is issued, download and install the Visual C++ 
runtime libraries: 

- Download and run: http://dahlsys.com/vcredist_x64.exe
- Follow the prompts
- Retry the .exe file
