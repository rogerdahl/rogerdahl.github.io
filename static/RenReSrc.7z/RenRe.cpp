// Batch renaming of files and folders using regular expressions.
//
// The program accepts an arbitrary number of folders that can be searched
// recursively or non recursively, as specified by the user. The folders are
// processed in a "depth first" order that enables folders to be renamed without
// breaking the paths to folders that may get renamed later. Files in folders
// can also be renamed.
//
// The program does not check if the same folder or set of folders is specified
// more than once, directly or indirectly. Specifying the same	set of folders
// more than once would cause the program to attempt to process the folders more
// than once. The results would depend on if the paths still exist (after
// folders got renamed)	and what the filenames were, but the results would
// probably be confusing.
//
// The program creates a list of files and folders first and does the renaming
// second. This is because it's not safe to rename items as they are being found
// and iterated through, but it can cause the program to use much more memory
// than might be expected when processing a big folder tree.
//
// An optimization may be split the job up so that the list of items to process
// only contains the files and folders in a single folder.

#include "stdafx.h"

using namespace std;
using namespace boost;
namespace fs = boost::filesystem;
namespace po = boost::program_options;

#ifdef _WIN32
  typedef fs::wpath path_t;
  typedef wregex regex_t;
  typedef wstring string_t;
  #define tvalue po::wvalue
  #define tcout wcout
  #define tcerr wcerr
  #define tcin wcin
#else:
  typedef fs::path path_t;
  typedef regex regex_t;
  typedef string string_t;
  typedef cout tcout;
  #define tvalue po::value
  #define tcout cout
  #define tcerr cerr
  #define tcin cin
#endif

#if defined(_UNICODE)
#define T(x) L ##x
#else
#define T(x) x
#endif


typedef pair<int, path_t> depth_and_path_t;
typedef vector<depth_and_path_t> items_t;

bool depth_compare(depth_and_path_t& a, depth_and_path_t& b) {
  if (a.first != b.first) {
    return a.first > b.first;
  }
  return a.second < b.second;
}

bool rename_items(items_t& items, bool verbose, bool dry_run, bool query, regex_t& search_rx, string_t& replace_fmt) {
	for (items_t::iterator items_iter = items.begin(); items_iter  != items.end(); ++items_iter ) {
    verbose && cout << "Processing item: " << items_iter->second.string() << endl;

		// check if there's a match
		if (!regex_search(items_iter->second.filename().native(), search_rx)) {
			continue;
    }

		// file matched. do regex replace to find new name
		string_t newname(regex_replace(items_iter->second.filename().native(), search_rx, replace_fmt));

		// skip rename if name wouldn't change
		if (newname == items_iter->second.filename()) {
			continue;
    }

		// skip if query is on and user denies
    bool skip(false);
		if (query && !dry_run) {
			for(;;) {
				tcout << items_iter->second.filename().native() << T(" ->\n") << newname << T("\nRename? [Yes, No, Always, Quit]: ") << flush;
				string_t answer;
				tcin >> answer;
				if (answer == T("y") || answer == T("Y")) {
          break;
        }
				if (answer == T("n") || answer == T("N")) {
          skip = true;
          break;
        }
        if (answer == T("a") || answer == T("A")) {
					query = false;
          break;
        }
        if (answer == T("q") || answer == T("Q")) {
					exit(0);
        }
			}
		}

		// do the rename
    if (!skip) {
		  if (!dry_run) {
			  try {
				  fs::rename(items_iter->second, items_iter->second.branch_path() / newname);
			  }
			  catch (const fs::filesystem_error& e) {
				  tcerr << T("Error: Couldn't rename: ") << items_iter->second.native() << endl;
				  tcerr << T("Cause: ") << e.what() << endl;
          continue;
			  }
			  tcout << T("Renamed: ") << items_iter->second.native() << endl;
        tcout << T("->       ") << newname << endl;
		  }
		  else {
			  tcout << T("Dry-run: ") << items_iter->second.native() << endl;
        tcout << T("->       ") << newname << endl;
		  }
    }
	}

	return true;
}

// Find all sub items within a folder.
//
// Because we intend to rename directories and/or files, we create a list of items
// to process and then process them after the folder iteration is completed.
// Renaming directories and/or files as they are being iterated confuses the
// directory_iterator.
bool find_items(const path_t& folder, items_t& items, bool verbose, int depth,
  int depth_limit, bool files_only, bool dirs_only, regex_t& filter_rx) {

  // If there is a limit to how deep we will go, and that limit has been
  // reached, just exit.
	if (depth_limit != -1 && depth > depth_limit) {
		return true;
  }

	if (!is_directory(folder)) {
		tcerr << T("Error: Invalid folder: ") << folder.native() << endl;
		return false;
	}

	try {
		fs::directory_iterator end_itr; // default construction yields past-the-end
		for (fs::directory_iterator itr(folder); itr != end_itr; ++itr ) {
			if (fs::is_directory(itr->status()) && !fs::is_symlink(itr->status())) {
				find_items(itr->path(), items, verbose, depth + 1, depth_limit,
          files_only, dirs_only, filter_rx);
			}
			if (!dirs_only && fs::is_regular(itr->status()) &&
          regex_search(itr->path().native(), filter_rx)) {
				verbose && tcout << T("Found file: ") << itr->path().native() << endl;
				items.push_back(make_pair(depth, itr->path()));
			}
      if (!files_only && fs::is_directory(itr->status()) &&
          regex_search(folder.native(), filter_rx)) {
		    verbose && tcout << T("Found folder: ") << itr->path().native() << endl;
		    items.push_back(make_pair(depth, itr->path()));
	    }
		}
	}
	catch (const fs::filesystem_error& e) {
		tcerr << T("Error: Couldn't open folder: ") << folder.native() << endl;
		tcerr << T("Cause: ") << e.what() << endl;
		return false;
	}
	catch (...) {
		tcerr << T("Error: Couldn't open folder: ") << folder.native() << endl;
		tcerr << T("Cause: Unknown exception") << endl;
		return false;
	}

  return true;
}

int main(int argc, char* argv[]) {
	// program arguments
	vector<string_t> folder_args;
	vector<string_t> rfolder_args;
	string_t search_rx_str;
	string_t filter_rx_str;
	string_t replace_fmt;

	bool dry_run(false);
	bool verbose(false);
	bool files_only(false);
	bool dirs_only(false);
	bool case_sensitive(false);
	bool query(false);

	int depth_limit(-1); // -1 = no limit to depth of recursive search

	// command line arguments
	try {
		po::options_description desc("RenRe - Batch regex renaming of files and folders - dahlsys.com");
		desc.add_options()
			("help", "produce help message")
			// search items
			("folder,f", tvalue<vector<string_t> >(&folder_args), "add search folder")
			("rfolder,r", tvalue<vector<string_t> >(&rfolder_args), "add recursive search folder")
			// regexs and format
			("search,s", tvalue<string_t>(&search_rx_str)->default_value(T(""), ""), "search regex (required)")
			("replace,e", tvalue<string_t>(&replace_fmt)->default_value(T(""), ""), "replace with (back references allowed) (required)")
			("filter,i", tvalue<string_t>(&filter_rx_str)->default_value(T(".*"), ".*"), "file/folder filter regex")
			// flags
			("dry-run,d", po::bool_switch(&dry_run), "don't rename anything -- just simulate")	
			("verbose,v", po::bool_switch(&verbose), "display verbose messages")
			("case-sensitive,c", po::bool_switch(&case_sensitive), "make regexes case sensitive")
			("files-only,z", po::bool_switch(&files_only), "only rename files")
			("folders-only,x", po::bool_switch(&dirs_only), "only rename folders")
			("query,q", po::bool_switch(&query), "ask for confirmation for each rename")
			// limit recursiveness
			("depth,l", tvalue<int>(&depth_limit), "limit depth of recursive search")
			;

		po::positional_options_description p;
		p.add("search", 1);
		p.add("replace", 1);

		po::variables_map vm;
		po::store(po::command_line_parser(argc, argv).options(desc).positional(p).run(), vm);
		po::notify(vm);

		// check arguments and display help and exit if any errors (or help requested)
		bool arg_err(false);
		arg_err |= vm.count("help") > 0;
		//arg_err |= depth_limit == 0;
		arg_err |= search_rx_str == T("");
		arg_err |= replace_fmt == T("");
		arg_err |= dirs_only && files_only;
		if (arg_err) {
			cout << desc;
			tcout << "\nThe search and replace arguments can be given without using\n";
			tcout << "options, as long as they are given in that order." << endl;
			exit(1);
		}
	}
	catch (std::exception& e) {
		tcerr
			<< "Couldn't parse command line arguments" << endl
			<< "Cause: " << e.what () << endl;
		exit (1);
	}
	catch(...) {
		cerr << "Error: Unknown exception" << endl;;
		exit(1);
	}

  // Sometimes, the user wants to replace a string with nothing. One would
  // think that providing an empty format string in quotes would work, but
  // the command line interpreter removes that before it reaches the program.
  // So this allows the user to represent empty with "@@".
	if (replace_fmt == T("@@")) {
    replace_fmt = T("");
  }
	// if no folders were provided, we do the current folder by default
	if (!folder_args.size() && !rfolder_args.size()) {
		folder_args.push_back(T("."));
	}

  // verify that all provided folder names have legal syntax and exist
  vector<string_t>::iterator i;
  try {
    for (i = folder_args.begin(); i != folder_args.end(); ++i)
      if (!fs::exists(*i) || !fs::is_directory(*i))
        throw 0;
		for (i = rfolder_args.begin(); i != rfolder_args.end(); ++i)
      if (!fs::exists(*i) || !fs::is_directory(*i))
        throw 0;
  }
  catch (...) {
    tcerr << "Error: Illegal path: " << endl;
    tcerr << *i << endl;
    exit(1);
  }

	// compile the regexes
	regex_t search_rx;
	regex_t filter_rx;
	boost::regbase::flag_type regex_flags = case_sensitive ?
		boost::regbase::normal :
		boost::regbase::normal | boost::regbase::icase;

	bool rx_error(false);
	try {
		search_rx.assign(search_rx_str, regex_flags);
	}
	catch(...) {
		tcerr << "Error: Regular expression for search is invalid" << endl;
		rx_error = true;
	}
	try {
		filter_rx.assign(filter_rx_str, regex_flags);
	}
	catch(...) {
		tcerr << "Error: Regular expression for file is invalid" << endl;
		rx_error = true;
	}
	if (rx_error) {
		exit(1);
	}

	// find all items, non recursive
	items_t items;
  for (vector<string_t>::iterator i = folder_args.begin(); i != folder_args.end(); ++i) {
    tcout << "Processing non-recursive: " << *i << ":" << endl;
    find_items(path_t(*i), items, verbose, 0, 0, files_only, dirs_only, filter_rx);
	}
	// find all items, recursive
  for (vector<string_t>::iterator i = rfolder_args.begin(); i != rfolder_args.end(); ++i) {
    tcout << "Processing recursive: " << *i << ":" << endl;
    find_items(path_t(*i), items, verbose, 0, depth_limit, files_only, dirs_only, filter_rx);
	}

  // Order the items in such a way that they can be renamed without breaking
  // paths to items that haven not been renamed yet (as long as the user did
	// not specify folders that are subfolders of each other)
  sort(items.begin(), items.end(), depth_compare);

	rename_items(items, verbose, dry_run, query, search_rx, replace_fmt);

  return 0;
}
