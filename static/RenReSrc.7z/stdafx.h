#pragma once
#pragma message("Compiling PCH - Should only happen once per project")

// boost
#include <boost/program_options.hpp>
#include <boost/filesystem.hpp>
#include <boost/regex.hpp>

// std
#include <iostream>
#include <string>
#include <vector>
#include <utility>
