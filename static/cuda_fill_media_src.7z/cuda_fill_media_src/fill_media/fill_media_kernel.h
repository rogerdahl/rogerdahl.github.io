#pragma once

#include "int_types.h"

extern "C" bool run_fit_kernel(u64* item_buf, u64 total_file_cnt, u64 first_medium_size, u64 media_size, bool verbose);
