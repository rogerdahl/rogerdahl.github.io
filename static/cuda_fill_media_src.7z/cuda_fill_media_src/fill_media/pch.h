#pragma once
#pragma message("Compiling PCH - Should only happen once per project")

// Windows.
#include "targetver.h"
#include <windows.h>

// My specific integer types.
#include "int_types.h"

// std.
#include <string>
#include <iostream>
#include <fstream>

// Boost.
#include <boost/format.hpp>
#include <boost/timer.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/program_options.hpp>
#include <boost/filesystem.hpp>
#include <boost/regex.hpp>

// CUDA.
#include <cuda_runtime_api.h>
#include <cutil.h>
