#!/usr/bin/env python
import random
import math
import copy

# Python has a permutation implementation in the itertools stdlib. We implement
# our own since this is a prototype for a cuda implementation.

# s = sequence
# k = 0 < len(s)!
def permutation(s, k):
  for j in range(1, len(s)):
    i = k % (j + 1)
    s[i], s[j] = s[j], s[i]
    k = k / (j + 1)

def check_fit (files, media_size, prnt = False):
  media_cnt = 0
  media_used = 0.0

  for file_size in files:
    if media_used + file_size <= media_size:
      media_used += file_size
    else:
      media_cnt += 1
      media_used = file_size
      if prnt:
        print
  
    if prnt:
      print file_size
      
  return [media_cnt, media_used]

media_size = 2.0
file_cnt = 8

# Create simulated list of files.    
files = []
for i in range (file_cnt):
  # No files can be larger than media_size.
  files.append(random.random())

# Check the fit of all permutations and get k for best permutation.
permutations = math.factorial(len(files))
print 'Checking %d permutations...' % permutations

best_media_cnt = file_cnt
best_media_used = media_size
best_k = 0

for k in range(permutations * 3):
  files_copy = copy.copy(files)
  permutation(files_copy, k)
  [media_cnt, media_used] = check_fit (files_copy, media_size)
  if media_cnt <= best_media_cnt:
    if media_used < best_media_used:
      best_k = k
      best_media_cnt = media_cnt
      best_media_used = media_used
      
# Print the best fit.
files_copy = copy.copy(files)
permutation(files_copy, best_k)
check_fit(files_copy, media_size, True)
