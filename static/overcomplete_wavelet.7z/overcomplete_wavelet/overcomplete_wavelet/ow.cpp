#include <pch.h>

/**
* @todo try to change to int
* @todo try lifting based implementation
* @todo optimize optimize optimize
* @todo hard tresholding
* @todo use QP to decide filter strength
* @todo wavelet normalization / least squares optimal signal vs. noise thresholds
*/

#include <stdio.h>
#include <string.h>
#include <math.h>

const u8 dither[8][8] = {
	{  0,  48,  12,  60,   3,  51,  15,  63, },
	{ 32,  16,  44,  28,  35,  19,  47,  31, },
	{  8,  56,   4,  52,  11,  59,   7,  55, },
	{ 40,  24,  36,  20,  43,  27,  39,  23, },
	{  2,  50,  14,  62,   1,  49,  13,  61, },
	{ 34,  18,  46,  30,  33,  17,  45,  29, },
	{ 10,  58,   6,  54,   9,  57,   5,  53, },
	{ 42,  26,  38,  22,  41,  25,  37,  21, },
};

struct vf_priv_s {
	float luma_strength;
	float chroma_strength;
	int mode;
	int depth;
	float* plane[16][4];
	int stride;
} priv;

#define S 1.41421356237 // sqrt(2)

const double coeff[2][5] = {
	{
		0.6029490182363579 * S, 
			0.2668641184428723 * S, 
			-0.07822326652898785 * S, 
			-0.01686411844287495 * S, 
			0.02674875741080976 * S
	}, 
	{
		1.115087052456994 / S, 
			-0.5912717631142470 / S, 
			-0.05754352622849957 / S, 
			0.09127176311424948 / S
		}
};

const double icoeff[2][5] = {
	{
		1.115087052456994 / S, 
			0.5912717631142470 / S, 
			-0.05754352622849957 / S, 
			-0.09127176311424948 / S
	}, 
	{
		0.6029490182363579 * S, 
			-0.2668641184428723 * S, 
			-0.07822326652898785 * S, 
			0.01686411844287495 * S, 
			0.02674875741080976 * S
		}
};

#undef S

inline int mirror(int x, int w){
	while ((unsigned)x > (unsigned)w) {
		x = -x;
		if (x < 0) {
			x += 2 * w;
		}
	}
	return x;
}

inline void decompose(float *dst_l, float *dst_h, float *src, int stride, int w){
	for(int x (0); x < w; x++) {
		double sum_l (src[x * stride] * coeff[0][0]);
		double sum_h (src[x * stride] * coeff[1][0]);
		for(int i (1); i <= 4; i++){
			double s = (src[mirror(x - i, w - 1) * stride] + src[mirror(x + i, w - 1) * stride]);
			sum_l += coeff[0][i] * s;
			sum_h += coeff[1][i] * s;
		}
		dst_l[x * stride]= sum_l;
		dst_h[x * stride]= sum_h;
	}
}

inline void compose(float *dst, float *src_l, float *src_h, int stride, int w){
	for(int x (0); x < w; x++){
		double sum_l = src_l[x * stride] * icoeff[0][0];
		double sum_h = src_h[x * stride] * icoeff[1][0];
		for(int i (1); i <= 4; i++) {
			int x0 (mirror(x - i, w - 1) * stride);
			int x1 (mirror(x + i, w - 1) * stride);
			sum_l += icoeff[0][i] * (src_l[x0] + src_l[x1]);
			sum_h += icoeff[1][i] * (src_h[x0] + src_h[x1]);
		}
		dst[x * stride] = (sum_l + sum_h) * 0.5;
	}
}

inline void decompose2D(float *dst_l, float *dst_h, float *src, int stride_x, int stride_y, int step, int w, int h){
	int y, x;
	for(y = 0; y < h; y++) {
		for (x = 0; x < step; x++) {
			decompose (
				dst_l + stride_y * y + stride_x * x,
				dst_h + stride_y * y + stride_x * x,
				src + stride_y * y + stride_x * x,
				step * stride_x,
				(w - x + step - 1) / step
			);
		}
	}
}

inline void compose2D(float *dst, float *src_l, float *src_h, int stride_x, int stride_y, int step, int w, int h){
	int y, x;
	for(y=0; y<h; y++)
		for(x=0; x<step; x++)
			compose(dst + stride_y*y + stride_x*x, src_l + stride_y*y + stride_x*x, src_h + stride_y*y + stride_x*x, step*stride_x, (w-x+step-1)/step);
}

void decompose2D2(float *dst[4], float *src, float *temp[2], int stride, int step, int w, int h){
	decompose2D(temp[0], temp[1], src , 1, stride, step , w, h);
	decompose2D( dst[0], dst[1], temp[0], stride, 1, step , h, w);
	decompose2D( dst[2], dst[3], temp[1], stride, 1, step , h, w);
}

void compose2D2(float *dst, float *src[4], float *temp[2], int stride, int step, int w, int h){
	compose2D(temp[0], src[0], src[1], stride, 1, step , h, w);
	compose2D(temp[1], src[2], src[3], stride, 1, step , h, w);
	compose2D(dst , temp[0], temp[1], 1, stride, step , w, h);
}

void filter(u8 *dst, u8 *src, int dst_stride, int src_stride, int width, int height, int is_luma){
	int x, y, i, j;
	// double sum=0;
	double s = is_luma ? priv.luma_strength : priv.chroma_strength;
	int depth = priv.depth;

	// Adjust depth.
	while(1 << depth > width || 1 << depth > height) {
		depth--;
	}

	// Copy image plane (Y, U or V) from src.
	for(y = 0; y < height; y++) {
		for(x = 0; x < width; x++) {
			priv.plane[0][0][x + y * priv.stride] = src[x + y * src_stride];
		}
	}

	// Decompose.
	for(i = 0; i < depth; i++) {
		decompose2D2 (priv.plane[i + 1], priv.plane[i][0], priv.plane[0] + 1, priv.stride, 1 << i, width, height);
	}

	// Gurf.
	for(i = 0; i < depth; i++) {
		for(j = 1; j < 4; j++) {
			for(y = 0; y < height; y++) {
				for(x = 0; x < width; x++) {
					double v = priv.plane[i + 1][j][x + y * priv.stride];
					if (v > s) {
						v -= s;
					}
					else if (v < -s) {
						v += s;
					}
					else {
						v = 0;
					}
					priv.plane[i + 1][j][x + y * priv.stride] = v;
				}
			}
		}
	}

	// Compose.
	for(i = depth - 1; i >= 0; i--) {
		compose2D2 (priv.plane[i][0], priv.plane[i + 1], priv.plane[0] + 1, priv.stride, 1 << i, width, height);
	}

	// Apply dithering to image and copy it to dst.
	for(y = 0; y < height; y++)
		for(x = 0; x < width; x++){
			//yes the rounding is insane but optimal :)
			i = priv.plane[0][0][x + y * priv.stride] + dither[x & 7][y & 7] * (1.0 / 64.0) + 1.0 / 128.0;
			// double e= i - src[x + y*src_stride];
			// sum += e*e;
			if((unsigned)i > 255U) i= ~(i >> 31);
			dst[x + y * dst_stride]= i;
		}

		// printf("%f\n", sum/height/width);
}

void wqinit (int width, int height, int dst_width, int dst_height) {
	memset(&priv, 0, sizeof(priv));

	priv.depth = 8;
	priv.luma_strength = 1.0;
	priv.chroma_strength = 1.0;

	// Round up to number that is divisible by 16.
	int h ((height + 15) & (~15));
	priv.stride = (width + 15) & (~15);

	for(int j(0); j < 4; j++) {
		for(int i(0); i <= priv.depth; i++) {
			priv.plane[i][j] = (float*) malloc (priv.stride * h * sizeof (priv.plane[0][0][0]));
		}
	}
}

void uninit () {
	for(int j (0); j < 4; j++) {
		for(int i(0); i <= priv.depth; i++) {
			free (priv.plane[i][j]);
			priv.plane[i][j] = NULL;
		}
	}
}


//int query_format(struct vf_instance_s* vf, unsigned int fmt){
//	switch(fmt){
//		case IMGFMT_YVU9:
//		case IMGFMT_IF09:
//		case IMGFMT_YV12:
//		case IMGFMT_I420:
//		case IMGFMT_IYUV:
//		case IMGFMT_CLPL:
//		case IMGFMT_Y800:
//		case IMGFMT_Y8:
//		case IMGFMT_444P:
//		case IMGFMT_422P:
//		case IMGFMT_411P:
//			return vf_next_query_format(vf, fmt);
//	}
//	return 0;
//}
//

//void get_image(struct vf_instance_s* vf, mp_image_t *mpi){
//	if(flags&MP_IMGFLAG_PRESERVE) return; // don't change
//	// ok, we can do pp in-place (or pp disabled):
//	dmpi=vf_get_image(next, imgfmt, 
//		type, flags | MP_IMGFLAG_READABLE, width, height);
//	planes[0]=planes[0];
//	stride[0]=stride[0];
//	width=width;
//	if(flags&MP_IMGFLAG_PLANAR){
//		planes[1]=planes[1];
//		planes[2]=planes[2];
//		stride[1]=stride[1];
//		stride[2]=stride[2];
//	}
//	flags|=MP_IMGFLAG_DIRECT;
//}
//
//void filter_image () {
//	filter(planes[0], planes[0], stride[0], stride[0], w, h, 1);
//	filter(planes[1], planes[1], stride[1], stride[1], w, h, 0);
//	filter(planes[2], planes[2], stride[2], stride[2], w, h, 0);
//}
