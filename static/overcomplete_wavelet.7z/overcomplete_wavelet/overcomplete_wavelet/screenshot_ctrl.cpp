#include "pch.h"

#include "screenshot_ctrl.h"
#include "util.h"

using namespace std;
using namespace boost;
using namespace boost::filesystem;

BEGIN_EVENT_TABLE (screenshot_ctrl, wxControl)
EVT_PAINT (screenshot_ctrl::OnPaint)
EVT_SIZE (screenshot_ctrl::OnSize)
EVT_ERASE_BACKGROUND (screenshot_ctrl::OnEraseBackground)
END_EVENT_TABLE ()

IMPLEMENT_DYNAMIC_CLASS (screenshot_ctrl, wxControl)

screenshot_ctrl::screenshot_ctrl () : display_original (false) {
	::wxInitAllImageHandlers ();
}

screenshot_ctrl::~screenshot_ctrl () {
}

bool screenshot_ctrl::Create (wxWindow *parent, wxWindowID id, const wxPoint& pos, const wxSize& size, const wxString& name) {
	if (!wxControl::Create (parent, id, pos, size,
		wxCLIP_CHILDREN | wxWANTS_CHARS,
		wxDefaultValidator, name))
	{
		return false;
	}

	SetBackgroundColour (*wxWHITE);
	SetFont (*wxSWISS_FONT);

	return true;
}

bool screenshot_ctrl::Destroy () {
	return wxControl::Destroy ();
}

void screenshot_ctrl::OnPaint (wxPaintEvent& event) {
	wxPaintDC dc (this);

	dc.SetBackgroundMode (wxTRANSPARENT);
	dc.SetTextForeground (*wxBLACK);

	wxImage* disp_image;
	wstring disp_msg;
	if (!display_original) {
		disp_image = &screenshot_image_original;
		disp_msg = L"<original>";
	}
	else {
		disp_image = &screenshot_image_filtered;
		disp_msg = L"<filtered>";
	}

	dc.Clear ();

	if (disp_image->IsOk ()) {
		wxBitmap bmp = wxBitmap (*disp_image);
		dc.DrawBitmap (bmp, 0, 0, true);
	}

	wxCoord x, y;
	dc.GetTextExtent (disp_msg.c_str(), &x, &y);
	dc.DrawText (disp_msg.c_str(), GetClientSize ().x / 2 - x / 2, GetClientSize ().y - y);
}

void screenshot_ctrl::OnSize (wxSizeEvent& event) {
	Layout ();
}

void screenshot_ctrl::OnEraseBackground (wxEraseEvent& event) {
}

void screenshot_ctrl::set_screenshot_image_original (wpath p) {
	screenshot_image_original.LoadFile (p.file_string());
	Refresh ();
}

void screenshot_ctrl::set_screenshot_image_filtered (wpath p) {
	screenshot_image_filtered.LoadFile (p.file_string());
	Refresh ();
}

void screenshot_ctrl::clear_screenshot_image_filtered () {
	screenshot_image_filtered.SetData (NULL, 0, 0, false);
	Refresh ();
}

void screenshot_ctrl::swap () {
	display_original = !display_original;
	Refresh ();
}

bool screenshot_ctrl::current () {
	return display_original;
}
