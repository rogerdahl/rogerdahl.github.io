// screenshot_ctrl: Render a frame of a screenshot.

#pragma once

#define screenshot_ctrl_string L"screenshot_ctrl"

class screenshot_ctrl : public wxControl {
	void OnPaint (wxPaintEvent& event);
	void OnSize (wxSizeEvent& event);
	void OnEraseBackground (wxEraseEvent& event);

	//std::vector<u8> screenshot_data;

	bool display_original;
	//u32 screenshot_w, screenshot_h;

	DECLARE_DYNAMIC_CLASS (screenshot_ctrl)
	DECLARE_EVENT_TABLE ()

public:
	wxImage screenshot_image_original;
	wxImage screenshot_image_filtered;

	screenshot_ctrl ();

	bool Create (wxWindow *parent,
		wxWindowID id,
		const wxPoint& pos = wxDefaultPosition,
		const wxSize& size = wxDefaultSize,
		const wxString& name = screenshot_ctrl_string);

	virtual ~screenshot_ctrl ();
	virtual bool Destroy ();

	void set_screenshot_image_original (boost::filesystem::wpath);
	void set_screenshot_image_filtered (boost::filesystem::wpath);
	void clear_screenshot_image_filtered ();

	void screenshot_ctrl::swap ();
	bool screenshot_ctrl::current ();
};
