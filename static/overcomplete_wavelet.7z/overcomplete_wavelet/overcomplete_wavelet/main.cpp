#include "pch.h"

#include "screenshot_ctrl.h"
#include "ow.h"

using namespace std;
using namespace boost;
using namespace boost::filesystem;

// Controls.
screenshot_ctrl* screenshot;
wxButton* previous_button;
wxButton* next_button;
wxButton* run_button;
wxButton* swap_button;
wxTextCtrl* mencoder_cmd;
wxTextCtrl* mencoder_res;

// Sizer.
wxSizer* topsizer;


// Define a new application type, each program should derive a class from wxApp
class app : public wxApp {
public:
	// override base class virtuals.
	//
	// This one is called on application startup and is a good place for the app
	// initialization (doing it here and not in the ctor allows to have an error
	// return: if OnInit () returns false, the application terminates).
	int FilterEvent (wxEvent& event);
	virtual bool OnInit ();
};

// Define our main frame.
class main_frame : public wxFrame {
	// Any class wishing to process wxWindows events must use this macro.
	DECLARE_EVENT_TABLE ()

	vector<wpath> images;
	int image_idx;
	wstring old_cmd1;
	int old_pos1;
	wstring old_cmd2;
	int old_pos2;
	void run_filter();

public:
	main_frame (const wxString& title, const wxPoint& pos, const wxSize& size,
		long style = wxDEFAULT_FRAME_STYLE | wxFULL_REPAINT_ON_RESIZE);

	// Event handlers (these functions should _not_ be virtual).
	void OnOpenFolder (wxCommandEvent& event);
	void OnQuit (wxCommandEvent& event);
	void OnAbout (wxCommandEvent& event);

	void OnPreviousButton (wxCommandEvent& event);
	void OnNextButton (wxCommandEvent& event);
	void OnRunButton (wxCommandEvent& event);
	void OnSwapButton(wxCommandEvent& event);
	void OnCmdChange (wxCommandEvent& event);
};

main_frame* frame;

// IDs for the controls and the menu commands.
enum {
	// Menu items.
	preview_quit = 1,
	preview_open_screenshot,
	previous_button_id,
	// Buttons.
	next_button_id,
	run_button_id,
	swap_button_id,
	// Mencoder command and result.
	mencoder_cmd_id,
	mencoder_res_id,
	// It is important for the id corresponding to the "About" command to have
	// this standard value as otherwise it won't be handled properly under Mac
	// (where it is special and put into the "Apple" menu).
	preview_about = wxID_ABOUT
};

// ----------------------------------------------------------------------------
// event tables and other macros for wxWindows
// ----------------------------------------------------------------------------

// the event tables connect the wxWindows events with the functions (event
// handlers) which process them.
BEGIN_EVENT_TABLE (main_frame, wxFrame)
EVT_MENU (preview_open_screenshot, main_frame::OnOpenFolder)
EVT_MENU (preview_quit, main_frame::OnQuit)
EVT_MENU (preview_about, main_frame::OnAbout)

EVT_BUTTON (previous_button_id, main_frame::OnPreviousButton)
EVT_BUTTON (next_button_id, main_frame::OnNextButton)
EVT_BUTTON (run_button_id, main_frame::OnRunButton)
EVT_BUTTON (swap_button_id, main_frame::OnSwapButton)

END_EVENT_TABLE ()

// Create a new application object: this macro will allow wxWindows to create
// the application object during program execution.
IMPLEMENT_APP (app)

inline int mirror(int x, int w){
	while ((unsigned)x > (unsigned)w) {
		x = -x;
		if (x < 0) {
			x += 2 * w;
		}
	}
	return x;
}

int mirror2 (int x, int w) {
	w = _copysign (w, x);
	if (x < 0) w = - abs (w);
	if (x >= 0) w = abs (w);
	x = -x;
	x -= w; 
	return x;
	//if (x <= w) return x;
	//return w + w - x;
}

// Program entrypoint.
bool app::OnInit () {
	// Create and show the main application window.
//	frame = new main_frame (L"Mencoder Video Filter Preview", wxPoint (50, 50), wxSize (640 + 50, 480 + 50));
	frame = new main_frame (L"Mencoder Video Filter Preview", wxPoint (-1, -1), wxSize (-1, -1));
	// Frames, unlike simple controls, are not shown when created initially.
	frame->Show (TRUE);
	// Success: wxApp::OnRunButton () will be called which will enter the main message
	// loop and the application will run. If we returned FALSE here, the
	// application would exit immediately.

	exit (mirror2 (-100, 50));

	for (int i(-100); i < 100; i += 50) {
		::wxLogDebug (L"%d\t%d", i, mirror (i, 50));
		::wxLogDebug (L"%d\t%d", i, mirror2 (i, 50));
		::wxLogDebug (L"-");
	}
	::wxLogDebug (L"----");
	for (int i(-100); i < 100; i += 50) {
		::wxLogDebug (L"%d\t%d", i, mirror (i, -50));
		::wxLogDebug (L"%d\t%d", i, mirror2 (i, -50));
		::wxLogDebug (L"-");
	}
	::wxLogDebug (L"----");
	for (int i(-100); i < 100; i += 50) {
		::wxLogDebug (L"%d\t%d", i, mirror (i, 200));
		::wxLogDebug (L"%d\t%d", i, mirror2 (i, 200));
		::wxLogDebug (L"-");
	}
	::wxLogDebug (L"----");
	for (int i(-100); i < 100; i += 50) {
		::wxLogDebug (L"%d\t%d", i, mirror (i, -200));
		::wxLogDebug (L"%d\t%d", i, mirror2 (i, -200));
		::wxLogDebug (L"-");
	}
	return TRUE;
}

// Set up global accelerators.
int app::FilterEvent (wxEvent& event) {
	if (event.GetEventType() == wxEVT_KEY_DOWN) {
		if (((wxKeyEvent&)event).GetKeyCode() == WXK_PAGEUP) {
			frame->OnPreviousButton ((wxCommandEvent&) event);
			return true;
		}
		if (((wxKeyEvent&)event).GetKeyCode() == WXK_PAGEDOWN) {
			frame->OnNextButton ((wxCommandEvent&) event);
			return true;
		}
		if (((wxKeyEvent&)event).GetKeyCode() == WXK_RETURN) {
			frame->OnRunButton ((wxCommandEvent&) event);
			return true;
		}
		if (((wxKeyEvent&)event).GetKeyCode() == WXK_SPACE) {
			frame->OnSwapButton ((wxCommandEvent&) event);
			return true;
		}
	}
	return -1;
}

// Frame constructor.
main_frame::main_frame (const wxString& title, const wxPoint& pos, const wxSize& size, long style)
: wxFrame (NULL, -1, title, pos, size, style), image_idx (0)
{
	// set the frame icon
	SetIcon (wxICON (mondrian));

	// menu bar
	wxMenu *menuFile = new wxMenu;
	menuFile->Append (preview_open_screenshot, L"Open &Screenshot Folder\tCtrl-O", L"Open a folder with screenshots");
	menuFile->Append (preview_quit, L"E&xit\tAlt-X", L"Quit this program");

	wxMenu *menuHelp = new wxMenu;
	menuHelp->Append (preview_about, L"&About...\tF1", L"Show about dialog");

	wxMenuBar *menuBar = new wxMenuBar ();
	menuBar->Append (menuFile, L"&File");
	menuBar->Append (menuHelp, L"&Help");

	SetMenuBar (menuBar);

	// Create a vertical sizer.
	topsizer = new wxBoxSizer (wxVERTICAL);

	// screenshot_ctrl
	screenshot = new screenshot_ctrl ();
	screenshot->Create (this, -1, wxPoint (0, 200), wxSize (200, 200));
	topsizer->Add (screenshot, 1, wxEXPAND);

	// Previous and Next buttons.
	previous_button = new wxButton (this, previous_button_id, L"&Previous");
	next_button = new wxButton (this, next_button_id, L"&Next");
	run_button = new wxButton (this, run_button_id, L"&Run");
	swap_button = new wxButton (this, swap_button_id, L"&Swap");
	wxBoxSizer* prev_next_button_sizer = new wxBoxSizer (wxHORIZONTAL);
	prev_next_button_sizer->Add (previous_button, 0, wxLEFT | wxRIGHT, 2);
	prev_next_button_sizer->Add (next_button, 0, wxLEFT | wxRIGHT, 2);
	prev_next_button_sizer->Add (run_button, 0, wxLEFT | wxRIGHT, 2);
	prev_next_button_sizer->Add (swap_button, 0, wxLEFT | wxRIGHT, 2);
	topsizer->Add (prev_next_button_sizer, 0, wxEXPAND | wxTOP | wxBOTTOM, 2);

	//
	mencoder_cmd = new wxTextCtrl (this, mencoder_cmd_id, L"", wxPoint (0, 0), wxSize (0, 50));
	topsizer->Add (mencoder_cmd, 0, wxEXPAND | wxTOP | wxBOTTOM, 2);
	mencoder_res = new wxTextCtrl (this, mencoder_res_id, L"", wxPoint (0, 0), wxSize (0, 50), wxTE_MULTILINE);
	topsizer->Add (mencoder_res, 0, wxEXPAND | wxTOP | wxBOTTOM, 2);

	mencoder_cmd->ChangeValue (L"Paste a mencoder command line here from the command.txt file...");
	old_cmd1 = mencoder_cmd->GetValue ();
	old_cmd2 = mencoder_cmd->GetValue ();
	old_pos1 = mencoder_cmd->GetInsertionPoint ();
	old_pos2 = mencoder_cmd->GetInsertionPoint ();

	SetSizer (topsizer);
	// give the sizer a minimal size
	topsizer->SetMinSize (800, 600);
	// Tell the sizer to set (and Fit) the minimal size of the window to match the sizer's minimal size.
	topsizer->SetSizeHints (this);

	SetBackgroundColour(wxColour(wxT("WHITE")));
}


// Event handlers.

void main_frame::OnOpenFolder (wxCommandEvent& event) {
	//wxFileDialog d (this, L"Open screenshot", L"", L"", L"*.*", wxFD_OPEN);
	wxDirDialog d (this, L"Open Screenshot Folder");
	if (d.ShowModal () != wxID_OK) {
		return;
	}
	// Set default path
	SetCurrentDirectory (d.GetPath ());

	// Store a list of all screen shots in folder.
	wregex rx (L"shot\\d+\\..*");
	for (wdirectory_iterator iter(wpath (d.GetPath ())); iter != wdirectory_iterator(); ++iter) {
		if (!regex_match (iter->path().filename(), rx)) {
			continue;
		}
		images.push_back (*iter);
		image_idx = 0;
		//wxMessageBox (iter->path().file_string());
	}

	screenshot->set_screenshot_image_original (images[image_idx]);
	//screenshot->set_screenshot_file ());
	//mandel_pos_slider->ChangeValue (0);
	//// update text boxes
	//mencoder_cmd->ChangeValue (wxString (lexical_cast<wstring> (0).c_str ()));
	//// get palette for new position
	//screenshot->set_color_array (pal->get_color_array (0, 256));
	//screenshot->set_pos (0);
}

void main_frame::OnQuit (wxCommandEvent& WXUNUSED (event)) {
	// TRUE is to force the frame to close
	Close (TRUE);
}

void main_frame::OnAbout (wxCommandEvent& WXUNUSED (event)) {
	wxString msg;
	msg.Printf (L"Mencoder Video Filter Preview - Copyright (C)2009 Roger Dahl\n\n%s", wxVERSION_STRING);
	wxMessageBox (msg, L"About Mencoder Video Filter Preview", wxOK | wxICON_INFORMATION, this);
}

void main_frame::OnPreviousButton (wxCommandEvent& event) {
	if (image_idx > 0) {
		--image_idx;
		screenshot->set_screenshot_image_original (images[image_idx]);
		mencoder_cmd->SetModified (true);
		run_filter ();
	}
}

void main_frame::OnNextButton (wxCommandEvent& event) {
	if (image_idx + 1 < images.size()) {
		++image_idx;
		screenshot->set_screenshot_image_original (images[image_idx]);
		mencoder_cmd->SetModified (true);
		run_filter ();
	}
}

// We want the command line to always match the picture.
//
// If the command line is changed and return is pressed, we run the new command
// line.
//
// If the command line is not changed and return is pressed, we switch to the
// old command line and run that.
void main_frame::OnRunButton (wxCommandEvent& event) {
	if (!images.size ()) {
		wxMessageBox (L"Open a folder of screen shots first");
		return;
	}

	if (mencoder_cmd->IsModified ()) {
		wstring cmd (mencoder_cmd->GetValue ());
		int pos (mencoder_cmd->GetInsertionPoint ());
		old_cmd2 = old_cmd1;
		old_pos2 = old_pos1;
		old_cmd1 = cmd;
		old_pos1 = pos;
	}
	else {
		wstring tmp_cmd (mencoder_cmd->GetValue ());
		int tmp_pos (mencoder_cmd->GetInsertionPoint ());
		wstring cmd (old_cmd2);
		int pos (old_pos2);
		old_cmd2 = tmp_cmd;
		old_pos2 = tmp_pos;
		mencoder_cmd->ChangeValue (cmd);
		mencoder_cmd->SetInsertionPoint (pos);
	}

	mencoder_cmd->SetModified (false);

	run_filter ();
}

void main_frame::OnSwapButton (wxCommandEvent& event) {
	screenshot->swap();
}

void main_frame::OnCmdChange (wxCommandEvent& event) {
	screenshot->set_screenshot_image_original (images[image_idx]);
}

void main_frame::run_filter () {
	wstring cmd (mencoder_cmd->GetValue ());

	wxBitmap src (screenshot->screenshot_image_original, 24);

	wqinit (src.GetWidth(), src.GetHeight(), src.GetWidth(), src.GetHeight());



	//// 
	//if (exists (L"00000001.png")) {
	//	screenshot->set_screenshot_image_filtered (L"00000001.png");
	//}
	//else {
	//	screenshot->clear_screenshot_image_filtered ();
	//}
	//wstring wres(res.begin(), res.end());
	//mencoder_res->ChangeValue (wres);
}
