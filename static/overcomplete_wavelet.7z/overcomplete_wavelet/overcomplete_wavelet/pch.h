#pragma once

#pragma message ("Compiling PCH - Should only happen once per project")

// Misc.
#include "int_types.h"

// Windows
#include "targetver.h"
#include "shlobj.h"

// wx
#include <wx/msw/setup.h>
#include <wx/wxprec.h>
#include <wx/slider.h>
#include <wx/image.h>
#include <wx/control.h>
#include <wx/dcclient.h>

// std
#include <list>
#include <sstream>
#include <fstream>
#include <vector>
#include <iostream>
#include <fstream>
#include <memory>

#include <math.h>

// boost
#include <boost/regex.hpp>
#include <boost/filesystem.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/regex.hpp>
