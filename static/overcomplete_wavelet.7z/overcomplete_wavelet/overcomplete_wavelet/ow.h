void wqinit (int width, int height, int dst_width, int dst_height);
