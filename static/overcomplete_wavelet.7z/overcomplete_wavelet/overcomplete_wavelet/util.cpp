#include "pch.h"

// Fill a byte_store_t with the contents of a file.
void read_file_to_vector (const boost::filesystem::wpath& path, std::vector<u8>& buf, bool binary) {
	// Open file and get size.
	std::ifstream in (path.file_string ().c_str (), std::ios::in | (binary ? std::ios::binary : 0));
	if (!in.good ()) {
		throw int(0);
	}
	in.unsetf (std::ios::skipws);
	in.seekg (0, std::ios::end);
	std::streampos fsize = in.tellg ();
	in.seekg (0, std::ios::beg);

	// Copy file to vector and close.
	// We reserve the memory first to speed up the back_inserts.
	buf.resize (fsize);
	in.read (reinterpret_cast<char*> (&buf[0]), fsize);
	in.close ();
}
