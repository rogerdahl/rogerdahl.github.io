for i in range (100):
	print str(i) + '\t' + str((i + 15) & (~15))
	
