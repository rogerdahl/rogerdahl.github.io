// Duplex - Delete duplicate files

#include "pch.h"

#include "md5.hpp"
#include "fnv_1a_64.h"
#include "junction.h"

#ifndef WIN32
using namespace __gnu_cxx;
#endif

#ifdef WIN32
using namespace stdext;
#endif

using namespace std;
using namespace boost;
using namespace boost::filesystem;
using namespace boost::program_options;

// Declarations.

bool add_folder(const wpath& dir_path, const bool recursive, const bool verbose, const bool quiet, u64 smaller, u64 bigger, bool debug);
bool add_folder_recursive(const wpath& dir_path, const bool recursive, const bool verbose, const bool quiet, u64 smaller, u64 bigger, timer& time, u64& file_cnt);
bool add_md5list(const wpath& md5deep_file, const bool verbose, const bool quiet, u64 smaller, u64 bigger, bool debug);

// Hash function for strings.
struct hash_string {
  // Parameters for hash table.
  enum {
    bucket_size = 4,
    min_buckets = 8
  };
  // Hash string s1 to size_t value.
  size_t operator()(const wstring& s1) const { 
    const unsigned char *p = (const unsigned char *)s1.c_str();
    size_t hashval = 0;
    for (size_t n = s1.size(); 0 < n; --n)
      hashval += *p++;
    return(hashval);
  }
  // Test if s1 ordered before s2.
  bool operator()(const wstring &s1, const wstring &s2) const { 
    return(s1 < s2);
  }
};

// Hash function for s64.
struct hash_s64 {
  // Parameters for hash table.
  enum {
    bucket_size = 4,
    min_buckets = 8
  };
  // Hash s64 s1 to size_t value.
  size_t operator()(const s64& s1) const {
    return((size_t)s1);
  }
  // Test if s1 ordered before s2.
  bool operator()(const s64 &s1, const s64 &s2) const { 
    return(s1 < s2);
  }
};

// Hold one file entry.
struct dup_file {
  dup_file(wpath path, u64 size, wstring hash) :
path(path),
size(size),
hash(hash) {
}
wpath path;
u64 size;
wstring hash;
};

// Comparison for dup_file pointers.
bool compare_dup_file(dup_file* _first, dup_file* _second) {
  return _first->path.native() < _second->path.native();
  //wstring first(_first->path.native());
  //wstring second(_second->path.native());
  //unsigned int i(0);
  //while ((i < first.length()) && (i < second.length())) {
  //  if (tolower(first[i]) < tolower(second[i])) {
  //    return true;
  //  }
  //  else if (tolower(first[i]) > tolower(second[i])) {
  //    return false;
  //  }
  //  ++i;
  //}
  //if (first.length()<second.length()) {
  //  return true;
  //}
  //return false;
}

// Hold one rule.
struct rule {
  rule(wregex rx, wstring rx_str) :
rx(rx),
rx_str(rx_str) {
}
wregex rx;
wstring rx_str;
};

// Types.

// Hold list of files in one group. It's important that this is a list and not
// another sequence, as we rely on iterators into the list remaining valid even
// when items are removed.
typedef list<dup_file> group_t;

// Map that files are initially put into when they're found. It both orders and
// groups files by filesize.
typedef map<u64, group_t> filemap_t;

// List of pointers to the individual files in the filemap.
typedef list<dup_file*> filelist_t;

typedef hash_map<wstring, group_t, hash_string> groupmap_t;

typedef list<rule> rulelist_t;

// A file_ref points to a specific file in a specific group.
typedef pair<groupmap_t::iterator, group_t::iterator> file_ref_t;
typedef deque<file_ref_t> file_refs_t;

filemap_t filemap;

// Display a file with size and path.
wformat filesize_row(L"%12d %s");
wformat filesize_hash_row(L"%12d %s %s");

// hold total stats.
struct total_stats_t {
  total_stats_t() :
num_total(0),
num_dup(0),
num_marked(0),
num_manual(0),
num_full_marked(0),
size_total(0),
size_dup(0),
size_marked(0)
{
}
u32 num_total;
u32 num_dup;
u32 num_marked;
u32 num_manual;
u32 num_full_marked;
u64 size_total;
u64 size_dup;
u64 size_marked;
};


// global count of number of files found for processing (in both folders and md5 lists).
bool add_folder(const wpath& dir_path, const bool recursive, const bool verbose, const bool quiet, u64 smaller, u64 bigger, bool debug) {
  u64 file_cnt(0);
  timer time;
  bool res = add_folder_recursive(dir_path, recursive, verbose, quiet, smaller, bigger, time, file_cnt);
  // Show debug info about filemap.
  if (debug) {
    wcout << L"Debug: filemap size: " << filemap.size() << endl;
    wcout << L"Debug: filemap max size: " << filemap.max_size() << endl;
  }
  // Print final file count (was probably not printed since we only print a count every second).
  wcout << L"Files: " << file_cnt << endl;
  return res;
}

// Recursively find file sizes and paths and store info in containers.
bool add_folder_recursive(const wpath& dir_path, const bool recursive, const bool verbose, const bool quiet, u64 smaller, u64 bigger, timer& time, u64& file_cnt) {
  // Check that path is valid and not a symlink.
  if (is_symlink(dir_path) || is_junction(dir_path)) {
    verbose && wcout << L"Skipped symlink: " << dir_path.native() << endl;
    return false;
  }
  verbose && wcout << L"Opening folder: " << dir_path.native() << endl;
  try {
    directory_iterator end_itr;
    for (directory_iterator itr(dir_path); itr != end_itr; ++itr) {
      wpath abs_path(absolute(*itr));
      try {
        if (is_directory(abs_path) && !is_symlink(abs_path)) {
          if (recursive) {
            add_folder_recursive(*itr, recursive, verbose, quiet, smaller, bigger, time, file_cnt);
          }
        }
        else {
          if (is_regular_file(abs_path)) {
            u64 size(file_size(abs_path));
            // Filter small files if requested.
            if (smaller != -1 && size <= smaller) {
              // for new boost
              verbose && wcout << L"Skipped <= " << smaller << L": " << str(filesize_row % size % abs_path.native()) << endl;
            }
            // Filter big files if requested.
            else if (bigger != -1 && size >= bigger) {
              verbose && wcout << L"Skipped >= " << bigger << L": " << str(filesize_row % size % abs_path.native()) << endl;
            }
            else {
              // Check if file already is in map (this can happen if user messes up the search folder arguments
              // or if some symlink og hardlink is followed (though I'm trying to avoid that).
              bool found_path(false);
              group_t& group(filemap[size]);
              for (group_t::iterator group_iter(group.begin()); group_iter != group.end(); ++group_iter) {
                if (group_iter->path == abs_path) {
                  verbose && wcout << L"Skipped redundant: " << str(filesize_row % size % abs_path.native()) << endl;
                  found_path = true;
                  break;
                }
              }
              if (!found_path) {
                // Add file to map.
                group.push_back(dup_file(abs_path, size, L""));
                verbose && wcout << L"Found: " << str(filesize_row % size % abs_path.native()) << endl;
              }
            }
          }
          ++file_cnt;
          // Display status if more than one second has elapsed.
          if (!quiet && time.elapsed() >= 1.0) {
            wcout << L"Files: " << file_cnt << endl;
            time.restart();
          }
        }
      }
      catch(const filesystem_error& e) {
        wcout << L"Error processing: " << abs_path.native() << endl;
        wcout << L"Cause: " << e.what() << endl;
      }
      catch(...) {
        wcout << L"Error processing: " << abs_path.native() << endl;
        wcout << L"Cause: Unknown exception" << endl;
      }
    }
  }
  catch(const filesystem_error& e) {
    wcout << L"Error: Couldn't open folder: " << dir_path.native() << endl;
    wcout << L"Cause: " << e.what() << endl;
  }
  catch(...) {
    wcout << L"Error: Couldn't open folder: " << dir_path.native() << endl;
    wcout << L"Cause: Unknown exception" << endl;
  }
  return true;
}

// Add a list of files generated with md5deep or similar.
//
// File format is one size, MD5 and full path per line. Example:
//
// 43912  ccd6dad4b72d1255cf2e7a9dadd64083  C:\Documents and Settings\Administrator\Desktop\test.txt
bool add_md5list(const wpath& md5deep_file, const bool verbose, const bool quiet, u64 smaller, u64 bigger, bool debug) {
  wregex md5line(L" *([0-9]+) +([0-9a-fA-F]{32}) +(.*)");
  boost::wsmatch what;
  timer time;
  u64 file_cnt(0);

  // Open file for reading.
  std::wifstream fi(md5deep_file.native().c_str());
  if (!fi.good()) {
    wcout << L"Error: Couldn't open file" << endl;
    return false;
  }

  while (fi.good()) {
    // Count processed files.
    file_cnt++;

    // Get line.
    wstring line;
    getline(fi, line);
    trim(line);

    // Ignore empty lines.
    if (line == L"")
      continue;

    // Parse line into size, md5 and path.
    if (!regex_search(line, what, md5line)) {
      wcout << L"Error: Malformed line in md5 file:" << endl;
      wcout << L"\"" << line << "\"" << endl;
      continue;
    }
    wstring size_str(what[1].first, what[1].second);
    wstring md5(what[2].first, what[2].second);
    wstring file(what[3].first, what[3].second);

    u64 size = lexical_cast<u64>(size_str);

    // Filter small files if requested.
    if (smaller != -1 && size <= smaller) {
      verbose && wcout << L"Skipped <= " << smaller << L": " << str(filesize_row % size % file) << endl;
    }
    // Filter big files if requested.
    else if (bigger != -1 && size >= bigger) {
      verbose && wcout << L"Skipped >= " << bigger << L": " << str(filesize_row % size % file) << endl;
    }
    else {
      // Process file.
      filemap[size].push_back(dup_file(wpath(file), size, md5));
      verbose && wcout << L"Found: " << str(filesize_row % size % file) << endl;
    }
    // Display progress once every second.
    if (!quiet && time.elapsed() >= 1.0) {
      wcout << L"Files: " << file_cnt << endl;
      time.restart();
    }
  }
  // Display final count (probably wasn't displayed above since we display only once per second).
  if (!quiet) {
    wcout << L"Files: " << file_cnt++ << endl;
  }
  // Show debug info about filemap.
  if (debug) {
    wcout << L"Debug: filemap size: " << filemap.size() << endl;
    wcout << L"Debug: filemap max size: " << filemap.max_size() << endl;
  }
  return true;
}

// Get all files that are marked in a group.
void get_marked
(
 groupmap_t::iterator& groupmap_iter,
 group_t& group,
 rulelist_t& rules,
 file_refs_t& files,
 total_stats_t& total_stats
 )
{
  u64 file_size(0);
  u32 num_marked(0);
  for (group_t::iterator group_iter = group.begin(); group_iter != group.end(); ++group_iter) {
    // Update total stats.
    if (!file_size) {
      file_size = group_iter->size;
    }
    // If we have marked all but one file in group, exit (no rule can mark all files in one group).
    if (num_marked + 1 == group.size()) {
      break;
    }
    // Run all rules on group.
    for (list<rule>::iterator rules_iter = rules.begin(); rules_iter != rules.end(); ++rules_iter) {
      if (regex_search(group_iter->path.native(), rules_iter->rx)) {
        ++num_marked;
        files.push_back(file_ref_t(groupmap_iter, group_iter));
        // Don't try any other rules when we get a match (would create duplicate delete entries).
        break;
      }
    }
  }
  // Update total stats.
  total_stats.num_total += (u32)group.size();
  total_stats.num_dup += (u32)group.size() - 1;
  total_stats.num_marked += num_marked;
  total_stats.size_total += group.size() * file_size;
  total_stats.size_dup += (group.size() - 1) * file_size;
  total_stats.size_marked += num_marked * file_size;
}

int main(int argc, char* argv[]) {
  // Program arguments.
  vector<wstring> folder_args;
  vector<wstring> rfolder_args;
  vector<wstring> md5list_args;
  vector<wstring> rule_args;
  wstring search, file;
  // Switches.
  bool automatic(false);
  bool verbose(false);
  bool quiet(false);
  bool debug(false);
  bool use_md5(false);
  bool query(false);
  bool dry_run(false);
  bool remove_empty(false);
  u64 smaller(-1), bigger(-1);
  // Command line arguments.
  try {
    options_description desc("Duplex - Delete duplicate files - dahlsys.com");
    desc.add_options()
      ("help,h", "produce help message")
      ("dry-run,d", bool_switch(&dry_run), "don't delete anything, just simulate")
      ("automatic,a", bool_switch(&automatic), "don't enter interactive mode (delete without confirmation)")
      ("filter-small,s", value<u64>(&smaller), "ignore files of this size and smaller")
      ("filter-big,b", value<u64>(&bigger), "ignore files of this size and bigger")
      ("quiet,q", bool_switch(&quiet), "display only error messages")
      ("verbose,v", bool_switch(&verbose), "display verbose messages")
      ("debug,e", bool_switch(&debug), "display debug / optimization info")
      ("md5,5", bool_switch(&use_md5), "use md5 cryptographic hash (fnv 64 bit hash is used by default)")
      ("rule,u", wvalue< vector<wstring> >(&rule_args), "add marking rule (case insensitive regex)")
      ("rfolder,r", wvalue< vector<wstring> >(&rfolder_args), "add recursive search folder")
      ("md5list,m", wvalue< vector<wstring> >(&md5list_args), "add md5 list file (output from md5deep -zr)")
      ("folder,f", wvalue< vector<wstring> >(&folder_args), "add search folder")
      ;

    positional_options_description p;
    p.add("rfolder", -1);

    variables_map vm;
    store(command_line_parser(argc, argv).options(desc).positional(p).run(), vm);
    notify(vm);

    // Display help and exit if required options (yes, I know) are missing.
    if (vm.count("help") || (!folder_args.size() && !rfolder_args.size() && !md5list_args.size())) {
      cout << desc << endl << "Arguments are equivalent to rfolder options" << endl;
      exit(1);
    }

    // Switch to md5 hashes if md5lists are used.
    if (md5list_args.size()) {
      verbose && cout << "Enabled md5 hashes due to md5list being used" << endl;
      use_md5 = true;
    }
  }
  catch(std::exception& e) {
    cerr << L"Error: " << e.what() << endl;
    exit(1);
  }
  catch(...) {
    cerr << L"Error: Unknown exception" << endl;;
    exit(1);
  }

  // Switch from C locale to user's locale.
  // will be used for all new streams.
  std::locale::global(std::locale(""));
  // This stream was already created, so must imbue.
  wcout.imbue(locale(""));

  // Verify that all provided folder names have legal syntax and exist.
  vector<wstring>::iterator i;
  try {
    for (i = folder_args.begin(); i != folder_args.end(); ++i) {
      if (!exists(*i) || !is_directory(*i)) {
        throw 0;
      }
    }
    for (i = rfolder_args.begin(); i != rfolder_args.end(); ++i) {
      if (!exists(*i) || !is_directory(*i)) {
        throw 0;
      }
    }
    for (i = md5list_args.begin(); i != md5list_args.end(); ++i) {
      if (!exists(*i) || is_directory(*i)) {
        throw 0;
      }
    }
  }
  catch(...) {
    wcout << L"Error: Illegal path: " << endl;
    wcout << *i << endl;
    exit(1);
  }

  // Build database of files to process.

  // Add all files in search folders, non-recursive.
  for (vector<wstring>::iterator i = folder_args.begin(); i != folder_args.end(); ++i) {
    wcout << L"Processing non-recursive: " << *i << endl;
    add_folder(wpath(*i), false /* not recursive */, verbose, quiet, smaller, bigger, debug);
  }

  // Add all files in search folders, recursive.
  for (vector<wstring>::iterator i = rfolder_args.begin(); i != rfolder_args.end(); ++i) {
    wcout << L"Processing recursive: " << *i << endl;
    add_folder(wpath(*i), true /* recursive */, verbose, quiet, smaller, bigger, debug);
  }

  // Add all files provided as md5 lists.
  for (vector<wstring>::iterator i = md5list_args.begin(); i != md5list_args.end(); ++i) {
    wcout << L"Processing md5 list: " << *i << endl;
    add_md5list(wpath(*i), verbose, quiet, smaller, bigger, debug);
  }

  // Remove files that have unique size (optimization -- they can't have duplicates so no need to MD5 them).
  u32 unique_size_cnt(0);
  for (filemap_t::iterator filemap_iter = filemap.begin(); filemap_iter != filemap.end(); ) {
    if (filemap_iter->second.size() <= 1) {
      // Erasing an element from a map also not invalidate any iterators, except
      // for iterators that actually point to the element that is being erased.
      filemap.erase(filemap_iter++);
      ++unique_size_cnt;
    }
    else {
      ++filemap_iter;
    }
  }
  verbose && wcout << L"Removed " << unique_size_cnt << L" file entries based on unique file size" << endl;

  // Show debug info about filemap.
  if (debug) {
    wcout << L"Debug: filemap after unique size optimization:" << endl;
    wcout << L"Debug: filemap size: " << filemap.size() << endl;
    wcout << L"Debug: filemap max size: " << filemap.max_size() << endl;
  }

  // Hash of lists of files is the map that files are put into after
  // files with unique file lenghts are eliminated. It groups files by
  // hash.
  groupmap_t groupmap;

  // List that keeps the order that the groupmaps were created in. Because
  // filemap is a map sorted by filesize, groupwalker is also sorted. This
  // enables us to move back and forth in groups based on file size, and to put
  // the group with the biggest files first.
  typedef list<wstring> groupwalker_t;
  groupwalker_t groupwalker;

  // Sum up file sizes and number of files (for progress display).
  u64 totsize(0);
  u64 numfiles(0);
  for (filemap_t::iterator filemap_iter = filemap.begin(); filemap_iter != filemap.end(); ++filemap_iter) {
    for (group_t::iterator group_iter = filemap_iter->second.begin(); group_iter != filemap_iter->second.end(); ++group_iter) {
      totsize += group_iter->size;
      ++numfiles;
    }
  }

  // We want to hash the files in the same order as we found them in the
  // filesystem because processing them in that order is much faster than
  // jumping ramdomly around in the filesystem, as we would if we were to
  // process them by filesize.
  
  // Create a list of pointers to the dup_file entries and sort that list.
  filelist_t filelist;
  for (filemap_t::iterator filemap_iter = filemap.begin(); filemap_iter != filemap.end(); ++filemap_iter) {
    for (group_t::iterator group_iter = filemap_iter->second.begin(); group_iter != filemap_iter->second.end(); ++group_iter) {
      filelist.push_back(&*group_iter);
    }
  }
  filelist.sort(compare_dup_file);

  // Calculate hashes for all files.
  u64 so_far_size(0);
  u64 file_cnt(0);
  timer time;
  for (filelist_t::iterator filelist_iter = filelist.begin(); filelist_iter != filelist.end(); ++filelist_iter) {
    ++file_cnt;
    wstring hash;
    try {
      if ((*filelist_iter)->hash == L"") {
        if (use_md5) {
          boost::filesystem::ifstream file((*filelist_iter)->path, ios::binary);
          string ck(md5(file).digest().hex_str_value());
          wstring wck(ck.begin(), ck.end());
          (*filelist_iter)->hash = wck;
        }
        else {
          u64 fnv_hash(fnv_1a_64((*filelist_iter)->path));
          (*filelist_iter)->hash = str(wformat(L"%x") % fnv_hash);
        }
        verbose && wcout << (use_md5 ? L"MD5: " : L"FNV64: ") << str(filesize_hash_row
          % (*filelist_iter)->size
          % (*filelist_iter)->hash
          % (*filelist_iter)->path.native())
          << endl;
      }
      // Display status.
      so_far_size += (*filelist_iter)->size;
      if (!quiet && totsize && (time.elapsed() >= 1.0 || so_far_size == totsize)) {
        wcout << fixed << setprecision(2) <<
          L"Calculating " << (use_md5 ? L"MD5" : L"FNV64") << " hashes:\n" <<
          L"Data: " << (float)so_far_size / (float)totsize * 100 << L"% (" << so_far_size << L" / " << totsize << L" bytes)\n" << 
          L"Files: " << (float)file_cnt / (float)numfiles * 100 << L"% (" << file_cnt << L" / " << numfiles << L" files)\n" << endl;
        time.restart();
      }
    }
    catch (boost::filesystem::ifstream::failure e) {
      wcout << L"Skipped file: " << (*filelist_iter)->path.native() << endl;
      wcout << L"Cause: " << e.what() << endl;
    }
    catch(const filesystem_error& e) {
      wcout << L"Skipped file: " << (*filelist_iter)->path.native() << endl;
      wcout << L"Cause: " << e.what() << endl;
    }
    catch (const wstring& s) {
      wcout << L"Skipped file: " << (*filelist_iter)->path.native() << endl;
      wcout << L"Cause: " << s << endl;
    }
    catch(...) {
      wcout << L"Skipped file: " << (*filelist_iter)->path.native() << endl;
      wcout << L"Cause: Unknown exception" << endl;
    }
  }
  filelist.clear();

  // Build database of duplicates.
  for (filemap_t::iterator filemap_iter = filemap.begin(); filemap_iter != filemap.end(); ) {
    for (group_t::iterator group_iter = filemap_iter->second.begin(); group_iter != filemap_iter->second.end(); ++group_iter) {
      wstring hash_and_size(group_iter->hash + str(wformat(L"%d") % group_iter->size));
      groupmap[hash_and_size].push_back(dup_file(group_iter->path, group_iter->size, L""));
      // If this is the first file added to groupmap, we add the group to the walker.
      if (groupmap[hash_and_size].size() == 1) {
        groupwalker.push_front(hash_and_size);
      }
    }
    // Erasing an element from a map does not invalidate any iterators except
    // for iterators that point to the element that is being erased.
    filemap.erase(filemap_iter++);
  }
  // Free memory used for the initial file map.
  filemap.clear();

  // Show debug info about group map.
  if (debug) {
    wcout << L"Debug: groupmap size: " << groupmap.size() << endl;
    wcout << L"Debug: groupmap max size: " << groupmap.max_size() << endl;
  }

  // Add the rules given on the command line.

  // List of marking rules.
  rulelist_t rulelist;

  for (vector<wstring>::iterator i = rule_args.begin(); i != rule_args.end(); ++i) {
    try {
      rulelist.push_back(rule(wregex(*i, regbase::perl | regbase::icase), *i));
    }
    catch(...) {
      wcout << L"Error: \"" << *i << "\" is not a valid regular expression" << endl;
      exit(1);
    }
  }

  // Interactive.

  wformat file_row(L"%3d %c %12d %s");
  wformat rule_row(L"%3d %s");
  bool display_rules(!quiet);
  bool display_help(false);
  bool displaystatus(!quiet);
  bool cleangroups(true);
  bool did_delete(false);
  size_t walkpos(1);

  // Go to first group (the one with the biggest file sizes).
  groupwalker_t::iterator groupwalker_iter(groupwalker.begin());
  walkpos = 1;

  // Start interactive section.
  for (;;) {
    // Remove groups with only one file.
    if (cleangroups) {
      cleangroups = false;
      u32 cnt_removed(0);
      for (groupwalker_t::iterator iter(groupwalker.begin()); iter != groupwalker.end(); ) {
        if (groupmap[*iter].size() <= 1) {
          groupmap.erase(*iter);
          groupwalker.erase(iter++);
          ++cnt_removed;
        }
        else {
          ++iter;
        }
      }
      // Set walker to first group.
      groupwalker_iter = groupwalker.begin();
      walkpos = 1;
      verbose && cnt_removed && wcout << L"Removed " << cnt_removed << L" groups with only one member" << endl;
    }

    // Exit if no more groups.
    if (!groupmap.size()) {
      if (!quiet) {
        if (did_delete) {
          wcout << L"No more duplicates" << endl;
        }
        else {
          wcout << L"No duplicates found" << endl;
        }
      }
      break;
    }

    // Shortcuts for this group.
    wstring groupkey(*groupwalker_iter);
    group_t& group(groupmap[groupkey]);

    if (displaystatus) {
      displaystatus = false;

      total_stats_t total_stats;
      for (groupmap_t::iterator groupmap_iter = groupmap.begin(); groupmap_iter != groupmap.end(); ++groupmap_iter) {
        file_refs_t files;
        get_marked(groupmap_iter, groupmap_iter->second, rulelist, files, total_stats);
      }

      wformat status_row(L"%18d %s");
      wcout << endl;
      wcout << L"Status:" << endl << endl;
      wcout << str(status_row % total_stats.num_total       % L"files") << endl;
      wcout << str(status_row % total_stats.num_dup         % L"duplicates") << endl;
      wcout << str(status_row % total_stats.num_marked      % L"marked files") << endl;
      wcout << str(status_row % groupmap.size() % L"groups") << endl;
      //			wcout << str(status_row % num_manual      % L"manual groups") << endl;
      wcout << str(status_row % total_stats.size_total      % L"bytes in all groups") << endl;
      wcout << str(status_row % total_stats.size_dup        % L"bytes in duplicates") << endl;
      wcout << str(status_row % total_stats.size_marked     % L"bytes in all marked files") << endl;
      //if (num_full_marked)
      //	wcout << str(status_row % num_full_marked % L"groups with ALL marked (warning!)") << endl;
      wcout << str(status_row %((float)total_stats.num_total / (float)groupmap.size()) % L"files per group (average)") << endl;
    }

    if (display_help) {
      display_help = false;
      wcout << L"Interactive mode commands:" << endl << endl;
      wcout << L"f, first          : go to first group" << endl;
      wcout << L"l, last           : go to last group" << endl;
      wcout << L"p, previous       : go to previous group" << endl;
      wcout << L"n, next, <Enter>  : go to next group" << endl;
      //			wcout << L"t, toggle <index> : toggle mark on file with given index" << endl;
      wcout << L"c, clear          : remove all manual editing" << endl;
      wcout << L"r, rules          : list rules" << endl;
      wcout << L"a, add <rule>     : add rule (case insensitive regular expression)" << endl;
      wcout << L"b, file <file #>  : add rule (file number)" << endl;
      wcout << L"d, remove <index> : remove rule" << endl;
      wcout << L"h, help, ?        : display this message" << endl;
      wcout << L"s, status         : display status" << endl;
#ifdef WIN32
      wcout << L"o, open <index>   : open file" << endl;
#endif
      wcout << L"quit, exit        : exit program without deleting anything" << endl;
      wcout << L"delete            : delete all marked files" << endl;
      wcout << endl;
    }

    // Display existing rules if previous command was a rule add or delete command.
    if (display_rules) {
      display_rules = false;
      wcout << L"Rules:" << endl << endl;
      if (!rulelist.size()) {
        wcout << L"No rules defined" << endl;
      }
      else {
        // Display existing rules.
        int c(0);
        for (list<rule>::iterator iter = rulelist.begin(); iter != rulelist.end(); ++iter) {
          wcout << str(rule_row % ++c % iter->rx_str) << endl;
        }
      }
      wcout << endl;
    }

    // Get command, or hardwire delete command if automatic mode.
    wstring cmd, cmdarg;
    if (!automatic) {
      // Display list of files in group and mark status.
      total_stats_t group_stats;
      groupmap_t::iterator dummy_iter = groupmap.begin();
      file_refs_t files;
      get_marked(dummy_iter, group, rulelist, files, group_stats);

      wcout << endl;
      u32 cnt_files(0);
      for (group_t::iterator group_iter = group.begin(); group_iter != group.end(); ++group_iter) {
        bool marked(find(files.begin(), files.end(), file_ref_t(dummy_iter, group_iter)) != files.end());
        wcout << str(file_row % ++cnt_files % (marked ? '*' : ' ') % group_iter->size % group_iter->path.native()) << endl;
      }

      wcout << endl;
      wformat status_row(L"%18d %s");
      wcout << str(status_row % group_stats.size_total  % L"bytes in group") << endl;
      wcout << str(status_row % group_stats.size_dup    % L"bytes in duplicates") << endl;
      wcout << str(status_row % group_stats.size_marked % L"bytes in marked files") << endl;

      // Get command.
      wstring cmdline;
      wcout << endl;
      wcout << walkpos << L" / " << groupwalker.size() << L" > " << flush;
      getline(wcin, cmdline);
      // Split command into command and argument.
      size_t space_idx = cmdline.find(L" ");
      cmd = cmdline.substr(0, space_idx);
      trim(cmd);
      if (space_idx != -1) {
        cmdarg = cmdline.substr(space_idx);
        trim(cmdarg);
      }
    }
    else {
      // automatic.
      cmd = L"delete";
    }
    // display rules
    if (cmd == L"r" || cmd == L"rule") {
      // Flag display rules after all rules have been added.
      display_rules = true;
    }
    // Add rule (regex).
    else if (cmd == L"a" || cmd == L"add") {
      if (cmdarg == L"") {
        wcout << L"Error: Missing rule argument" << endl;
        display_help = true;
        continue;
      }
      try {
        rulelist.push_back(rule(wregex(cmdarg, regbase::perl | regbase::icase), cmdarg));
      }
      catch(...) {
        wcout << L"Error: \"" << cmdarg << "\" is not a valid regular expression. Ignored." << endl;
        display_help = true;
        continue;
      }
      // Flag display rules after all rules have been added.
      display_rules = true;
    }
    // Add rule (file #).
    else if (cmd == L"b" || cmd == L"file") {
      if (cmdarg == L"") {
        wcout << L"Error: Missing index argument" << endl;
        display_help = true;
        continue;
      }
      u32 idx;
      try {
        idx = lexical_cast<u32>(cmdarg);
        if (idx < 1 || idx > group.size()) {
          throw(0);
        }
      }
      catch(...) {
        wcout << L"Error: \"" << cmdarg << "\" is not a valid index" << endl;
        display_help = true;
        continue;
      }
      // Since a list doesn't have random access, we walk out to the required element.
      group_t::iterator group_iter = group.begin();
      for (u32 d(0); d < idx - 1; ++d) { 
        ++group_iter;
      }
      // Escape path for use as regex.
      wregex esc(L"[\\^\\.\\$\\|\\(\\)\\[\\]\\*\\+\\?\\/\\\\]");
      wstring rep(L"\\\\\\1&");
      wstring escaped_path(regex_replace(group_iter->path.native(), esc, rep, match_default | format_sed));
      try {
        rulelist.push_back(rule(wregex(escaped_path, regbase::perl),
          wstring(L"Delete: ") + group_iter->path.native()));
      }
      catch(...) {
        wcout << L"Error: \"" << cmdarg << "\" is not a valid regular expression. Ignored." << endl;
        display_help = true;
        continue;
      }
    }
    // Erase rule.
    else if (cmd == L"d" || cmd == L"remove") {
      if (cmdarg == L"") {
        wcout << L"Error: Missing index argument" << endl;
        display_help = true;
        continue;
      }
      u32 idx;
      try {
        idx = lexical_cast<u32>(cmdarg);
        if (idx < 1 || idx > rulelist.size()) {
          throw(0);
        }
      }
      catch(...) {
        wcout << L"Error: \"" << cmdarg << "\" is not a valid index" << endl;
        display_help = true;
        continue;
      }
      // Since a list doesn't have random access, we walk out to the required element.
      rulelist_t::iterator rule_iter = rulelist.begin();
      for (u32 d(0); d < idx - 1; ++d) { 
        ++rule_iter;
      }
      rulelist.erase(rule_iter);
      // Flag display rules after all rules have been added.
      display_rules = true;
    }
    // Go to next group.
    else if (cmd == L"n" || cmd == L"next" || cmd == L"") {
      ++groupwalker_iter;
      ++walkpos;
      if (groupwalker_iter == groupwalker.end()) {
        wcout << L"No more groups" << endl;
        --groupwalker_iter;
        --walkpos;
      }
    }
    // Go to previous group.
    else if (cmd == L"p" || cmd == L"previous") {
      if (groupwalker_iter == groupwalker.begin()) {
        wcout << L"Already at first group" << endl;
      }
      else {
        --groupwalker_iter;
        --walkpos;
      }
    }
    // Go to first group.
    else if (cmd == L"f" || cmd == L"first") {
      if (groupwalker_iter == groupwalker.begin()) {
        wcout << L"Already at first group" << endl;
      }
      else {
        groupwalker_iter = groupwalker.begin();
        walkpos = 1;
      }
    }
    // Go to last group.
    else if (cmd == L"l" || cmd == L"last") {
      if (walkpos == groupwalker.size()) {
        wcout << L"Already at last group" << endl;
      }
      else {
        groupwalker_iter = groupwalker.end();
        --groupwalker_iter;
        walkpos = groupwalker.size();
      }
    }
    // Display status.
    else if (cmd == L"s" || cmd == L"status") {
      displaystatus = true;
    }
#ifdef WIN32
    // Open file.
    else if (cmd == L"o" || cmd == L"open") {
      if (cmdarg == L"") {
        wcout << L"Error: Missing index argument" << endl;
        display_help = true;
        continue;
      }
      try {
        int idx(1);
        int pidx(lexical_cast<int>(cmdarg));
        for (group_t::iterator group_iter = group.begin(); group_iter != group.end(); ++group_iter) {
          if (idx == pidx) {
            wstringstream s;
            s << L"start /b \"" << group_iter->path.native() << L"\"";
            //system(s.str().c_str());
            break;
          }
          ++idx;
        }
        rulelist.push_back(rule(wregex(cmdarg, regbase::perl | regbase::icase), cmdarg));
      }
      catch(...) {
        wcout << L"Error: \"" << cmdarg << "\" is not a valid index." << endl;
      }
    }
#endif
    // Delete files.
    else if (cmd == L"delete") {
      displaystatus = false;

      total_stats_t total_stats;
      file_refs_t files;
      for (groupmap_t::iterator groupmap_iter = groupmap.begin(); groupmap_iter != groupmap.end(); ++groupmap_iter) {
        get_marked(groupmap_iter, groupmap_iter->second, rulelist, files, total_stats);
      }

      // Delete confirmation.
      wstring cmdline(L"Y");
      if (!automatic && !quiet) {
        wcout << endl;
        for (;;) {
          wcout << L"About to delete " << total_stats.num_marked << L" files (" << total_stats.size_marked << L" bytes) Delete? (y/n) > " << flush;
          getline(wcin, cmdline);
          if (cmdline == L"Y" || cmdline == L"y" || cmdline == L"N" || cmdline == L"n")
            break;
        }
      }

      // Do delete.
      if (cmdline == L"Y" || cmdline == L"y" ) {
        u64 file_cnt(0);
        u64 files_deleted(0);
        timer time;
        for (file_refs_t::iterator file_items_iter = files.begin(); file_items_iter != files.end(); ++file_items_iter) {
          did_delete = true;
          wpath this_path(file_items_iter->second->path);
          try {
            if (!dry_run) {
              remove(file_items_iter->second->path);
              ++files_deleted;
              verbose && wcout << L"Deleted by rule: " << this_path.native() << endl;
            }
            else {
              wcout << L"Dry-run: Skipped delete: " << this_path.native() << endl;
            }
            // Delete from group (unless filesystem delete exception).
            file_items_iter->first->second.erase(file_items_iter->second);
          }
          catch(const filesystem_error& e) {
            wcout << L"Couldn't delete: " << this_path.native() << endl;
            wcout << L"Cause: " << e.what() << endl;
          }
          catch(...) {
            wcout << L"Couldn't delete: " << this_path.native() << endl;
            wcout << L"Cause: Unknown exception" << endl;
          }
          // Count files deleted.
          ++file_cnt;
          // Display status if one second has elapsed or this is last iteration.
          if (!quiet && (time.elapsed() >= 1.0 || file_cnt == total_stats.num_marked)) {
            wcout << setprecision(2) << 
              L"Deleting: " << (float)file_cnt / (float)total_stats.num_marked * 100 << L"% (" << 
              file_cnt << L" / " << total_stats.num_marked << L" files)\n" <<
              L"Failed: " << (file_cnt - files_deleted) << L" files\n" << endl;
            time.restart();
          }
        }
      }

      displaystatus = true;
      cleangroups = true;
      // If in automatic mode, exit here.
      if (automatic)
        break;
    }
    // Display help.
    else if (cmd == L"h" || cmd == L"help" || cmd == L"?") {
      display_help = true;
    }
    // Quit.
    else if (cmd == L"quit" || cmd == L"exit") {
      break;
    }
    // Unknown command.
    else {
      wcout << L"Error: Unknown command" << endl;
      display_help = true;
    }
  } // for (;;)

  // Success.
  exit(0);
}
