#include "pch.h"

bool is_junction(const boost::filesystem::wpath&);
