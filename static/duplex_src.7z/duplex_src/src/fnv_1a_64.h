u64 fnv_1a_64(const boost::filesystem::wpath& path);

