//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Multismart.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define id_dlg_about                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_MULTISTYPE                  129
#define IDR_MAINFRAME1                  129
#define IDR_MAINFRAME2                  130
#define id_dlg_downloader               130
#define id_dlg_showhide                 135
#define id_dialog_select                143
#define id_dlg_select_cleanup           149
#define id_dlg_select_request           151
#define id_dlg_select                   153
#define id_dlg_progress                 154
#define id_dlg_description_cleaning     157
#define id_html_about                   162
#define id_dlg_duplicates               163
#define id_dlg_duplicates_confirm       164
#define IDD_DIALOG1                     167
#define id_dlg_delete_confirm           169
#define id_dlg_copy                     173
#define id_bitmap_logo                  174
#define id_chk_show_existing            1000
#define ID_VIEW_CHK_SHOWEXISTING        1001
#define ID_VIEW_CHK_SHOWMISSING         1002
#define id_edit_parts                   1003
#define id_edit_days                    1004
#define id_chk_onlyexisting             1005
#define id_chk_onlynonexisting          1006
#define id_chk_hide_nonrar              1006
#define id_pic_info                     1007
#define id_chk_hide_sfv                 1007
#define id_chk_show_missing             1008
#define id_tab                          1009
#define id_request_edit_dayfirst        1010
#define id_request_edit_daylast         1011
#define id_request_edit_parts           1012
#define id_select_edit_dayfirst         1015
#define id_select_edit_daylast          1016
#define id_select_edit_parts            1017
#define id_progress_loading             1019
#define IDC_CHECK1                      1022
#define id_explorer                     1024
#define id_edit_info                    1026
#define id_pic_warning                  1027
#define id_chk_nomore                   1028
#define id_pic_question                 1029
#define id_static_message               1030
#define id_static_warning               1032
#define id_list_files                   1035
#define id_radio_existing               1036
#define id_radio_virtual                1037
#define id_radio_both                   1038
#define id_rich_info                    1040
#define ID_EDIT_DELETE                  32771
#define ID_TOOLS_AUTOSELECT             32773
#define ID_TOOLS_DUPLICATES             32774
#define ID_TOOLS_REQUESTS               32775
#define ID_TOOLS_PAR                    32776
#define ID_VIEW_REFRESH                 32777
#define ID_TOOLS_RESET                  32781
#define id_but_pause                    32782
#define ID_VIEW_PAUSE                   32782
#define id_but_stop                     32784
#define ID_TEST_2                       32784
#define id_but_delete                   32785
#define ID_DIALOG_STATUS_BAR            32785
#define id_but_copy                     32786
#define ID_VIEW_DIALOG_BAR              32786
#define id_but_openfolder               32789
#define id_but_selectfolder             32792
#define id_but_autoselect               32793
#define id_but_exit                     32795
#define id_but_about                    32796
#define id_but_refresh                  32797
#define ID_TEST                         32798
#define id_but_crc                      32800
#define id_but_request                  32801
#define id_but_duplicates               32803
#define ID_INDICATOR_SEL                59142
#define ID_INDICATOR_TOT                59143
#define ID_INDICATOR_FREE               59144
#define ID_INDICATOR_SELNO              59145

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
