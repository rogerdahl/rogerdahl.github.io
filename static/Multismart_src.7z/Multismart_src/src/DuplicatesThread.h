#pragma once

#include "DuplicatesDlg.h"

#define UWM_ADDSTR (WM_APP + 1843)


// CDuplicatesThread thread.

class CDuplicatesThread : public CWinThread {
    DECLARE_DYNCREATE(CDuplicatesThread)
  protected:
    // Protected constructor used by dynamic creation.
    CDuplicatesThread();

    // Attributes.
  public:
    bool AddStr(CString cs);

    // Overrides.
  public:
    virtual BOOL InitInstance();
    virtual int ExitInstance();

    // Implementation.
  protected:
    virtual ~CDuplicatesThread();

    DECLARE_MESSAGE_MAP()

    void OnMsgAddStr(WPARAM wParam, LPARAM lParam);

    CDuplicatesDlg* pDlg;
    u32 iTxtCnt;
};
