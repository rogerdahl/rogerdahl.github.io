#include "stdafx.h"
#include "../res/resource.h"	// main symbols
#include "DuplicatesDlg.h"
#include "DuplicatesThread.h"
#include "VPar.h"
#include "MultismartView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// Including VFile.h here to get access to DiskFile. Can not include in VPar.h
// because vPar.h is included in VFile.h

CVPar::CVPar(void) {
  // Primes: 67, 127, 257, 571, 1009, 4001, 5003, 7919.
  mapSets.InitHashTable(257);
  mapParentToSet.InitHashTable(257);
  mapChildToSet.InitHashTable(257);
  mapChildNameToItem.InitHashTable(257);
  mapParentNameToItem.InitHashTable(257);
  mapParentNameToSet.InitHashTable(257);
  mapChildNameToSet.InitHashTable(257);
  mapChildItemToParentItem.InitHashTable(257);
}

CVPar::~CVPar(void) {
  ContainerCleanup();
}

// Delete all pointed-to objects on the free store that have pointers in
// containers.
void CVPar::ContainerCleanup(void) {
  CVParSetItem* pSetItem;
  CVParParentItem* pParentItem;
  CVParChildItem* pChildItem;
  CMd5		md5;
  POSITION	posSets = mapSets.GetStartPosition();

  while (posSets != NULL) {
    mapSets.GetNextAssoc(posSets, md5, pSetItem);

    POSITION	posChildren = pSetItem->mapChildren.GetStartPosition();

    while (posChildren != NULL) {
      pSetItem->mapChildren.GetNextAssoc(posChildren, md5, pChildItem);
      delete pChildItem;
    }

    POSITION	posParents = pSetItem->mapParents.GetStartPosition();

    while (posParents != NULL) {
      pSetItem->mapParents.GetNextAssoc(posParents, md5, pParentItem);
      delete pParentItem;
    }

    delete pSetItem;
  }
}

// Gen.
bool CVPar::LoadFolder(bool fQuick) {
  CVSfv::LoadFolder(fQuick);
  ProgressSet("Scanning PAR parents and mapping PAR children...", 55);
  LoadParFiles();

  return true;
}

// Load all PAR files in folder.
//
// if several PAR files exist and they all contain info on the same file
// (test1.PAR  test1-0001.PAR for instance), the last file found will be
// the one that is recorded as the PARent of that file. This can create
// confusing results when deleting files.
bool CVPar::LoadParFiles(void) {
  TRACE("CVPar::LoadFolder()\n");

  // Delete all the actual items that are being pointed to.
  ContainerCleanup();

  mapSets.RemoveAll();
  mapParentToSet.RemoveAll();
  mapParentNameToItem.RemoveAll();
  mapChildToSet.RemoveAll();
  mapChildNameToItem.RemoveAll();
  mapParentNameToSet.RemoveAll();
  mapChildNameToSet.RemoveAll();
  mapChildItemToParentItem.RemoveAll();

  CString		csFFirst, csFLast;
  CVDiskCont	df;
  CString		csFname;
  POSITION	pos = CVDisk::GetStartPosition();

  while (pos != NULL) {
    CVDisk::GetNextAssoc(&pos, &csFname, &df);

    if (SplitPAR(df.csDisplayFname, &csFFirst, &csFLast)) {
      LoadFile(df.csDisplayFname);
    }
  }

  TRACE("CVPar::LoadFolder() Maps:\n", mapSets.GetCount());
  TRACE("mapSets %d\n", mapSets.GetCount());
  TRACE("mapParentToSet %d\n", mapParentToSet.GetCount());
  TRACE("mapChildToSet %d\n", mapChildToSet.GetCount());
  TRACE("mapChildNameToItem %d\n", mapChildNameToItem.GetCount());
  TRACE("mapParentNameToItem %d\n", mapParentNameToItem.GetCount());
  TRACE("mapParentNameToSet %d\n", mapParentNameToSet.GetCount());
  TRACE("mapChildNameToSet %d\n", mapChildNameToSet.GetCount());
  TRACE("mapChildItemToParentItem %d\n", mapChildItemToParentItem.GetCount());

  return true;
}

/*
	Add all PAR children from a single PAR parent to mapChildren.
	Add all PAR parents from a single PAR parent to mapParents.

	If none of the PAR children exist on disk, the parent is not loaded.
	This makes it possible to keep old PAR files around without using
	huge amounts of memory.
*/
bool CVPar::LoadFile(CString csParFname) {
  CFile	cF;

  if (!cF.Open(GetWorkingFolder() + csParFname, CFile::modeRead)) {
    TRACE("Could not open %s\n", csParFname);
    return false;
  }

  u64 pHead[0x60];

  if (cF.Read(pHead, 0x60) < 0x60) {
    TRACE("Read error on %s (or truncated to less than 0x60 bytes)\n", csParFname);
    return false;
  }

  // PAR signature.
  if (strncmp((s8*)pHead, "PAR\0\0\0\0\0", 8)) {
    TRACE("%s not a PAR file\n", csParFname);
    return false;
  }

  // PAR file version.
  if (strncmp((s8*)pHead + 8, "\0\0\0\1\0\0\0\0", 8)) {
    TRACE("%s is not a v1.00 PAR file\n", csParFname);
    return false;
  }

  // TODO: check if PAR file is valid here.
  CMd5 md5Parent(pHead + (0x10 / sizeof(u64)));

  // Check if this PAR file belongs to a set I have encountered before.
  CVParSetItem* pItemSet;
  bool	fFirstSet = false;
  CMd5	md5Set(pHead + (0x20 / sizeof(u64)));

  if (!mapSets.Lookup(md5Set, pItemSet)) {
    // Have not encountered set before. create a new set and map it.
    fFirstSet = true;
    pItemSet = new CVParSetItem;
    mapSets[md5Set] = pItemSet;

    // Create name for parity set.
    CString csFFirst, csFLast;

    if (SplitPAR(csParFname, &csFFirst, &csFLast)) {
      pItemSet->csName = csFFirst;
    }
    else {
      pItemSet->csName = csParFname;
    }
  }

  CString csParFnameKey = csParFname;
  csParFnameKey.MakeLower();
  // Can't overlap.
  ASSERT(!mapParentNameToSet.Lookup(csParFnameKey, pItemSet));
  mapParentNameToSet[csParFnameKey] = pItemSet;

  // Map this parent.

  // TODO: Bug: there may be copies of the same parent with different file
  // names. Should store the name that is most similar to the childrens names.

  CVParParentItem* pItemParent;

  if (!pItemSet->mapParents.Lookup(md5Parent, pItemParent)) {
    pItemParent = new CVParParentItem;
    pItemParent->csDisplayFname = csParFname;
    pItemParent->iVolumePos = (u32)(pHead[0x30 / sizeof(u64)]);
    pItemParent->iParityOffset = (u32)(pHead[0x50 / sizeof(u64)]);
    pItemParent->iParitySize = (u32)(pHead[0x58 / sizeof(u64)]);
    pItemParent->md5 = md5Parent;

    // Can't overlap.
    ASSERT(!pItemSet->mapParents.Lookup(md5Parent, pItemParent));
    pItemSet->mapParents[md5Parent] = pItemParent;

    pItemSet->iParitySets += (pItemParent->iVolumePos > 0);
    // Can't overlap.
    ASSERT(!mapParentToSet.Lookup(md5Parent, md5Set));
    mapParentToSet[md5Parent] = md5Set;

    CString csParentFnameKey(pItemParent->csDisplayFname);
    csParentFnameKey.MakeLower();

    // Can't overlap.
    ASSERT(!mapParentNameToItem.Lookup(csParentFnameKey, pItemParent));
    mapParentNameToItem[csParentFnameKey] = pItemParent;
  }
  else {
    TRACE("duplicate parent: %s / %s\n", pItemParent->csDisplayFname, csParFname);
    return false;
  }

  // No more to be done if we have seen this set before.
  if (!fFirstSet) {
    cF.Close();
    return true;
  }

  // This is the first set. map children in set.

  // Read file data area and init vars for loop.
  u64 iFiles = pHead[0x38 / sizeof(u64)];
  u64 iFileOffset = pHead[0x40 / sizeof(u64)];
  u64 iFileLen = pHead[0x48 / sizeof(u64)];

  u64* piFileBuf = new u64[(u32) iFileLen];
  // For delete.
  u64* piRemFileBuf = piFileBuf;
  cF.Seek((u32) iFileOffset, 0);
  cF.Read(piFileBuf, (u32) iFileLen);

  bool	fEmpty = true;

  // Record info on all files.
  u32		iFilesetPos = 1;

  while (iFiles--) {
    CVParChildItem* pItemChild = new CVParChildItem;

    // Copy filename from buffer to CString, converting from unicode at the same time.

    // TODO: Bug: filename could be longer than MAX_PATH.
    LPTSTR	str = pItemChild->csDisplayFname.GetBuffer(MAX_PATH);
    u32		iEntrySize = (u32) piFileBuf[0x00 / sizeof(u64)];
    u32 i;

    for (i = 0; i < (iEntrySize - 0x38) / sizeof(u16); i++) {
      str[i] = (s8)((u16*)piFileBuf)[(0x38 / sizeof(u16)) + i];
    }

    pItemChild->csDisplayFname.ReleaseBuffer(i);
    pItemChild->md516k.LoadMem(piFileBuf + (0x28 / sizeof(u64)));
    pItemChild->iSize = piFileBuf[0x10 / sizeof(u64)];
    pItemChild->fSavedInParity = ((piFileBuf[0x08 / sizeof(u64)] & 1) != 0);
    pItemChild->iFilesetPos = iFilesetPos++;

    // Map new child.

    // MD5 of child.
    CMd5	md5Child(piFileBuf + (0x18 / sizeof(u64)));
    pItemChild->md5 = md5Child; // TODO: This is a kludge for old parts of app.

    // This would happen if the same child is listed more than once in a set
    // (shouldn't happen).
    if (pItemSet->mapChildren.Lookup(md5Child, pItemChild)) {
      TRACE("already in pItemSet->mapChildren: %s %s\n", CString(md5Child), pItemChild->csDisplayFname);
    }
    else {
      pItemSet->mapChildren[md5Child] = pItemChild;
    }

    CString csChildFnameKey(pItemChild->csDisplayFname);
    csChildFnameKey.MakeLower();

    CVParChildItem* pItemChildJunk;

    // Happens if child name has been encountered in a parent in another set.
    if (mapChildNameToItem.Lookup(csChildFnameKey, pItemChildJunk)) {
      TRACE("already in mapChildNameToItem: %s\n", csChildFnameKey);
    }
    else {
      // TODO: This is a kludge for old parts of app.
      mapChildNameToItem[csChildFnameKey] = pItemChild;
    }

    mapChildToSet[md5Child] = md5Set;

    CVParSetItem* pItemSetJunk;

    // Happens if child name has been encountered in a parent of another set.
    if (mapChildNameToSet.Lookup(csChildFnameKey, pItemSetJunk)) {
      TRACE("already in mapChildNameToSet: %s\n", csChildFnameKey);
    }
    else {
      // TODO: This is a kludge for old parts of app.
      mapChildNameToSet[csChildFnameKey] = pItemSet;
    }

    CVParParentItem* pItemParentJunk;

    // Happens if child name has been encountered in a parent of another set.
    if (mapChildItemToParentItem.Lookup(pItemChild, pItemParentJunk)) {
      TRACE("already in mapChildItemToParentItem: %s\n", csChildFnameKey);
    }
    else {
      // TODO: This is a kludge for old parts of app.
      mapChildItemToParentItem[pItemChild] = pItemParent;
    }

    // Next file.
    piFileBuf = (u64*)(((s8*)piFileBuf) + (u32) piFileBuf[0x00 / sizeof(u64)]);
  }

  delete piRemFileBuf;

  cF.Close();

  return true;
}

// Delete all children of any parent where no children exist. If one or more
// children exist, leave all children. also see LoadFile comments.
bool CVPar::RemoveChildless(void) {
  TRACE("bool CVPar::RemoveChildless()  begin\n");

  //// Count all children of each parent.

  //CMap<CString, LPCSTR, u32, u32> mapCount;
  //POSITION pos1, pos2;
  //CString csFnameParMapKey;
  //CVParChildItem sf;
  //CVDiskCont df;
  //u32 iChildCount;

  //for (pos1 = CVPar::map.GetStartPosition(); pos1 != NULL; ) {
  //  CVPar::map.GetNextAssoc(pos1, csFnameParMapKey, sf);

  //  if (!mapCount.Lookup(sf.csParFile, iChildCount))
  //    mapCount[sf.csParFile] = 1;
  //  else
  //    mapCount[sf.csParFile] = ++iChildCount;
  //}

  //// Iterate over all PAR children and check if they exist. if one doesn't
  //// exist, remove it from PAR children map and subtract count of it's PAR
  //// parent by one. If the count becomes zero, remove all children of that
  //// parent.

  //// Iterate over all PAR children.
  //for (pos1 = CVPar::map.GetStartPosition(); pos1 != NULL;) {
  //  CVPar::map.GetNextAssoc(pos1, csFnameParMapKey, sf);

  //  if (!CVDisk::Lookup(csFnameParMapKey, &df)) {
  //    // Found PAR child that doesn't exist on disk. check if it is alone.
  //    VERIFY(mapCount.Lookup(sf.csParFile, iChildCount));
  //    mapCount[sf.csParFile] = --iChildCount;
  //    if (!iChildCount) {
  //      // Found PAR parent that contains no children anymore. delete all children.
  //      //  of that parent.
  //      CString csParParent = sf.csParFile;
  //      for (pos2 = CVPar::map.GetStartPosition(); pos2 != NULL;) {
  //        CVPar::map.GetNextAssoc(pos2, csFnameParMapKey, sf);
  //        if (sf.csParFile == csParParent)
  //          CVPar::map.RemoveKey(csFnameParMapKey);
  //      }
  //    }
  //  }
  //}

  TRACE("bool CVPar::RemoveChildless()  end\n");

  return true;
}

// GetSelect is called when virtual files need to be translated to real files.
//
// CVPar responds by adding PAR children from selected PAR parents.
bool CVPar::GetSelect(CStringList* listcsSelectedFnames, CMapStringToPtr* mapReal) {
  TRACE("CVPar::GetSelect()  begin\n");

  CVParChildItem* pItemChild;
  CString		csFnameParMapKey, csFnameKey;
  bool		fAdded = false;

  // Iterate over names of files that have been selected.
  POSITION	posSelectedFiles = listcsSelectedFnames->GetHeadPosition();

  while (posSelectedFiles != NULL) {
    CString csSelectedFname = listcsSelectedFnames->GetNext(posSelectedFiles);
    CString csSelectedFnameKey = csSelectedFname;
    csSelectedFnameKey.MakeLower();

    // If file is child of any PAR parent, add it. (makes it possible to select
    // "par only" files).
    if (mapChildNameToItem.Lookup(csSelectedFnameKey, pItemChild)) {
      (*mapReal)[csSelectedFname] = NULL;
      fAdded = true;

      TRACE("Added: %s\n", csSelectedFname);
    }

    // Check if file is PAR parent. if it is, add all children of this parent.
    CString csFirstFnameKey, csLastFnameKey;

    // Add children if PAR or Pxx file.
    if (SplitPAR(csSelectedFnameKey, &csFirstFnameKey, &csLastFnameKey)) {
      CVParSetItem* pItemSet;

      if (mapParentNameToSet.Lookup(csSelectedFnameKey, pItemSet)) {
        CMd5		md5Child;
        POSITION	posChildren = pItemSet->mapChildren.GetStartPosition();

        while (posChildren != NULL) {
          pItemSet->mapChildren.GetNextAssoc(posChildren, md5Child, pItemChild);
          (*mapReal)[pItemChild->csDisplayFname] = NULL;
          fAdded = true;
        }
      }
    }
  }

  TRACE("CVPar::GetSelect()  end\n");

  return fAdded;
}

/*
Restore as many sets as possible.
*/
bool CVPar::RestoreAllSets(void) {
  CVParSetItem* pItemSet;
  CMd5	md5Junk;

  threadDuplicates = AfxBeginThread(RUNTIME_CLASS(CDuplicatesThread), THREAD_PRIORITY_ABOVE_NORMAL);

  POSITION	posMapSet = mapSets.GetStartPosition();

  while (posMapSet != NULL) {
    mapSets.GetNextAssoc(posMapSet, md5Junk, pItemSet);
    RestoreSet(pItemSet);
  }

  return true;
}

/*
Restore a set based on child name.
*/
bool CVPar::RestoreChild(CString csChildFname) {
  CVParSetItem* pItemSet;
  CString csChildFnameKey(csChildFname);
  csChildFnameKey.MakeLower();

  threadDuplicates = AfxBeginThread(RUNTIME_CLASS(CDuplicatesThread), THREAD_PRIORITY_ABOVE_NORMAL);

  if (!mapChildNameToSet.Lookup(csChildFnameKey, pItemSet)) {
    // Abort if no set found.
    CString csMsg;
    csMsg.Format("No Set found for file %s", csChildFname);
    AfxMessageBox(csMsg);
    return false;
  }

  return RestoreSet(pItemSet);
}

/*
Helper for ProcessDuplicates()
*/
bool CVPar::PostString(CWinThread* thread, CString csMsg) {
  TRACE(csMsg);

  CString* csTransfer = new CString;
  *csTransfer = csMsg;
  thread->PostThreadMessage(UWM_ADDSTR, (WPARAM) csTransfer, 0);

  return true;
}

/*
Given the name of a random file in a set that is covered by
a PAR set, restore all broken/missing files in that set.
(Provided that enough Pxx files exist).
*/
bool CVPar::RestoreSet(CVParSetItem* pItemSet) {
  u16			fnrs[1000];
  afile		in[1000], out[1000];

  CVParChildItem* pItemChild;
  CVParParentItem* pItemParent;
  CMd5		md5Junk, md5Parent;
  CFileStatus fileStat;
  CVDiskCont	df;
  u32			k = 0, l = 0;
  CFile* cf;
  CString		csMsg;
  bool		fFailed = false;

  int i;

  for (i = 0; i < pItemSet->mapChildren.GetCount(); i++) {
    fnrs[i] = i + 1;
  }

  fnrs[i] = 0;

  csMsg.Format("Checking set %s\n", pItemSet->csName);
  PostString(threadDuplicates, csMsg);

  // Create table of all input filenames involved in the restore operation.

  // Verify md5 of all the input files.

  // Create table of all ouput filenames involved in the restore operation.

  // Open all files and create tables on the form DoRestore wants them.
  POSITION	posMapChildren = pItemSet->mapChildren.GetStartPosition();
  POSITION	posMapParents = pItemSet->mapParents.GetStartPosition();

  while (posMapChildren != NULL) {
    pItemSet->mapChildren.GetNextAssoc(posMapChildren, md5Junk, pItemChild);

    // Has to be saved in parity to be part of restore operation.
    if (pItemChild->fSavedInParity) {
      // Check if file exists and is healthy.
      if
      (
        CVDisk::Lookup(pItemChild->csDisplayFname, &df) // file exists and ...
        &&	df.iCrcStatus == CRCSTATUS_CALCULATED			// md5 has been calculated and ..
        &&	df.md5 == pItemChild->md5 // md5 matches
      ) {
        // File is healthy. Add it to input array.
        cf = new CFile;

        if (!cf->Open(GetWorkingFolder() + pItemChild->csDisplayFname, CFile::modeRead)) {
          csMsg.Format("Couldn't open %s. Cause: %s\n", pItemChild->csDisplayFname, MyGetLastError());
          PostString(threadDuplicates, csMsg);
          fFailed = true;
          break;
        }

        in[k].filenr = pItemChild->iFilesetPos;
        in[k].files = NULL;
        in[k].size = pItemChild->iSize;
        in[k].cf = cf;
      }
      else {
        // Child is not healthy. Add it to output array.
        cf = new CFile;

        if (!cf->Open(GetWorkingFolder() + pItemChild->csDisplayFname, CFile::modeWrite | CFile::modeCreate)) {
          csMsg.Format("Couldn't open %s for writing.", pItemChild->csDisplayFname);
          LastErrorMessageBox(csMsg);
          fFailed = true;
          break;
        }

        out[l].filenr = pItemChild->iFilesetPos;
        out[l].files = NULL;
        out[l].size = pItemChild->iSize;
        out[l].cf = cf;
        l++;

        // Add a parent with parity (Pxx) to input.

        // Find new parent.
        bool fNotMd5ed = false, fOnDisk, fNoMoreParents = false;

        do {
          if (posMapParents == NULL) {
            fNoMoreParents = true;
            break;
          }

          pItemSet->mapParents.GetNextAssoc(posMapParents, md5Parent, pItemParent);
          fOnDisk = CVDisk::Lookup(pItemParent->csDisplayFname, &df);

          // Turn on flag for more text if skipped parents because they weren't md5'ed.
          if (fOnDisk && df.iCrcStatus < CRCSTATUS_CALCULATED) {
            fNotMd5ed = true;
          }
        }
        while
        ( // find new parent if this parent...
          (
            !fOnDisk	// (didn't exists on disk OR
            ||	df.iCrcStatus < CRCSTATUS_CALCULATED	// has not been md5'ed OR
            ||	(df.iCrcStatus == CRCSTATUS_CALCULATED && pItemParent->md5 != df.md5)	// ... has been md5'ed but md5 is not correct OR
            ||	pItemParent->iVolumePos == 0 // ... contains no parity data.
          )
        );

        if (fNoMoreParents) {
          if (fNotMd5ed) {
            PostString
            (
              threadDuplicates,
              "Need more parents to fix this set. One or more parents were ignored because their\n"
            );
            PostString
            (
              threadDuplicates,
              "checksums have not been verified yet. Please run checksums and then try again\n"
            );
          }
          else {
            PostString(threadDuplicates, "Need more parents to fix this set.\n");
          }

          fFailed = true;
          break;
        }

        // Add the parent.
        cf = new CFile;

        if (!cf->Open(GetWorkingFolder() + pItemParent->csDisplayFname, CFile::modeRead)) {
          csMsg.Format("Couldn't open %s. Cause: %s\n", pItemParent->csDisplayFname, MyGetLastError());
          PostString(threadDuplicates, csMsg);
          fFailed = true;
          break;
        }

        cf->Seek((u32) pItemParent->iParityOffset, 0);

        in[k].filenr = pItemParent->iVolumePos;
        in[k].files = fnrs;
        in[k].size = pItemParent->iParitySize;
        in[k].cf = cf;

        csMsg.Format("Restoring child %s using %s\n", pItemChild->csDisplayFname, pItemParent->csDisplayFname);
        PostString(threadDuplicates, csMsg);
      }

      k++;
    }
  }

  in[k].filenr = 0;
  out[l].filenr = 0;

  // DoRestore.

  // Any out-files?
  if (l == 0) {
    PostString(threadDuplicates, "No errors found in set\n");
  }
  else {
    // Enough pxx files?
    if (!fFailed) {
      if (DoRestore(in, out)) {
        PostString(threadDuplicates, "Restored set\n");
      }
      else {
        PostString(threadDuplicates, "Restore of set FAILED\n");
      }
    }
    else {
      PostString(threadDuplicates, "Restore not attempted\n");
    }
  }

  // Close all files and delete cFile objects.
  for (k = 0; in[k].filenr; k++) {
    try {
      in[k].cf->Close();
      // Destructor closes file if it was open.
      delete in[k].cf;
    }

    catch (...) {
    }
  }

  for (k = 0; out[k].filenr; k++) {
    try {
      CString csFname;

      if (!out[k].cf->GetLength()) {
        csFname = out[k].cf->GetFileName();
      }

      out[k].cf->Close();

      if (csFname != "") {
        CFile::Remove(GetWorkingFolder() + csFname);
      }

      // Destructor closes file if it was open.
      delete out[k].cf;
    }

    catch (...) {
    }
  }

  return true;
}



// Some utility macros.
#define HEXDIGIT(i)			(((i) + (((i) < 0xA) ? '0' : ('a' - 0xA))))
#define NEW(ptr, size)		((ptr) = (u8 *) (malloc(sizeof(*(ptr)) * (size))))
#define CNEW(ptr, size)		((ptr) = (u8 *) (calloc(sizeof(*(ptr)), (size))))
#define RENEW(ptr, size)	((ptr) = (realloc((ptr), sizeof(*(ptr)) * (size))))
#define COPY(tgt, src, nel) (memcpy((tgt), (src), ((nel) * sizeof(*(tgt)))))

s64 file_read(CFile* cf, void* buf, s64 n) {
  s64 i;

  i = cf->Read(buf, (u32) n);

  //	if (!f) return 0;

  /*	if (do_open(f) < 0)
  return 0;
  i = fread(buf, 1, n, f->f);
  if (i > 0) {
  f->off += i;
  f->s_off = f->off;
  }
  */
  return i;
}

/* */
s64 file_write(CFile* cf, void* buf, s64 n) {
  //	s64 i;
  cf->Write(buf, (u32) n);

  /*	if (!f) return 0;
  if (do_open(f) < 0)
  return 0;
  i = fwrite(buf, 1, n, f->f);
  if (i > 0) {
  f->off += i;
  f->s_off = f->off;
  }
  */
  return n;
}

// Calculations over a Galois Field, GF(8).
u8	gl[0x100], ge[0x200];

// Multiply: a*b = exp(log(a) + log(b)).
static int gmul(int a, int b) {
  if ((a == 0) || (b == 0)) {
    return 0;
  }

  return ge[gl[a] + gl[b]];
}

// Divide: a/b = exp(log(a) - log(b)).
static int gdiv(int a, int b) {
  if ((a == 0) || (b == 0)) {
    return 0;
  }

  return ge[gl[a] - gl[b] + 255];
}

// Power: a^b = exp(log(a) * b).
static int gpow(int a, int b) {
  if (a == 0) {
    return 0;
  }

  return ge[(gl[a] * b) % 255];
}

// Initialise log and exp tables using generator x^8 + x^4 + x^3 + x^2 + 1.
void ginit(void) {
  unsigned int	b, l;

  b = 1;

  for (l = 0; l < 0xff; l++) {
    gl[b] = l;
    ge[l] = b;
    b += b;

    if (b & 0x100) {
      b ^= 0x11d;
    }
  }

  for (l = 0xff; l < 0x200; l++) {
    ge[l] = ge[l - 0xff];
  }
}

// Fill in a LUT.
static void make_lut(u8 lut[0x100], int m) {
  int j;

  for (j = 0x100; --j;) {
    lut[j] = ge[gl[m] + gl[j]];
  }

  lut[0] = 0;
}

#define MT(i, j)	(mt[((i) * Q) + (j)])
#define IMT(i, j)	(imt[((i) * N) + (j)])
#define MULS(i, j)	(muls[((i) * N) + (j)])

/* */
bool CVPar::DoRestore(afile* in, afile* out) {
  int		i, j, k, l, M, N, Q, R;
  u8* mt, *imt, *muls;
  u8		buf[512 * 1024], *work;
  s64		s, size;
  s64		perc;
  CString csMsg;

  ginit();

  // Count number of recovery files.
  for (i = Q = R = 0; in[i].filenr; i++) {
    if (in[i].files) {
      R++;

      // Get max. matrix row size.
      for (k = 0; in[i].files[k]; k++) {
        if (in[i].files[k] > Q) {
          Q = in[i].files[k];
        }
      }
    }
    else {
      if (in[i].filenr > Q) {
        Q = in[i].filenr;
      }
    }
  }

  N = i;

  // Count number of volumes to output.
  for (i = j = M = 0; out[i].filenr; i++) {
    M++;

    if (out[i].files) {
      j++;

      // Get max. matrix row size.
      for (k = 0; out[i].files[k]; k++) {
        if (out[i].files[k] > Q) {
          Q = out[i].files[k];
        }
      }
    }
    else {
      if (out[i].filenr > Q) {
        Q = out[i].filenr;
      }
    }
  }

  R += j;
  Q += j;

  CNEW(mt, R * Q);
  CNEW(imt, R * N);

  // Fill in matrix rows for recovery files.
  for (i = j = 0; in[i].filenr; i++) {
    if (!in[i].files) {
      continue;
    }

    for (k = 0; in[i].files[k]; k++) {
      MT(j, in[i].files[k] - 1) = gpow(k + 1, in[i].filenr - 1);
    }

    IMT(j, i) = 1;
    j++;
  }

  // Fill in matrix rows for output recovery files.
  for (i = 0, l = Q; out[i].filenr; i++) {
    if (!out[i].files) {
      continue;
    }

    for (k = 0; out[i].files[k]; k++) {
      MT(j, out[i].files[k] - 1) = gpow(k + 1, out[i].filenr - 1);
    }

    --l;

    // Fudge filenr.
    out[i].filenr = l + 1;
    MT(j, l) = 1;
    j++;
  }

  // LOG.

  /*	TRACE("Matrix input:\n");
  for (i = 0; i < R; i++) {
  TRACE("| ");
  for (j = 0; j < Q; j++)
  TRACE("%02x ", MT(i, j));
  TRACE("| ");
  for (j = 0; j < N; j++)
  TRACE("%02x ", IMT(i, j));
  TRACE("|\n");
  }
  */

  // Use (virtual) rows from data files to eliminate columns.
  for (i = 0; in[i].filenr; i++) {
    if (in[i].files) {
      continue;
    }

    k = in[i].filenr - 1;

    // MT would have a 1 at (i, k), IMT a 1 at (i, i).

    // IMT(j,i) -= MT(j,k) * IMT(i,i)  (is MT(j, k)).

    //  MT(j,k) -= MT(j,k) *  MT(i,k)  (becomes 0).
    for (j = 0; j < R; j++) {
      IMT(j, i) ^= MT(j, k);
      MT(j, k) = 0;
    }
  }

  // LOG.

  /*	TRACE("Matrix after data file elimination:\n");
  for (i = 0; i < R; i++) {
  TRACE("| ");
  for (j = 0; j < Q; j++)
  TRACE("%02x ", MT(i, j));
  TRACE("| ");
  for (j = 0; j < N; j++)
  TRACE("%02x ", IMT(i, j));
  TRACE("|\n");
  }
  */

  // Eliminate columns using the remaining rows, so we get I..

  // The accompanying matrix will be the inverse.
  for (i = 0; i < R; i++) {
    int d, l;

    // Find first non-zero entry.
    for (l = 0; (l < Q) && !MT(i, l); l++) {
      ;
    }

    if (l == Q) {
      continue;
    }

    d = MT(i, l);

    // Scale the matrix so MT(i, l) becomes 1.
    for (j = 0; j < Q; j++) {
      MT(i, j) = gdiv(MT(i, j), d);
    }

    for (j = 0; j < N; j++) {
      IMT(i, j) = gdiv(IMT(i, j), d);
    }

    // Eliminate the column in the other matrices.
    for (k = 0; k < R; k++) {
      if (k == i) {
        continue;
      }

      d = MT(k, l);

      for (j = 0; j < Q; j++) {
        MT(k, j) ^= gmul(MT(i, j), d);
      }

      for (j = 0; j < N; j++) {
        IMT(k, j) ^= gmul(IMT(i, j), d);
      }
    }
  }

  /*	TRACE("Matrix after gaussian elimination:\n");
  for (i = 0; i < R; i++) {
  TRACE("| ");
  for (j = 0; j < Q; j++)
  TRACE("%02x ", MT(i, j));
  TRACE("| ");
  for (j = 0; j < N; j++)
  TRACE("%02x ", IMT(i, j));
  TRACE("|\n");
  }
  */

  // Make the multiplication tables.
  CNEW(muls, M * N);

  for (i = 0; out[i].filenr; i++) {
    // File #x: The row IMT(j) for which MT(j,x) = 1.
    for (j = 0; j < R; j++) {
      k = out[i].filenr - 1;

      if (MT(j, k) != 1) {
        continue;
      }

      // All other values should be 0.
      for (k = 0; !MT(j, k); k++) {
        ;
      }

      if (k != out[i].filenr - 1) {
        continue;
      }

      for (k++; (k < Q) && !MT(j, k); k++) {
        ;
      }

      if (k != Q) {
        continue;
      }

      break;
    }

    // Did we find a suitable row ?
    if (j == R) {
      out[i].size = 0;
      continue;
    }

    for (k = 0; k < N; k++) {
      MULS(i, k) = IMT(j, k);
    }
  }

  free(mt);
  free(imt);

  // LOG.

  /*	TRACE("Multipliers:\n");
  for (i = 0; i < M; i++) {
  TRACE("| ");
  for (j = 0; j < N; j++)
  TRACE("%02x ", MULS(i, j));
  TRACE("|\n");
  }
  */

  // Check for columns with all-zeroes.
  for (j = 0; j < N; j++) {
    for (i = 0; i < M; i++)
      if (MULS(i, j)) {
        break;
      }

    // This input file isn't used.
    if (i == M) {
      in[j].size = 0;
    }
  }

  // Find out how much we should process in total.
  size = 0;

  for (i = 0; out[i].filenr; i++)
    if (size < out[i].size) {
      size = out[i].size;
    }

  // Restore all the files at once.
  NEW(work, sizeof(buf) * M);

  perc = 0;
  PostString(threadDuplicates, "0%");

  // Process all files.
  for (s = 0; s < size;) {
    s64 tr, r, q;
    u8* p;

    // Display progress.
    while (((s * 50) / size) > perc) {
      perc++;

      if (perc % 5) {
        PostString(threadDuplicates, ".");
      }
      else {
        csMsg.Format("%d%%", (perc / 5) * 10);
        PostString(threadDuplicates, csMsg);
      }
    }

    // See how much we should read.
    memset(work, 0, sizeof(buf) * M);

    for (i = 0; in[i].filenr; i++) {
      tr = sizeof(buf);

      if (tr > (in[i].size - s)) {
        tr = in[i].size - s;
      }

      if (tr <= 0) {
        continue;
      }

      r = file_read(in[i].cf, buf, tr);

      if (r < tr) {
        PostString(threadDuplicates, "READ ERROR");
        free(muls);
        free(work);
        return 0;
      }

      for (j = 0; out[j].filenr; j++) {
        u8	lut[0x100];

        if (s >= out[j].size) {
          continue;
        }

        if (!MULS(j, i)) {
          continue;
        }

        // Precalc LUT.
        make_lut(lut, MULS(j, i));
        p = work + (j * sizeof(buf));

        // XOR it in, passed through the LUTs.
        for (q = r; --q >= 0;) {
          p[q] ^= lut[buf[q]];
        }
      }
    }

    for (j = 0; out[j].filenr; j++) {
      if (s >= out[j].size) {
        continue;
      }

      tr = sizeof(buf);

      if (tr > (out[j].size - s)) {
        tr = out[j].size - s;
      }

      r = file_write(out[j].cf, work + (j * sizeof(buf)), tr);

      if (r < tr) {
        PostString(threadDuplicates, "WRITE ERROR");
        free(muls);
        free(work);
        return 0;
      }
    }

    s += sizeof(buf);
  }

  PostString(threadDuplicates, "100%\n");
  free(muls);
  free(work);
  return 1;
}
