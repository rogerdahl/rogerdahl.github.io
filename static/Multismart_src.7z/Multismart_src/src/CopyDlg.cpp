#include "stdafx.h"
#include "Multismart.h"
#include "CopyDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CCopyDlg::CCopyDlg(CWnd* pParent /*=NULL*/)
  : CDialog(CCopyDlg::IDD, pParent) {
  chk_nomore = FALSE;
  radio_existing = -1;
}

void CCopyDlg::DoDataExchange(CDataExchange* pDX) {
  CDialog::DoDataExchange(pDX);
  DDX_Control(pDX, id_pic_question, pic_question);
  DDX_Check(pDX, id_chk_nomore, chk_nomore);
  DDX_Radio(pDX, id_radio_existing, radio_existing);
}

BEGIN_MESSAGE_MAP(CCopyDlg, CDialog)
END_MESSAGE_MAP()


// CCopyDlg message handlers.

BOOL CCopyDlg::OnInitDialog()  {
  CDialog::OnInitDialog();

  // Init icon.

  HICON h = LoadIcon(NULL, IDI_QUESTION);
  pic_question.SetIcon(h);

  // Init radio buttons.

  HKEY	myhnd;
  DWORD	num, dsize = sizeof(num);

  RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\dahlsys\\multismart", 0, KEY_READ, &myhnd);

  if (RegQueryValueEx(myhnd, "radio_copy_select", NULL, NULL, (BYTE*)&num, &dsize) == ERROR_SUCCESS) {
    radio_existing = num;
  }
  else {
    radio_existing = 0;
  }

  UpdateData(false);

  // return TRUE unless you set the focus to a control
  return TRUE;
}

INT_PTR CCopyDlg::DoModal()  {
  /*
  	set radio_existing to value stored in registry and return IDOK
  	if dialog has been disabled
  */
  HKEY	myhnd;
  DWORD	num, dsize = sizeof(num);

  RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\dahlsys\\multismart", 0, KEY_READ, &myhnd);

  if (RegQueryValueEx(myhnd, "chk_hide_copy_select", NULL, NULL, (BYTE*)&num, &dsize) == ERROR_SUCCESS) {
    if (RegQueryValueEx(myhnd, "radio_copy_select", NULL, NULL, (BYTE*)&num, &dsize) == ERROR_SUCCESS) {
      radio_existing = num;
    }
    else {
      ASSERT(false);
    }

    return IDOK;
  }

  return CDialog::DoModal();
}

void CCopyDlg::OnOK()  {
  UpdateData(true);

  HKEY	myhnd;
  DWORD	num, dsize = sizeof(num);

  RegCreateKeyEx(HKEY_CURRENT_USER, "Software\\dahlsys\\multismart", 0, " ",
                 REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS | KEY_WRITE, NULL, &myhnd, NULL);

  if (chk_nomore) {
    // User selected to remove confirmation from now on so create registry key.
    num = 1;
    RegSetValueEx(myhnd, "chk_hide_copy_select", 0, REG_DWORD, (BYTE*)&num, dsize);
  }

  num = radio_existing;
  RegSetValueEx(myhnd, "radio_copy_select", 0, REG_DWORD, (BYTE*)&num, dsize);

  CDialog::OnOK();
}
