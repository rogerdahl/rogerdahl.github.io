#pragma once

template<class T> class CFifoItem {
  public:
    CFifoItem() {
      nextFifoItem = NULL;
      previousFifoItem = NULL;
      userItem =  NULL;
    };
    ~CFifoItem() {};

  public:
    void setNext(CFifoItem<T>* n) {
      nextFifoItem  =  n;
    };
    void SetuserItem(T v) {
      userItem  =  v;
    };
    void setPrevious(CFifoItem<T>* n) {
      previousFifoItem  =  n;
    };
    CFifoItem<T>* GetNext() {
      return(nextFifoItem);
    };
    CFifoItem<T>* GetPrevious() {
      return(previousFifoItem);
    };
    T GetValue() {
      return(userItem);
    };

  private:
    CFifoItem<T>* nextFifoItem;
    CFifoItem<T>* previousFifoItem;
    T userItem;
};

template<class T> class CFifo {
  public:
    CFifo();
    ~CFifo();

    void Put(T item);
    void PutFirst(T item);
    T Get(); // retrieve and remove
    bool IsEmpty();

    void RemoveAll();
    u32 GetSize();

  private:
    CFifoItem<T>* pFirstFifoItem;
    CFifoItem<T>* pLastFifoItem;
    u32 nItems;
};

template<class T> CFifo<T>::CFifo() {
  pFirstFifoItem = NULL;
  pLastFifoItem = NULL;
  nItems = 0;
}

template<class T> CFifo<T>::~CFifo() {
  RemoveAll();
}

template<class T>T CFifo<T>::Get() {
  CFifoItem<T>* fifoItem;
  T userItem;
  fifoItem = pFirstFifoItem;

  if (pFirstFifoItem == NULL) {
    userItem = NULL;
  }
  else {
    userItem = fifoItem->GetValue();
    pFirstFifoItem = fifoItem->GetNext();

    if (pFirstFifoItem != NULL) {
      pFirstFifoItem->setPrevious(NULL);
    }
    else {
      pFirstFifoItem = NULL;
      pLastFifoItem = NULL;
    }

    nItems--;
    delete(fifoItem);
  }

  return userItem;
}

template<class T> void CFifo<T>::Put(T userItem) {
  CFifoItem<T>* fifoItem = new CFifoItem<T>;
  fifoItem->SetuserItem(userItem);

  if (pFirstFifoItem == NULL) {
    pFirstFifoItem = fifoItem;
    pLastFifoItem = fifoItem;
  }
  else {
    pLastFifoItem->setNext(fifoItem);
    fifoItem->setPrevious(pLastFifoItem);
    fifoItem->setNext(NULL);
    pLastFifoItem = fifoItem;
  }

  nItems++;
}

/*
	Sneak in the line.
*/
template<class T> void CFifo<T>::PutFirst(T userItem) {
  CFifoItem<T>* fifoItem = new CFifoItem<T>;
  fifoItem->SetuserItem(userItem);

  if (pFirstFifoItem == NULL) {
    pFirstFifoItem = fifoItem;
    pLastFifoItem = fifoItem;
  }
  else {
    pFirstFifoItem->setPrevious(fifoItem);
    fifoItem->setPrevious(NULL);
    fifoItem->setNext(pFirstFifoItem);
    pFirstFifoItem = fifoItem;
  }

  nItems++;
}

template<class T> bool CFifo<T>::IsEmpty() {
  return pFirstFifoItem == NULL;
}

template<class T> void CFifo<T>::RemoveAll() {
  CFifoItem<T>* fifoItem;
  CFifoItem<T>* nextItem;
  fifoItem = pFirstFifoItem;

  while (fifoItem != NULL) {
    nextItem = fifoItem->GetNext();
    delete fifoItem;
    fifoItem = nextItem;
  }

  pFirstFifoItem = NULL;
  pLastFifoItem = NULL;
  nItems = 0;
}

template<class T> u32 CFifo<T>::GetSize() {
  return nItems;
}

/*
	code for copying the fifo buffer. can't imagine that I would ever want to do that

template<class T> CFifo<T> &CFifo<T>::operator = (const CFifo<T> &q)
{
	Clear();
	copy(q);
}

template<class T> void CFifo<T>::copy(const CFifo<T> &q)
{
	CFifoItem<T> *item;
	CFifoItem<T> *n;
	CFifoItem<T> *prev;
	item = q.first;
	prev = NULL;
	while (item != NULL)
	{
		nItems++;
		n = new CFifoItem<T>();
		n->SetuserItem(item->GetValue());
		n->setPrevious(prev);
		if (prev != NULL)
		{
			prev->setNext(n);
		}
		if (first == NULL)
		{
			first = n;
		}
		last = n;
		prev = n;
		item = item->GetNext();
	}
}
*/
