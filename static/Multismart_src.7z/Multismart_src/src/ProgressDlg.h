#pragma once


// CProgressDlg dialog.

class CProgressDlg : public CDialog {
  public:
    // Standard constructor.
    CProgressDlg(CWnd* pParent = NULL);

    // Dialog Data.
    enum { IDD = id_dlg_progress };
    CStatic	static_message;
    CProgressCtrl	progress_loading;

    // Overrides.
  protected:
    // DDX/DDV support.
    virtual void DoDataExchange(CDataExchange* pDX);
    virtual void PostNcDestroy();

    // Implementation.
  protected:
    // Generated message map functions.
    DECLARE_MESSAGE_MAP()
};
