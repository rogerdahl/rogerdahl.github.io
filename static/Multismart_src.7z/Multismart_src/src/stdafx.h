#pragma once

// Exclude rarely-used stuff from Windows headers
#define VC_EXTRALEAN

#include "targetver.h"

// MFC core and standard components
#include <afxwin.h>
// MFC extensions
#include <afxext.h>
// MFC Automation classes
#include <afxdisp.h>
// MFC support for Internet Explorer 4 Common Controls
#include <afxdtctl.h>

#include <afxcview.h>

#ifndef _AFX_NO_AFXCMN_SUPPORT
// MFC support for Windows Common Controls
#include <afxcmn.h>
#endif // _AFX_NO_AFXCMN_SUPPORT

// MFC socket extensions
#include <afxsock.h>

#include <afxtempl.h>
#include <afxmt.h>
#include <mshtml.h>
#include "int_types.h"

// App.

#include "global.h"

// Boost.

#include <boost/regex.hpp>
// High Level Class RegEx (Deprecated)
#include <boost/cregex.hpp>
