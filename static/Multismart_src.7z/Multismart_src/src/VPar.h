#pragma once

#include "VSfv.h"
#include "md5.h"

// Notes about how this class stores PAR info:
//
// PAR info is stored in sets. Each set contains a map of all parents (PAR and
// Pxx files) and a map of all children (files listed in PAR and Pxx files) that
// belong to one set. The sets are then stored in a map of sets.
//
// Because the sets are big and contain other maps, I didn't want to put the
// entire sets in the maps. That would have caused implicit copying around of a
// lot of data and I would have had to write my own assignment operator since
// the one that is created by default by the compiler only does a shallow copy.
//
// So I 'new' the sets and the parent and child items and map the pointers. I
// manually 'delete' all 'new'ed objects before destroying the container.
//
// I also have some other maps to create "shortcuts" for some types of
// information, so that fewer iterations of entire maps need to be done.

// Key is MD5 of PAR parent, from 0x20 to end.
class CVParParentItem {
  public:
    CString	csDisplayFname; // filename of PAR parent
    CMd5 md5; // MD5 hash of whole file from byte 0x20. *kludge* for old parts of app
    u32 iVolumePos; // the number of the parity volume 0 for PAR, 1 for .p01, 2 for .p02 etc.
    u64 iParityOffset; // where the parity information starts
    u64 iParitySize; // size of parity information
};

// Key is MD5 hash of whole file.
class CVParChildItem {
  public:
    CString csDisplayFname; // filename of file (key is lower case)
    CMd5 md5; // MD5 hash of whole file. *kludge* for old parts of app
    CMd5 md516k; // MD5 hash of first 16384 bytes of file
    u64 iSize; // size of file
    bool fSavedInParity; // file saved in parity volume set
    //			bool fCheckedSuccessfully;// file is checked successfully
    u32 iFilesetPos; // position of file in set
};

// Key is Set MD5 (MD5 for entire PAR set).
class CVParSetItem {
  public:
    CString csName; // name of parity set
    u32 iParitySets; // how many of the CVParParentItems contain parity data
    // Map of all parents in set. OWNER of CVParParentItem.
    CMap<CMd5, CMd5&, CVParParentItem*, CVParParentItem*> mapParents;
    // Map of all children in set. OWNER of CVParChildItem.
    CMap<CMd5, CMd5&, CVParChildItem*, CVParChildItem*> mapChildren;
};

class CVPar : public CVSfv {
  public:
    CVPar();
    virtual ~CVPar();
    void ContainerCleanup(void);

    bool PostString(CWinThread* thread, CString csMsg);
    bool RestoreAllSets();
    bool RestoreChild(CString csChildFname);
    bool RestoreSet(CVParSetItem* pItemSet);

    bool LoadFolder(bool fQuick);
    bool LoadParFiles();
    bool LoadFile(CString csFile);
    bool RemoveChildless();
    bool GetSelect(CStringList* csFnames, CMapStringToPtr* mapReal);

    CMap<CMd5, CMd5&, CVParSetItem*, CVParSetItem*> mapSets; // OWNER of CVParSetItem items
    CMap<CMd5, CMd5&, CMd5, CMd5&> mapParentToSet; // given parent, find set
    CMap<CMd5, CMd5&, CMd5, CMd5&> mapChildToSet; // given child, find set
    /*
    because the rest of this application is based on the (older) idea of grouping by
    filenames, I need to provide a way to quickly find info from names.
    this should become unnecessary later
    */
    CMap<CString, LPCSTR, CVParSetItem*, CVParSetItem*&> mapParentNameToSet; // key is lower case full name
    CMap<CString, LPCSTR, CVParSetItem*, CVParSetItem*&> mapChildNameToSet; // key is lower case full name
    CMap<CString, LPCSTR, CVParChildItem*, CVParChildItem*&> mapChildNameToItem; // key is lower case full name
    CMap<CString, LPCSTR, CVParParentItem*, CVParParentItem*&> mapParentNameToItem; // key is lower case full name
    CMap<CVParChildItem*, CVParChildItem*, CVParParentItem*, CVParParentItem*&> mapChildItemToParentItem; // map child to first parent it was found in
  private:
    virtual bool ProgressStart() = 0;
    virtual bool ProgressStop() = 0;
    virtual bool ProgressSet(CString, u32) = 0;
    virtual void PostMessageView(u32, WPARAM, LPARAM) = 0;
    virtual CString GetWorkingFolder() = 0;

    CWinThread* threadDuplicates;

    struct afile {
      s64 size; // size of file if child and size of parity data if parent
      CFile* cf; // open file object, seeked to start of parity data if parent
      u16 filenr; // sequence number of child or parent
      u16* files; // pointer to array of file positions (doesn't contain any info. 4 files give 1, 2, 3, 4)
    };

    bool DoRestore(afile* in, afile* out);
};

// PAR storage demands:
//
// - (1) Given any CHILD MD5, find all PARENTS for SET (and quickly find # of
//   parents).
// - (2) Given any CHILD MD5, find all CHILDREN in SET (and quickly find # of
//   children).
// - (3) Given any CHILD NAME, quickly fin the same things, with error if more
//   than one set exists.
//
// Solve 1 and 2 by:
//
// - Calculate MD5 of child, look up child and find parent md5.
// - Look up parent and find set MD5.
// - Look up set and find maps of all parents and all children.
//
// Solve 3 by:
//
// - Mapping child MD5 to SET md5.
//
// Logic:
//	open new parent
//	if first of set
//		create a new set and put all children in it
//		put this parent in it
//		add parent md5 -> set md5 to mapParentToSet
//		add child Md5 -> set md5 to mapChildToSet
//	else
//		put this parent in it
//		add parent md5 -> set md5 to mapParentToSet
//	end if
