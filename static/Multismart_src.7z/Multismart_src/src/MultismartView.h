#pragma once

#include "DuplicatesDlg.h"
#include "DuplicatesConfirmDlg.h"
#include "ProgressThread.h"

#include "MultismartDoc.h"

class CMainFrame;

// Message definitions. Use "random" number to minize the risk of picking up
// broadcasts from other apps. This is the quick and dirty way. The best way is
// to register messages with names based on GUIDs
#define UWM_NEWFILESTATUS (WM_APP + 1841)
#define UWM_DONECRC (WM_APP + 1842)

// The key to desciding if a piece of data should reside in View or Doc will
// probably always be: Will that piece of data be different for two different
// Views of the Doc.
class CVFile {
  public:
    COLORREF color;
    CString csTypeText;
    CString csDate;
    CString csSize;
    CString csStatusText;
    CString csInfo1;
    CString csInfo2;
};

// CVDisplay is the container for for all the container classes. The containers
// are as follows. Each inherits from the one above.
//
// - CVDisk
// - CVDescr
// - CVSfv
// - CVPar
// - CVHighest
// - CVGap
// - CVRarInfo
//
// - CVDisplay
//
// ABOUT THE WAY THE CLASS HIERARCHY IS LAID OUT IN THIS PROJECT
//
// The *Files classes above are containers of the information displayed in the
// CVDisplay class. The way I first implemented this was that I used a map as
// base class for each of the *Files classes, and then I instantiated the
// classes inside CVDisplay. I then had an init function in each class that I
// called with pointers to all the other classes, so that the classes could talk
// together. I also had a Load function to call the main Load function of each
// class. This function took care of loading the classes they way they have to
// be loaded which is from the "ground up".
//
// As the project grew more complex, more interaction was required between the
// classes, and also I thought the Load and Init functions were inelegant and
// prone to error. So I decided to try to set up another class hierarchy. I
// based it on multiple inheritance (MI) where each class was based on a map and
// the *Files class "above" it. This would have worked fine, but for the thing I
// didn't know: MFC does not support MI very well, and I was not able to resolve
// the error messages I got, though it is supposed to be possible to do it. I
// didn't know enough C++ to do this.
//
// So I changed the structure in such a way that each single class has a map as
// one member, and inherits from the class "above" it. This worked, but the code
// is now filled with statements such as
//
// mapFiles.CVSfv::map.GetStartPosition();
//
// Needed to reach the different maps in the different classes. Now, there is no
// need for an Init function, and the Load function first calls Load in the
// class above it before it loads it's own class.
//
// Maybe this is better than the way it was at first. I don't know.
//
// --
//
// Made another attempt at using MI, and this time it seems to work, even though
// I don't know what I did different from trying the first time, and I did not
// implement any of the MS' suggestions on making it work.

class CMultismartView : public CListView {
  // Create from serialization only.
  protected:
    CMultismartView();
    DECLARE_DYNCREATE(CMultismartView)
  public:
    virtual ~CMultismartView();

    CMultismartDoc* GetDocument();

    bool RequestSelected();
    u64 GetTotal();

    virtual void DrawItem(LPDRAWITEMSTRUCT lpDIS);

    // Gen.
    bool Refresh(bool fQuick);
    bool VirtualFileState(CString csFname, CVFile* vf);
    bool VirtualFileSync();

    void ClearSelections();
    bool SelectRAR(CString csFnameKey, bool onlyexisting, bool onlynonexisting);

    bool AutoSelect();
    bool Selected2Real(CMapStringToPtr* mapReal);
    bool CopyToClipboard();
    bool DeleteSelected();
    bool CopyRequestToClipboard();

    // Color list.
    bool RedrawItem(CString csFname);
  private:
    // The following members are set by VirtualFileSync..
    // csKeyFname and csDisplayFname
    CMapStringToString map;
    // Sort elements in map.
    CArray<POSITION, POSITION&> arrMapPos;
    // Set used for calc in DrawItem and AutoSelect.
    CTime timeNow;
    bool fFullView;

    CListCtrl* lv;
    CString csDlFolder;

    bool fShowExisting;
    bool fShowMissing;

    bool CreateCompressedSequence(CArray<s32, s32> *arrPart, CString* csCompress);

  public:
    // Overridden to draw this view.
    virtual void OnDraw(CDC* pDC);
    virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
    virtual void OnInitialUpdate();
  protected:
    virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
    virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
    virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
    virtual void PostNcDestroy();

  public:

#ifdef _DEBUG
    virtual void AssertValid() const;
    virtual void Dump(CDumpContext& dc) const;
#endif

  protected:

    // Generated message map functions.
  protected:
    afx_msg void OnUpdateSelected(CCmdUI* pCmdUI);
    afx_msg void OnUpdateTotal(CCmdUI* pCmdUI);
    afx_msg void OnUpdateFree(CCmdUI* pCmdUI);
    afx_msg void OnUpdateViewChkShowexisting(CCmdUI* pCmdUI);
    afx_msg void OnUpdateViewChkShowmissing(CCmdUI* pCmdUI);

    afx_msg LRESULT OnMsgNewFileStatus(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnMsgDoneCRC(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnMsgDoRefresh(WPARAM wParam, LPARAM lParam);

    afx_msg void OnOdfinditem(NMHDR* pNMHDR, LRESULT* pResult);
    afx_msg void OnDividerdblclick(NMHDR* pNMHDR, LRESULT* pResult);
    afx_msg void OnGetdispinfo(NMHDR* pNMHDR, LRESULT* pResult);
    afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
    afx_msg void OnViewRefresh();
    afx_msg void OnViewPause();
    afx_msg void OnToolsAutoselect();
    afx_msg void OnToolsDuplicates();
    afx_msg void OnToolsPar();
    afx_msg void OnToolsRequests();
    afx_msg void OnEditDelete();
    afx_msg void OnEditCut();
    afx_msg void OnEditCopy();
    afx_msg void OnEditPaste();
    afx_msg void OnEditUndo();
    afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
    afx_msg void OnUpdateToolsAutoselect(CCmdUI* pCmdUI);
    afx_msg void OnUpdateToolsDuplicates(CCmdUI* pCmdUI);
    afx_msg void OnUpdateToolsPar(CCmdUI* pCmdUI);
    afx_msg void OnUpdateViewPause(CCmdUI* pCmdUI);
    afx_msg void OnUpdateViewRefresh(CCmdUI* pCmdUI);
    afx_msg void OnUpdateEditCut(CCmdUI* pCmdUI);
    afx_msg void OnUpdateEditDelete(CCmdUI* pCmdUI);
    afx_msg void OnUpdateEditPaste(CCmdUI* pCmdUI);
    afx_msg void OnUpdateEditUndo(CCmdUI* pCmdUI);
    afx_msg void OnUpdateToolsRequests(CCmdUI* pCmdUI);
    afx_msg void OnChkShowexisting();
    afx_msg void OnChkShowmissing();

    DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MultismartView.cpp
inline CMultismartDoc* CMultismartView::GetDocument() {
  return (CMultismartDoc*)m_pDocument;
}
#endif
