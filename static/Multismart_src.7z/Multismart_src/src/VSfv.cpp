#include "stdafx.h"
#include "VSfv.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CVSfv::CVSfv() {
}

CVSfv::~CVSfv() {
}

// Gen.

bool CVSfv::LoadFolder(bool fQuick) {
  CVDescr::LoadFolder(fQuick);

  if (!fQuick) {
    ProgressSet("Scanning SFV parents and mapping SFV children...", 50);
    LoadSFVFiles();
  }
  else {
    ProgressSet("Removing SFV children from empty SFV parents...", 50);
    RemoveChildless();
  }

  return true;
}


// Load all SFV files in folder.
//
// If several SFV files exist and they all contain info on the same file
// (test1.sfv  test1-0001.sfv for instance), the last file found will be
// the one that is recorded as the parent of that file. This can create
// confusing results when deleting files.
bool CVSfv::LoadSFVFiles() {
  TRACE("CVSfv::LoadFolder()\n");

  map.RemoveAll();

  HANDLE h;
  WIN32_FIND_DATA fd;

  if ((h = FindFirstFile("*.sfv", &fd)) != INVALID_HANDLE_VALUE) {
    do {
      if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
        LoadFile(fd.cFileName);
      }
    }
    while (FindNextFile(h, &fd));

    FindClose(h);
  }

  TRACE("CVSfv::LoadFolder()  Loaded %d sfv children\n", map.GetCount());
  return true;
}

/*
	load single SFV parent

	maps all children of the sfv parent

	if none of the SFV children exist on disk, the parent is not loaded.
	this makes it possible to keep old sfv files around without using
	huge amounts of memory.
*/
bool CVSfv::LoadFile(CString csSFVFname) {
  CStdioFile cF;
  CString csLine;
  CString csFname;
  CStringList listcs;
  CVDiskCont df;

  CVSfvCont sf;
  sf.csSFVFile = csSFVFname;

  if (!cF.Open(GetWorkingFolder() + csSFVFname, CFile::modeRead)) {
    return false;
  }

  bool fEmpty = true;

  while (cF.ReadString(csLine)) {
    if (csLine.Left(1) != ";" && csLine.GetLength() > 8) {
      sscanf(csLine.Left(csLine.GetLength() - 8), "%[^\n]", csFname.GetBuffer(1024));
      csFname.ReleaseBuffer();

      csFname.TrimRight();
      sf.csDisplayFname = csFname;
      sscanf(csLine.Right(8), "%x", &sf.crc);
      csFname.MakeLower();

      map.SetAt(csFname, sf);

      // Check if file exists on disk.
      if (CVDisk::Lookup(csFname, &df)) {
        fEmpty = false;
      }

      // If still haven't found file that exists on disk, add filename to list.
      if (fEmpty) {
        listcs.AddTail(csFname);
      }
    }
  }

  // If none of the files existed on disk I now have a list of all those keys.
  // Go back and delete all of them.
  if (fEmpty) {
    POSITION p = listcs.GetHeadPosition();

    while (p) {
      csFname = listcs.GetNext(p);
      map.RemoveKey(csFname);
    }

    listcs.RemoveAll();
  }

  cF.Close();

  return true;
}

/*
		delete all children of any parent where no children exist. If one or more
		children exist, leave all children. also see LoadFile comments
*/
bool CVSfv::RemoveChildless() {
  TRACE("bool CVSfv::RemoveChildless()  begin\n");

  // Count all children of each parent.

  CMap<CString, LPCSTR, u32, u32> mapCount;
  POSITION pos1, pos2;
  CString csFnameSFVMapKey;
  CVSfvCont sf;
  CVDiskCont df;
  u32 iChildCount;

  for (pos1 = map.GetStartPosition(); pos1 != NULL;) {
    map.GetNextAssoc(pos1, csFnameSFVMapKey, sf);

    if (!mapCount.Lookup(sf.csSFVFile, iChildCount)) {
      mapCount[sf.csSFVFile] = 1;
    }
    else {
      mapCount[sf.csSFVFile] = ++iChildCount;
    }
  }

  // Iterate over all SFV children and check if they exist. if one doesn't
  // exist, remove it from SFV children map and subtract count of it's sfv
  // parent by one. if the count becomes zero, remove all children of that
  // parent.

  // Iterate over all SFV children.
  for (pos1 = map.GetStartPosition(); pos1 != NULL;) {
    map.GetNextAssoc(pos1, csFnameSFVMapKey, sf);

    if (!CVDisk::Lookup(csFnameSFVMapKey, &df)) {
      // Found SFV child that doesn't exist on disk. check if it is alone.
      VERIFY(mapCount.Lookup(sf.csSFVFile, iChildCount));
      mapCount[sf.csSFVFile] = --iChildCount;

      if (!iChildCount) {
        // Found SFV parent that contains no children anymore. delete all
        // children of that parent.
        CString csSFVParent = sf.csSFVFile;

        for (pos2 = map.GetStartPosition(); pos2 != NULL;) {
          map.GetNextAssoc(pos2, csFnameSFVMapKey, sf);

          if (sf.csSFVFile == csSFVParent) {
            map.RemoveKey(csFnameSFVMapKey);
          }
        }
      }
    }
  }

  TRACE("bool CVSfv::RemoveChildless()  end\n");

  return true;
}

/*
	GetSelect is called when virtual files need to be translated to
	real files.

	CVSfv responds by adding SFV children from selected SFV parents.
*/
bool CVSfv::GetSelect(CStringList* listcsSelectedFnames, CMapStringToPtr* mapReal) {
  TRACE("CVSfv::GetSelect()  begin\n");

  POSITION pos1, pos2;
  CVSfvCont sf;
  CVDiskCont df;
  CString csFnameSFVMapKey, csFnameKey;
  bool fAdded = false;

  // Iterate over names of files that have been selected.

  for (pos1 = listcsSelectedFnames->GetHeadPosition(); pos1 != NULL;) {
    CString csSelectedFname = listcsSelectedFnames->GetNext(pos1);
    CString csSelectedFnameKey = csSelectedFname;
    csSelectedFnameKey.MakeLower();

    // If file is child of any SFV parent, add it (makes it possible to select
    // "sfv only" files).
    if (map.Lookup(csSelectedFnameKey, sf)) {
      (*mapReal)[csSelectedFname] = NULL;
      fAdded = true;

      TRACE("Added: %s\n", csSelectedFname);
    }

    // Check if file is SFV parent. if it is, add all children of this parent.
    if (csSelectedFnameKey.Right(4) == ".sfv") {
      for (pos2 = map.GetStartPosition(); pos2 != NULL;) {
        map.GetNextAssoc(pos2, csFnameSFVMapKey, sf);

        if (sf.csSFVFile == csSelectedFname) {
          (*mapReal)[sf.csDisplayFname] = NULL;
          fAdded = true;
        }
      }
    }
  }

  TRACE("CVSfv::GetSelect()  end\n");

  return fAdded;
}

/*
	Find and delete SFV parents that have none of their children on disk.

	This function is not in use because after making it I decided that I wanted
	to encourage keeping the old SFV's around so that Multismart can use them to
	find number of archive parts if parts of that archive ever show up again.
*/
/*
bool CVSfv::DeleteEmptySFV() {
	// Sync DiskFiles to make sure we don't delete any SFV files that got files
  // since last sync.

	CVDisk::SyncFolder();
  // update VirtualFiles to reflect any changes in DiskFiles.
	VirtualFileSync();

	POSITION pos1, pos2;
	CString csFnameKey1, csFnameKey2;
	CVFile vf;
	CVDiskCont df, dfDummy;
	CVSfvCont sf;
	bool fDeleted = false;

	// Search for DiskFiles SFV file.

	pos1 = CVDisk::GetStartPosition();
	while (pos1 != NULL) {
		CVDisk::GetNextAssoc(&pos1, &csFnameKey1, &df);
		if (csFnameKey1.Right(4) == ".sfv") {
			// Found a DiskFiles SFV file.
			// Now search for DiskFiles that are listed in this SFV file.

			pos2 = CVDisk::GetStartPosition();
			while (pos2 != NULL) {
				CVDisk::GetNextAssoc(&pos2, &csFnameKey2, &dfDummy);
				VirtualFileState(csFnameKey2, &vf);
        // Has accompanying SFV file and has this SFV file.
				if (CVSfv::map.Lookup(csFnameKey2, sf) && vf.csInfo1 == df.csDisplayFname) {
          // Found match so abort search.
					break;
        }
			}

      // Didn't find any matches, so we delete it.
			if (pos2 == NULL)  {
				TRACE("Delete: %s\n", df.csDisplayFname);
				if (DeleteFile(df.csDisplayFname)) {
					fDeleted = true;
        }
			}
		}
	}

	if (fDeleted) {
    // Remove deleted files from dfs.
		CVDisk::SyncFolder();
    // Sync VirtualFiles with DiskFiles.
		VirtualFileSync();
	}

	return true;
}
*/