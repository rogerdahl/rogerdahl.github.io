#pragma once

class CDuplicatesConfirmDlg : public CDialog {
  public:
    // Standard constructor.
    CDuplicatesConfirmDlg(CWnd* pParent = NULL);

    // Dialog Data.
    enum { IDD = id_dlg_duplicates_confirm };
    CStatic	pic_warning;
    BOOL	chk_nomore;

    // Overrides.
  public:
    INT_PTR DoModal();
  protected:
    // DDX/DDV support.
    virtual void DoDataExchange(CDataExchange* pDX);

    // Implementation.
  protected:

    virtual BOOL OnInitDialog();
    virtual void OnOK();
    DECLARE_MESSAGE_MAP()
};
