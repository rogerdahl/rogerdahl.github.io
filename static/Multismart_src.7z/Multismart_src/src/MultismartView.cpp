#include "stdafx.h"
#include "Multismart.h"
#include "MultismartDoc.h"
#include "MultismartView.h"
#include "DuplicatesThread.h"
#include "MainFrm.h"
#include "DuplicatesThread.h"
#include "SortableStringArray.h"
#include "DeleteConfirmDlg.h"
#include "CopyDlg.h"
#include "SelectDlg.h"

#include <algorithm>
#include <fstream>
#include <queue>
#include <vector>
#include <map>
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

IMPLEMENT_DYNCREATE(CMultismartView, CListView)
BEGIN_MESSAGE_MAP(CMultismartView, CListView)
  ON_NOTIFY_REFLECT(LVN_ODFINDITEM, OnOdfinditem)
  ON_NOTIFY_REFLECT(HDN_DIVIDERDBLCLICK, OnDividerdblclick)
  ON_NOTIFY_REFLECT(LVN_GETDISPINFO, OnGetdispinfo)
  ON_WM_LBUTTONDBLCLK()
  ON_COMMAND(ID_VIEW_REFRESH, OnViewRefresh)
  ON_COMMAND(ID_VIEW_PAUSE, OnViewPause)
  ON_COMMAND(ID_TOOLS_AUTOSELECT, OnToolsAutoselect)
  ON_COMMAND(ID_TOOLS_DUPLICATES, OnToolsDuplicates)
  ON_COMMAND(ID_TOOLS_PAR, OnToolsPar)
  ON_COMMAND(ID_TOOLS_REQUESTS, OnToolsRequests)
  ON_COMMAND(ID_EDIT_DELETE, OnEditDelete)
  ON_COMMAND(ID_EDIT_CUT, OnEditCut)
  ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
  ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
  ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
  ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
  ON_UPDATE_COMMAND_UI(ID_TOOLS_AUTOSELECT, OnUpdateToolsAutoselect)
  ON_UPDATE_COMMAND_UI(ID_TOOLS_DUPLICATES, OnUpdateToolsDuplicates)
  ON_UPDATE_COMMAND_UI(ID_TOOLS_PAR, OnUpdateToolsPar)
  ON_UPDATE_COMMAND_UI(ID_VIEW_PAUSE, OnUpdateViewPause)
  ON_UPDATE_COMMAND_UI(ID_VIEW_REFRESH, OnUpdateViewRefresh)
  ON_UPDATE_COMMAND_UI(ID_EDIT_CUT, OnUpdateEditCut)
  ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, OnUpdateEditDelete)
  ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
  ON_UPDATE_COMMAND_UI(ID_EDIT_UNDO, OnUpdateEditUndo)
  ON_UPDATE_COMMAND_UI(ID_TOOLS_REQUESTS, OnUpdateToolsRequests)
  ON_BN_CLICKED(ID_VIEW_CHK_SHOWEXISTING, OnChkShowexisting)
  ON_BN_CLICKED(ID_VIEW_CHK_SHOWMISSING, OnChkShowmissing)
  // Standard printing commands.
  ON_COMMAND(ID_FILE_PRINT, CListView::OnFilePrint)
  ON_COMMAND(ID_FILE_PRINT_DIRECT, CListView::OnFilePrint)
  ON_COMMAND(ID_FILE_PRINT_PREVIEW, CListView::OnFilePrintPreview)
  ON_UPDATE_COMMAND_UI(ID_INDICATOR_SELNO, OnUpdateSelected)
  ON_UPDATE_COMMAND_UI(ID_INDICATOR_TOT, OnUpdateTotal)
  ON_UPDATE_COMMAND_UI(ID_INDICATOR_FREE, OnUpdateFree)
  ON_UPDATE_COMMAND_UI(ID_VIEW_CHK_SHOWEXISTING, OnUpdateViewChkShowexisting)
  ON_UPDATE_COMMAND_UI(ID_VIEW_CHK_SHOWMISSING, OnUpdateViewChkShowmissing)
  ON_MESSAGE(UWM_NEWFILESTATUS, OnMsgNewFileStatus)
  ON_MESSAGE(UWM_DONECRC, OnMsgDoneCRC)
END_MESSAGE_MAP()

CMultismartView::CMultismartView(void) {
  lv = &GetListCtrl();
}

CMultismartView::~CMultismartView(void) {
}
BOOL CMultismartView::PreCreateWindow(CREATESTRUCT& cs) {
  // Modify the Window class or styles here by modifying the CREATESTRUCT cs.
  cs.style = LVS_OWNERDATA | LVS_OWNERDRAWFIXED // virtual & owner draw
             | WS_VISIBLE | LVS_ALIGNLEFT | WS_CHILD | SS_NOPREFIX // WS_BORDER thin black border
             | LVS_REPORT | LVS_NOSORTHEADER | LVS_SHOWSELALWAYS;
  cs.dwExStyle |= LVS_EX_FULLROWSELECT;
  return CListView::PreCreateWindow(cs);
}

void CMultismartView::OnInitialUpdate(void) {
  CListView::OnInitialUpdate();
  char* cols[] = { "Type", "Name", "Days", "Size", "Status", "Info1", "Info2" };
  // Create columns in listview.
  // Get sizes from registry or use default values.
  int sizes[] = { 100, 300, 50, 50, 100, 100, 1000 };
  HKEY myhnd;
  DWORD num, dsize;
  CString csKeyName;
  RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\dahlsys\\Multismart", 0, KEY_READ, &myhnd);

  for (int i = 0; i < 7; i++) {
    dsize = sizeof(num);
    csKeyName.Format("lv_headwidth_%d", i);

    if (RegQueryValueEx(myhnd, csKeyName, NULL, NULL, (BYTE*) &num, &dsize) == ERROR_SUCCESS) {
      sizes[i] = num;
    }
  }

  // Add columns to listview.
  LV_COLUMN lc;
  CRect rect;

  // Add the columns to the list control.
  for (int i = 0; i < 7; i++) {
    lc.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
    lc.fmt = LVCFMT_LEFT;
    lc.pszText = cols[i];
    lc.iSubItem = i;
    lc.cx = sizes[i];
    lv->InsertColumn(i, &lc);
  }

  // Set default show state.
  fShowExisting = false;
  fShowMissing = false;
  Refresh(false);
}
// CMultismartView drawing.
void CMultismartView::OnDraw(CDC* pDC) {
  CMultismartDoc* pDoc = GetDocument();
  ASSERT_VALID(pDoc);
}
// CMultismartView printing.
BOOL CMultismartView::OnPreparePrinting(CPrintInfo* pInfo) {
  // Default preparation.
  return DoPreparePrinting(pInfo);
}
void CMultismartView::OnBeginPrinting(CDC*, CPrintInfo*) {
  // TODO: add extra initialization before printing.
}
void CMultismartView::OnEndPrinting(CDC*, CPrintInfo*) {
  // TODO: add cleanup after printing.
}
// CMultismartView diagnostics.
#ifdef _DEBUG
void CMultismartView::AssertValid(void) const {
  CListView::AssertValid();
}
void CMultismartView::Dump(CDumpContext& dc) const {
  CListView::Dump(dc);
}
// Non-debug version is inline.
CMultismartDoc* CMultismartView::GetDocument(void) {
  ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMultismartDoc)));
  return (CMultismartDoc*)m_pDocument;
}
#endif

void CMultismartView::PostNcDestroy(void) {
  CListView::PostNcDestroy();
}

// CMultismartView message handlers.

// ListView calls this to find the information to display. I've optimized this
// one away.

void CMultismartView::OnGetdispinfo(NMHDR* pNMHDR, LRESULT* pResult) {
  // LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;.
  pResult = 0;
}

// Override DrawItem (ownerdraw) The way it is supposed to work with a virtual
// listview is that the listview calls OnGetdispinfo to get the info it needs to
// draw items, and then it draws the items itself. Because my listview is also
// ownderdraw, I can take advantage of that and move the code that decides what
// to display directly into the DrawItem function. This gives me the opportunity
// to make some very good optimalizations, but it also stops me from being able
// to take advantage of some of the other services of the listview. These
// include: When a border between buttons is double-clicked, the listview
// attempts to find the size of the longest text. I now have to handle that
// myself. Also, I can not use the cache hinting mechanism of listviews. That is
// ok though since my data is all in RAM. Note that display flickers a whole
// lot. Particularly when making selections and scrolling at the same time. The
// virtual listview demo from MS does the same thing so I think that virtual
// listviews are just less intelligent, and redraws items all the time instead
// of actually scrolling them.
void CMultismartView::DrawItem(LPDRAWITEMSTRUCT lpDIS) {
  CDC* pDC = CDC::FromHandle(lpDIS->hDC);
  // Clear rectangle.
  CBrush br((COLORREF) 0xffffff);
  pDC->FillRect(&lpDIS->rcItem, &br);

  if (lpDIS->itemAction & ODA_DRAWENTIRE) {
    // Create and select brush and pen used for selected and focused.
    CPen penMarker(PS_SOLID, 1, 0xff0000);
    CPen* penDefault = (CPen*)pDC->SelectObject(penMarker);

    // If selected, draw selected marker, and make focus marker have gray
    // backround. Too if focus marker is drawn.
    if (lpDIS->itemState & ODS_SELECTED) {
      CBrush brushMarker((COLORREF) 0xe0e0e0);
      CBrush* brushDefault = (CBrush*)pDC->SelectObject(brushMarker);
      pDC->FillRect(&lpDIS->rcItem, &brushMarker);
    }

    // If focused, draw focus marker.
    if (lpDIS->itemState & ODS_FOCUS) {
      pDC->Rectangle(&lpDIS->rcItem);
    }

    // If focused or selected, create and select bold font.
    if (lpDIS->itemState & ODS_SELECTED) {
      LOGFONT finfo;
      CFont* fontCurrent(pDC->GetCurrentFont());
      fontCurrent->GetLogFont(&finfo);
      finfo.lfWeight = 900;
      CFont fontNew;
      fontNew.CreateFontIndirect(&finfo);
      CFont* fontDefault((CFont*)pDC->SelectObject(fontNew));
    }

    // Get item info.
    CVFile vf;
    CString csStatusText;
    CString csFnameKey, csDisplayFname;
    POSITION p = arrMapPos[lpDIS->itemID];
    map.GetNextAssoc(p, csFnameKey, csDisplayFname);
    VirtualFileState(csFnameKey, &vf);
    pDC->SetTextColor(vf.color);
    // Draw text.
    CString csItem;
    LVCOLUMN col;
    CRect r = lpDIS->rcItem;
    // Move text 5 pixels to the right.
    r.left += 5;
    u32 j = 0, k;

    for (u32 i = 0; i < 7; i++) {
      col.mask = LVCF_WIDTH;
      lv->GetColumn(i, &col);
      r.right = r.left + col.cx - 5;

      // Swap col 0 and 1.
      switch (i == 0 ? k = 1 : i == 1 ? k = 0 : k = i) {
        case 0 :
          csItem = csDisplayFname;
          break;
        case 1:
          csItem = vf.csTypeText;
          break;
        case 2:
          csItem = vf.csDate;
          break;
        case 3:
          csItem = vf.csSize;
          break;
        case 4:
          csItem = vf.csStatusText;
          break;
        case 5:
          csItem = vf.csInfo1;
          break;
        case 6:
          csItem = vf.csInfo2;
          break;
        default:
          // No such column.
          ASSERT(0);
      }

      pDC->DrawText(csItem, r, DT_SINGLELINE | DT_NOPREFIX);
      r.left += col.cx;
    }

    // Dunno why these don't work.
    //pDC->SelectObject(fontDefault); pDC->SelectObject(penDefault);
    //pDC->SelectObject(brushDefault);
  }
}

// I implement this so the keyboard shortcuts for jumping directly to the first
// item of a given letter will work, and a simple FindItem that I use will work.
// Because of this, the implementation is limited and doesn't support:
// LVFI_PARAM, LVFI_WRAP, LVFI_NEARESTXY. I think there is a bug: When the
// listview receives a keyboard shortcut and tries to find it, it does not use
// the LVFI_PARTIAL flag even if it searches for something that starts with a
// single letter. Because of this, I ignore LVFI_PARTIAL, and always search for
// partial.
void CMultismartView::OnOdfinditem(NMHDR* pNMHDR, LRESULT* pResult) {
  NMLVFINDITEM* pFindInfo = (NMLVFINDITEM*)pNMHDR;
  CString csFind(pFindInfo->lvfi.psz);

  // First search from current focus.

  // Searching for string.
  if (pFindInfo->lvfi.flags & LVFI_STRING) {
    for (int i = pFindInfo->iStart; i <= arrMapPos.GetUpperBound(); i++) {
      CString csFnameKey, csDisplayFname;
      POSITION p = arrMapPos[i];
      map.GetNextAssoc(p, csFnameKey, csDisplayFname);

      if (csFnameKey.Left(csFind.GetLength()) == csFind) {
        *pResult = i;
        return;
      }
    }
  }

  // Then search from top.

  // Searching for string.
  if (pFindInfo->lvfi.flags & LVFI_STRING) {
    for (int i = 0; i <= arrMapPos.GetUpperBound(); i++) {
      CString csFnameKey, csDisplayFname;
      POSITION p = arrMapPos[i];
      map.GetNextAssoc(p, csFnameKey, csDisplayFname);

      if (csFnameKey.Left(csFind.GetLength()) == csFind) {
        *pResult = i;
        return;
      }
    }
  }

  // Not found.
  *pResult = -1;
}
/*
	This should find the widest item and return that. Called when user double
	clicks divider to resize to widest item
*/
void CMultismartView::OnDividerdblclick(NMHDR* pNMHDR, LRESULT* pResult) {
  HD_NOTIFY* phdn = (HD_NOTIFY*)pNMHDR;
  *pResult = 0;
}
/*
	Called when user doubleclicks an item. Selects corresponding items.
*/
void CMultismartView::OnLButtonDblClk(UINT nFlags, CPoint point) {
  // HitTest works but I don't know why because I have not implemented that in
  // OnOdfinditem.
  u32 u32Item = lv->HitTest(point);

  // User doubleclicked in the middle of nowhere.
  if (u32Item == -1) {
    return;
  }

  CString csFnameKey, csDisplayFname;
  POSITION p = arrMapPos[u32Item];
  map.GetNextAssoc(p, csFnameKey, csDisplayFname);
  // Rarinfo.
  CVRarInfoCont rf;

  if (GetDocument()->CVRarInfo::map.Lookup(csFnameKey, rf)) {
    // TODO: Bug.
    // If (!CheckVisible())
    // Return;
    SelectRAR(csFnameKey, false, false);
  }

  // Pass double-click to base class.
  // TODO: Bug: had to remove this.
  // CListCtrl::OnLButtonDblClk(nFlags, point);
}

// Called by document when background thread causes item status to change.
bool CMultismartView::RedrawItem(CString csFname) {
  for (int i = 0; i < arrMapPos.GetSize(); i++) {
    CString csFnameKey, csDisplayFname;
    POSITION p = arrMapPos[i];
    map.GetNextAssoc(p, csFnameKey, csDisplayFname);

    if (csFnameKey == csFname) {
      lv->RedrawItems(i, i);
      return true;
    }
  }

  // TRACE("CMultismartView::RedrawItem() Didn't find %s\n", csFname);.
  return false;
}
/*
	called by CRCFilesAsync when it stops
*/
afx_msg LRESULT CMultismartView::OnMsgDoneCRC(WPARAM wParam, LPARAM lParam) {
  // WndMain->m_wndStatusBar.SetPaneText(0, "CRC Done");.
  // WndMain->m_wndToolBar.SendDlgItemMessage(id_but_crc, WM_ENABLE, 1, 0);.
  return 0;
}

// Message sent by CVDisk when it is finished MD5/CRC'ing a file.
afx_msg LRESULT CMultismartView::OnMsgNewFileStatus(WPARAM wParam, LPARAM lParam) {
  CString* csFname = (CString*)wParam;
  CString csFnameKey(*csFname);
  csFnameKey.MakeLower();
  // Update main item in lv.
  RedrawItem(csFnameKey);

  // Notify RarInfoFiles about changed status and update rarinfo file if one
  // changed status.

  // Alters csFnameKey if true.
  if (GetDocument()->CVRarInfo::NotifyChange(&csFnameKey)) {
    RedrawItem(csFnameKey);
  }

  // Update status bar.
  CString csCrc;
  csCrc.Format("CRC'ed: %s", *csFname);
  ((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(0, csCrc);
  delete csFname;
  return 0;
}
/*
	Functions
*/
/*
	Refresh Document
*/
bool CMultismartView::Refresh(bool fQuick) {
  GetDocument()->LoadFolder(fQuick);
  VirtualFileSync();
  return true;
}
/*
	VirtualFileSync() creates the list of items that this View will show
	information about. It maintains the members: map, arrMapPos and timeNow. Only
	unique filenames are used. The state of files is not recorded. The state is
	implicitly stored in the document, and retrieved by the document function
	VirtualFileState()
*/
bool CMultismartView::VirtualFileSync(void) {
  TRACE("CMultismartView::VirtualFileSync()  start\n");
  // Show the progress window.
  GetDocument()->ProgressStart();
  // Clear map and array and remove selections.
  arrMapPos.RemoveAll();
  map.RemoveAll();
  // Clear selections (virtual list doesn't have any items).
  ClearSelections();
  // Used for calculating Days on the fly in DrawItem.
  timeNow = CTime::GetCurrentTime();
  // Used to alter color asignments in VirtualFileStat().
  fFullView = false;
  // Create map of unique filenames from all containers.
  CVDiskCont df;
  CVSfvCont sf;
  CVHighestCont hf;
  CVGapCont gf;
  CVRarInfoCont rf;
  CString csFname, csFnameKey;
  POSITION pos;
  // Bool fHideEmpty = dlgDialogBar->SendDlgItemMessage(id_chk_show_emptysfv,
  // BM_GETCHECK, 0, 0);

  // Add DISK.
  GetDocument()->ProgressSet("Synchronizing display...", 20);

  if (fShowExisting) {
    fFullView = true;
    TRACE("CMultismartView::VirtualFileSync()  add DISK\n");
    pos = GetDocument()->CVDisk::GetStartPosition();

    while (pos != NULL) {
      GetDocument()->CVDisk::GetNextAssoc(&pos, &csFnameKey, &df);
      map[csFnameKey] = df.csDisplayFname;
    }
  }

  if (fShowMissing) {
    fFullView = true;
    // Add SFV ONLY.
    GetDocument()->ProgressSet("Synchronizing display...", 40);
    TRACE("CMultismartView::VirtualFileSync()  add SFV\n");
    pos = GetDocument()->CVSfv::map.GetStartPosition();

    while (pos != NULL) {
      GetDocument()->CVSfv::map.GetNextAssoc(pos, csFnameKey, sf);
      if (!GetDocument()->CVDisk::Lookup(csFnameKey, &df)) {
        map[csFnameKey] = sf.csDisplayFname;
      }
    }

    // Add PAR CHILDREN ONLY and PAR PARENTS ONLY.
    GetDocument()->ProgressSet("Synchronizing display...", 50);
    TRACE("CMultismartView::VirtualFileSync()  add PAR children and parents\n");
    CVParChildItem* pParItemChild;
    CVParParentItem* pParItemParent;
    CVParSetItem* pParItemSet;
    CMd5 md5Dummy;
    POSITION pos2;
    // Iterate over sets.
    pos = GetDocument()->CVPar::mapSets.GetStartPosition();

    while (pos != NULL) {
      GetDocument()->CVPar::mapSets.GetNextAssoc(pos, md5Dummy, pParItemSet);
      // Iterate over children in each set.
      pos2 = pParItemSet->mapChildren.GetStartPosition();

      while (pos2 != NULL) {
        pParItemSet->mapChildren.GetNextAssoc(pos2, md5Dummy, pParItemChild);
        csFnameKey = pParItemChild->csDisplayFname;
        csFnameKey.MakeLower();

        if (!GetDocument()->CVDisk::Lookup(csFnameKey, &df)) {
          map[csFnameKey] = pParItemChild->csDisplayFname;
        }
      }

      // Iterate parents in each set.
      pos2 = pParItemSet->mapParents.GetStartPosition();

      while (pos2 != NULL) {
        pParItemSet->mapParents.GetNextAssoc(pos2, md5Dummy, pParItemParent);
        csFnameKey = pParItemParent->csDisplayFname;
        csFnameKey.MakeLower();

        if (!GetDocument()->CVDisk::Lookup(csFnameKey, &df)) {
          map[csFnameKey] = pParItemParent->csDisplayFname;
        }
      }
    }

    // Add GAP.
    GetDocument()->ProgressSet("Synchronizing display...", 60);
    TRACE("CMultismartView::VirtualFileSync()  add GAP\n");
    pos = GetDocument()->CVGap::map.GetStartPosition();

    while (pos != NULL) {
      GetDocument()->CVGap::map.GetNextAssoc(pos, csFnameKey, gf);
      map[csFnameKey] = gf.csDisplayFname;
    }
  }

  // Add HIGHEST.
  /*
  	if (dlgDialogBar->SendDlgItemMessage(id_chk_show_diskonly, BM_GETCHECK, 0, 0)) {
  		TRACE("CMultismartView::VirtualFileSync() add HIGHEST\n");
  		pos = CVHighest::map.GetStartPosition();
  		while (pos != NULL) {
  			CVHighest::map.GetNextAssoc(pos, csFname, hf); map[csFname] = hf.csDisplayFname + CString(".") + hf.csLast;
  		}
  	}
  */
  // Add RARINFO.
  GetDocument()->ProgressSet("Synchronizing display...", 80);
  TRACE("CMultismartView::VirtualFileSync()  add RARINFO\n");
  pos = GetDocument()->CVRarInfo::map.GetStartPosition();

  while (pos != NULL) {
    GetDocument()->CVRarInfo::map.GetNextAssoc(pos, csFnameKey, rf);

    if (rf.u32DiskParts > 0 /* || fShowEmpty */) {
      map[csFnameKey] = rf.csDisplayFname;
    }
  }

  TRACE("CMultismartView::VirtualFileSync()  arrMapPos - Set size and fill\n");
  /*
  	set size of arrMapPos to number of unique files and fill it with unique filenames
  */
  arrMapPos.SetSize(map.GetCount());
  int i = 0;
  CString csDisplayFname;
  pos = map.GetStartPosition();

  while (pos != NULL) {
    arrMapPos[i++] = pos;
    map.GetNextAssoc(pos, csFname, csDisplayFname);
  }

  TRACE("CMultismartView::VirtualFileSync()  Start Sort\n");
  /*
  	sort the arrMapPos Uses Shell Sort Basically it does a bunch of smaller
  	insertion sorts than insertion sorts the whole thing. Insertion sorting is much
  	faster on a list that is already mostly sorted.
  */
#define STRIDE_FACTOR 3
  bool bFound;
  int iElements = static_cast<int>(arrMapPos.GetSize());
  int iInner, iOuter, iStride = 1;
  CString csFnameKey1, csFnameKey2, csDisplayFname1, csDisplayFname2;
  POSITION p1, p2, p1t, p2t;

  while (iStride <= iElements) {
    iStride = iStride * STRIDE_FACTOR + 1;
  }

  while (iStride > (STRIDE_FACTOR - 1)) {
    iStride = iStride / STRIDE_FACTOR;

    for (iOuter = iStride; iOuter < iElements; iOuter++) {
      bFound = false;
      iInner = iOuter - iStride;

      while ((iInner >= 0) && !bFound) {
        p1 = arrMapPos[iInner + iStride];
        p2 = arrMapPos[iInner];
        p1t = p1;
        p2t = p2;
        map.GetNextAssoc(p1t, csFnameKey1, csDisplayFname1);
        map.GetNextAssoc(p2t, csFnameKey2, csDisplayFname2);

        // Do case insensitive comparison.
        if (CString(csFnameKey1).MakeLower() < CString(csFnameKey2).MakeLower()) {
          arrMapPos[iInner + iStride] = p2;
          arrMapPos[iInner] = p1;
          iInner -= iStride;
        }
        else {
          bFound = true;
        }
      }
    }
  }

  TRACE("CMultismartView::VirtualFileSync()  End Sort\n");
  // Set number of items in clistctrl.
  lv->SetItemCountEx(static_cast<int>(map.GetCount()), LVSICF_NOSCROLL /* | LVSICF_NOINVALIDATEALL */);
  GetDocument()->ProgressStop();
  // RedrawItems(0, map.GetCount() -1);
  // Update(0); // seems to update everything from 0 and out.
  TRACE("CMultismartView::VirtualFileSync()  end\n");
  return true;
}
/*
	Retrieve the state of one item.
*/
bool CMultismartView::VirtualFileState(CString csFname, CVFile* vf) {
  /* text date info1 info2 error - internal error file doesn't exist disk only date
  	   of file - descript.ion sfv only date of sfv file sfv file highest only gap only
  	   - - crc ok date of file sfv file descript.ion crc bad / length ok date of file
  	   sfv file descript.ion crc bad / length bad date of file sfv file descript.ion
  	   open error - - descript.ion crc uncalculated date of file sfv file descript.ion */
  CVDiskCont df;
  CVSfvCont sf;
  CVHighestCont hf;
  CVGapCont gf;
  CVRarInfoCont rf;
  CString csDescription;
  CTimeSpan span;
  // "!!" because returns BOOL (not bool)
  bool fDiskExists = !!GetDocument()->CVDisk::Lookup(csFname, &df);
  bool fSfvChildExists = !!GetDocument()->CVSfv::map.Lookup(csFname, sf);
  // Find PAR child that has this name.
  CVParChildItem* pParItemChild;
  bool fParChildExists = !!GetDocument()->CVPar::mapChildNameToItem.Lookup(csFname, pParItemChild);
  // Find PAR parent that has this name.
  CVParParentItem* pParItemParent;
  bool fParParentExists = !!GetDocument()->CVPar::mapParentNameToItem.Lookup(csFname, pParItemParent);
  bool fHighestItemExists = !!GetDocument()->CVHighest::map.Lookup(csFname, hf);
  bool fGapItemExists = !!GetDocument()->CVGap::map.Lookup(csFname, gf);
  bool fRarInfoItemExists = !!GetDocument()->CVRarInfo::map.Lookup(csFname, rf);
  // False for rar info, so do it again with ".rar" in RAR info.
  bool ffDescriptionItemExists = !!GetDocument()->CVDescr::map.Lookup(csFname, csDescription);

  if (!ffDescriptionItemExists) {
    csDescription = "";
  }

  // At least one container must exist.
  ASSERT
  (
    fDiskExists
    ||	fSfvChildExists
    ||	!fParChildExists
    ||	!fParParentExists
    ||	!fHighestItemExists
    ||	!fGapItemExists
    ||	!fRarInfoItemExists
  );

  // RARINFO.
  if (fRarInfoItemExists) {
    vf->color = 0xee00000;
    vf->csTypeText = "rar info";
    CTimeSpan span1 = timeNow - rf.timeFirst;
    CTimeSpan span2 = timeNow - rf.timeLast;
    vf->csDate.Format("%I64d - %I64d", span1.GetDays(), span2.GetDays());
    vf->csSize.Format("%s / %s", ToSensible(rf.u64DiskSize), ToSensible(rf.u64EstSize));
    // Info1.
    char cMark = ' ';

    if (!rf.fCntVerified) {
      switch (rf.u8KnownPartsStatus) {
        case KNOWNPARTS_ALL:
          break;
        case KNOWNPARTS_PROBABLYALL:
          cMark = '?';
          break;
        case KNOWNPARTS_MORE:
          cMark = '+';
          break;
      }
    }

    // If PAR files exist.
    if (rf.fParExists) {
      vf->csInfo1.Format
      (
        "%d / %d%c (%d / %d)",
        rf.u32DiskParts,
        rf.u32KnownParts,
        cMark,
        rf.u32Substitutions,
        rf.iGoodParents
      );
    }
    else {
      vf->csInfo1.Format("%d / %d%c", rf.u32DiskParts, rf.u32KnownParts, cMark);
    }

    // Status.
    switch (rf.iWorstError) {
      case RAR_OK:
        // RAR info entry must have corresponding highest files entry.
        ASSERT(fHighestItemExists);
        vf->color = 0xa0a0a0;

        if (rf.fParExists) {
          vf->csStatusText = "md5 ok";
        }
        else if (hf.fCntVerified) {
          vf->csStatusText = "crc ok";
        }
        else {
          vf->csStatusText = "size ok";
        }

        break;
      case RAR_OPENERROR:
        vf->color = 0x0000ff;
        vf->csStatusText.Format("open error: %d", rf.iErrors);
        break;
      case RAR_PENDING:
        vf->color = RGB(206, 138, 23);
        vf->csStatusText.Format("pending: %d", rf.iErrors);
        break;
      case RAR_SIZEERROR:
        vf->color = 0xa0000a0;
        vf->csStatusText.Format("size bad: %d", rf.iErrors);
        break;
      case RAR_CRCERROR:
        vf->color = 0xa0000a0;
        vf->csStatusText.Format("crc bad: %d", rf.iErrors);
        break;
      case RAR_COMPLETEQ:
        vf->color = 0x000000;
        vf->csStatusText = "complete?";
        break;
      case RAR_COMPLETE:
        vf->color = 0x000000;
        vf->csStatusText = "complete";
        break;
    }

    // Info2.
    // Look up description for last known file and use it.
    GetDocument()->CVDescr::map.Lookup(csFname + CString(".") + GetRarPartNameFromNumber(hf.nFirst, hf.nRarType), vf->csInfo2);

    // Always blue rarinfo when existing and/or missing is showing.
    if (fFullView) {
      vf->color = RGB(0, 0, 255);
    }

    return true;
  }

  // DISK ONLY.
  if
  (
    fDiskExists
    &&	!fSfvChildExists
    &&	!fParChildExists
    &&	!fParParentExists
    &&	!fHighestItemExists
    &&	!fGapItemExists
  ) { // Is "disk only" even if "rar info" (Rfs) entry exists.
    CString csFnameKey, csFnamePartKey;

    if (SplitRAR(csFname, &csFnameKey, &csFnamePartKey)) {
      // Is a RAR file so highestfiles contains expected size.
      if (GetDocument()->CVHighest::map.Lookup(csFnameKey, hf)) {
        if (df.m_size == hf.u64MaxSize) {
          // Size is ok.
          vf->color = 0x00a000;
          vf->csTypeText = "disk only";
          vf->csDate.Format("%d", (span = timeNow - df.m_mtime, span.GetDays()));
          vf->csSize = ToSensible(df.m_size);
          vf->csStatusText = "size ok";
          vf->csInfo1 = "";
          vf->csInfo2 = csDescription;
        }
        else {
          // Size not as expected check if it is last part.
          if (GetRarPartNumber(csFnamePartKey) == hf.nLast) {
            // Last part, so still ok.
            vf->color = 0x00a000;
            vf->csTypeText = "disk only";
            vf->csDate.Format("%d", (span = timeNow - df.m_mtime, span.GetDays()));
            vf->csSize = ToSensible(df.m_size);
            vf->csStatusText = "last part";
            vf->csInfo1 = "";
            vf->csInfo2 = csDescription;
          }
          else {
            // Size error.
            vf->color = 0xa0000a0;
            vf->csTypeText = "disk only";
            vf->csDate.Format("%d", (span = timeNow - df.m_mtime, span.GetDays()));
            vf->csSize = ToSensible(df.m_size);
            vf->csStatusText = "size bad";
            vf->csInfo1 = "";
            vf->csInfo2 = csDescription;
          }
        }
      }
      else {
        // highestfiles map didn't have the entry.
        ASSERT(false);
      }
    }
    else {
      vf->color = 0x00a000;
      vf->csTypeText = "disk only";
      vf->csDate.Format("%d", (span = timeNow - df.m_mtime, span.GetDays()));
      vf->csSize = ToSensible(df.m_size);
      vf->csStatusText = "";
      vf->csInfo1 = "";
      vf->csInfo2 = csDescription;
    }

    return true;
  }

  // PAR CHILD ONLY (ignore SFV if PAR exists).
  if (!fDiskExists && fParChildExists) {
    CVParParentItem* pItemParent;
    GetDocument()->mapChildItemToParentItem.Lookup(pParItemChild, pItemParent);
    vf->color = 0xa0a0a0;
    vf->csTypeText = "par only";
    vf->csDate = "";
    vf->csSize = "";
    vf->csStatusText = "";
    vf->csInfo1 = pItemParent->csDisplayFname;
    vf->csInfo2 = "";
    return true;
  }

  // PAR PARENT ONLY (ignore SFV if PAR exists).
  if (!fDiskExists && fParParentExists) {
    vf->color = 0xa0a0a0;
    vf->csTypeText = "par only";
    vf->csDate = "";
    vf->csSize = "";
    vf->csStatusText = "";
    vf->csInfo1 = pParItemParent->csDisplayFname;
    vf->csInfo2 = "";
    return true;
  }

  // SFV ONLY.
  if
  (
    !fDiskExists
    &&	fSfvChildExists
    &&	!fParChildExists
    &&	!fParParentExists
    &&	!fHighestItemExists
    &&	!fGapItemExists
    &&	!fRarInfoItemExists
  ) {
    vf->color = 0xa0a0a0;
    vf->csTypeText = "sfv only";
    vf->csDate = "";
    vf->csSize = "";
    vf->csStatusText = "";
    vf->csInfo1 = sf.csSFVFile;
    vf->csInfo2 = "";
    return true;
  }

  // HIGHEST ONLY.
  if
  (
    !fDiskExists
    &&	!fSfvChildExists
    &&	!fParChildExists
    &&	!fParParentExists
    &&	fHighestItemExists
    &&	!fGapItemExists
    &&	!fRarInfoItemExists
  ) {
    vf->color = 0x0000ff;
    vf->csTypeText = "highest";
    vf->csDate = "";
    vf->csSize = "";
    vf->csStatusText = "";
    vf->csInfo1 = "highest";
    vf->csInfo2 = "";
    return true;
  }

  // GAP ONLY.
  if
  (
    !fDiskExists
    &&	!fSfvChildExists
    &&	!fParChildExists
    &&	!fParParentExists
    &&	!fHighestItemExists
    &&	fGapItemExists
    &&	!fRarInfoItemExists
  ) {
    vf->color = 0xa0a0a0;
    vf->csTypeText = "gap";
    vf->csDate = "";
    vf->csSize = "";
    vf->csStatusText = "";
    vf->csInfo1 = "";
    vf->csInfo2 = "";
    return true;
  }

  // DISK & PAR CHILD (ignore SFV if PAR exists).
  if (fDiskExists && fParChildExists) {
    CVParParentItem* pItemParent;
    GetDocument()->mapChildItemToParentItem.Lookup(pParItemChild, pItemParent);

    switch (df.iCrcStatus) {
      case CRCSTATUS_NOTATTEMPTED:
        vf->color = RGB(206, 138, 23);
        vf->csTypeText = "disk + par c";
        vf->csDate.Format("%d", (span = timeNow - df.m_mtime, span.GetDays()));
        vf->csSize = ToSensible(df.m_size);
        vf->csStatusText = "pending";
        vf->csInfo1 = pItemParent->csDisplayFname;
        vf->csInfo2 = csDescription;
        break;
      case CRCSTATUS_OPENERROR:
        vf->color = 0xa0000a0;
        vf->csTypeText = "disk + par c";
        vf->csDate.Format("%d", (span = timeNow - df.m_mtime, span.GetDays()));
        vf->csSize = ToSensible(df.m_size);
        vf->csStatusText = "open error";
        vf->csInfo1 = pItemParent->csDisplayFname;
        vf->csInfo2 = csDescription;
        break;
      case CRCSTATUS_CALCULATED:

        // If CRC ok.
        if (pParItemChild->md5 == df.md5) {
          vf->color = 0x000000;
          vf->csTypeText = "disk + par c";
          vf->csDate.Format("%d", (span = timeNow - df.m_mtime, span.GetDays()));
          vf->csSize = ToSensible(df.m_size);
          vf->csStatusText = "md5 ok";
          vf->csInfo1 = pItemParent->csDisplayFname;
          vf->csInfo2 = csDescription;
        }
        // CRC bad.
        else {
          vf->color = 0xa0000a0;
          vf->csTypeText = "disk + par c";
          vf->csDate.Format("%d", (span = timeNow - df.m_mtime, span.GetDays()));
          vf->csSize = ToSensible(df.m_size);
          vf->csStatusText = "md5 bad";
          vf->csInfo1 = pItemParent->csDisplayFname;
          vf->csInfo2 = csDescription;;
        }

        break;
    }

    return true;
  }

  // DISK & PAR PARENT (ignore SFV if PAR exists).
  if (fDiskExists && fParParentExists) {
    switch (df.iCrcStatus) {
      case CRCSTATUS_NOTATTEMPTED:
        vf->color = RGB(206, 138, 23);
        vf->csTypeText = "disk + par p";
        vf->csDate.Format("%d", (span = timeNow - df.m_mtime, span.GetDays()));
        vf->csSize = ToSensible(df.m_size);
        vf->csStatusText = "pending";
        vf->csInfo1 = pParItemParent->csDisplayFname;
        vf->csInfo2 = csDescription;
        break;
      case CRCSTATUS_OPENERROR:
        vf->color = 0xa0000a0;
        vf->csTypeText = "disk + par p";
        vf->csDate.Format("%d", (span = timeNow - df.m_mtime, span.GetDays()));
        vf->csSize = ToSensible(df.m_size);
        vf->csStatusText = "open error";
        vf->csInfo1 = pParItemParent->csDisplayFname;
        vf->csInfo2 = csDescription;
        break;
      case CRCSTATUS_CALCULATED:

        // If CRC ok.
        if (pParItemParent->md5 == df.md5) {
          vf->color = 0x000000;
          vf->csTypeText = "disk + par p";
          vf->csDate.Format("%d", (span = timeNow - df.m_mtime, span.GetDays()));
          vf->csSize = ToSensible(df.m_size);
          vf->csStatusText = "md5 ok";
          vf->csInfo1 = pParItemParent->csDisplayFname;
          vf->csInfo2 = csDescription;
        }
        // CRC bad.
        else {
          vf->color = 0xa0000a0;
          vf->csTypeText = "disk + par p";
          vf->csDate.Format("%d", (span = timeNow - df.m_mtime, span.GetDays()));
          vf->csSize = ToSensible(df.m_size);
          vf->csStatusText = "md5 bad";
          vf->csInfo1 = pParItemParent->csDisplayFname;
          vf->csInfo2 = csDescription;;
        }

        break;
    }

    return true;
  }

  // DISK & SFV and NO PAR.
  if (fDiskExists && fSfvChildExists && !fParChildExists) {
    switch (df.iCrcStatus) {
      case CRCSTATUS_NOTATTEMPTED:
        vf->color = RGB(206, 138, 23);
        vf->csTypeText = "disk + sfv";
        vf->csDate.Format("%d", (span = timeNow - df.m_mtime, span.GetDays()));
        vf->csSize = ToSensible(df.m_size);
        vf->csStatusText = "pending";
        vf->csInfo1 = sf.csSFVFile;
        vf->csInfo2 = csDescription;
        break;
      case CRCSTATUS_OPENERROR:
        vf->color = 0xa0000a0;
        vf->csTypeText = "disk + sfv";
        vf->csDate.Format("%d", (span = timeNow - df.m_mtime, span.GetDays()));
        vf->csSize = ToSensible(df.m_size);
        vf->csStatusText = "open error";
        vf->csInfo1 = sf.csSFVFile;
        vf->csInfo2 = csDescription;
        break;
      case CRCSTATUS_CALCULATED:

        // If CRC ok.
        if (sf.crc == df.crc) {
          vf->color = 0x000000;
          vf->csTypeText = "disk + sfv";
          vf->csDate.Format("%d", (span = timeNow - df.m_mtime, span.GetDays()));
          vf->csSize = ToSensible(df.m_size);
          vf->csStatusText = "crc ok";
          vf->csInfo1 = sf.csSFVFile;
          vf->csInfo2 = csDescription;
        }
        // CRC bad.
        else {
          vf->color = 0xa0000a0;
          vf->csTypeText = "disk + sfv";
          vf->csDate.Format("%d", (span = timeNow - df.m_mtime, span.GetDays()));
          vf->csSize = ToSensible(df.m_size);
          vf->csStatusText = "crc bad";
          vf->csInfo1 = sf.csSFVFile;
          vf->csInfo2 = csDescription;;
        }

        break;
    }

    return true;
  }

  // ASSERT(vf->csDisplayFname != "");.
  return false;
}
/*
	The Automatic Select / Copy / Delete / Request functions
*/
/*
	Automatically select rar info items by criteria.
*/
bool CMultismartView::AutoSelect(void) {
  CVRarInfoCont rf;
  CString csFnameKey, csDisplayFname, csFnameRarInfoKey;
  // Display dialog to get criteria from user.
  CSelectDlg dlg;

  // Abort if user cancelled operation.
  if (dlg.DoModal() != IDOK) {
    return false;
  }

  GetDocument()->ProgressStart();
  ClearSelections();
  u32 iTotalCnt = static_cast<u32>(GetDocument()->CVRarInfo::map.GetCount());
  u32 iCurrCnt = 0;
  POSITION pos = GetDocument()->CVRarInfo::map.GetStartPosition();

  while (pos != NULL) {
    GetDocument()->CVRarInfo::map.GetNextAssoc(pos, csFnameRarInfoKey, rf);
    GetDocument()->ProgressSet("Selecting...", (int)(((float)iCurrCnt++ / (float)iTotalCnt) * 100));

    // Search list for this RAR info item.
    for (s32 iItem = 0; iItem < map.GetCount(); iItem++) {
      POSITION pos = arrMapPos[iItem];
      map.GetNextAssoc(pos, csFnameKey, csDisplayFname);

      if (csFnameKey == csFnameRarInfoKey) {
        // Found the RAR info item. Check if it's within selection parameters.

        // Never select empty RARs
        if (rf.u32DiskParts > 0) {
          CTimeSpan span = timeNow - rf.timeLast;

          if (span.GetDays() >= dlg.iDaysLast) {
            // Within Days period.
            if (dlg.fLessThan) {
              // Select if LESS missing parts.
              if (rf.u32KnownParts - rf.u32DiskParts < dlg.iParts) {
                lv->SetItemState(iItem, LVIS_SELECTED, LVIS_SELECTED);
              }
            }
            else {
              // Select if MORE missing parts.
              if (rf.u32KnownParts - rf.u32DiskParts > dlg.iParts) {
                lv->SetItemState(iItem, LVIS_SELECTED, LVIS_SELECTED);
              }
            }
          }
        }

        // Search for next item.
        break;
      }
    }
  }

  GetDocument()->ProgressStop();
  return true;
}
/*
	Given a RARINFO file, selected rar info file and corresponding RAR files.
	Called from OnLButtonDblClk();
*/
bool CMultismartView::SelectRAR(CString csFnameKeyIn, bool onlyexisting, bool onlynonexisting) {
  CVDiskCont df;
  CVRarInfoCont rf;
  CString csFnameKey, csFnameFirst, csFnamePart, csDisplayFname;
  GetDocument()->ProgressStart();
  u32 iTotalCnt = static_cast<u32>(map.GetCount()), iCurrCnt = 0, iLast = 0, iTmp = 0;

  for (s32 iItem = 0; iItem < map.GetCount(); iItem++) {
    iTmp = (int)(((float)iCurrCnt++ / (float)iTotalCnt) * 100);

    if (iTmp > iLast) {
      GetDocument()->ProgressSet("Selecting...", (int)(((float)iCurrCnt++ / (float)iTotalCnt) * 100));
      iLast = iTmp;
    }

    POSITION p = arrMapPos[iItem];
    map.GetNextAssoc(p, csFnameKey, csDisplayFname);

    // Select RAR heads.
    if (csFnameKey == csFnameKeyIn) {
      lv->SetItemState(iItem, LVIS_SELECTED, LVIS_SELECTED);
    }

    // Select RAR parts.
    if
    (
      (SplitRAR(csFnameKey, &csFnameFirst, &csFnamePart) && csFnameFirst == csFnameKeyIn)
      ||	csFnameKey == csFnameKeyIn
    ) {
      bool exists = GetDocument()->CVDisk::Lookup(csFnameKey, &df) || GetDocument()->CVRarInfo::map.Lookup
                    (
                      csFnameKey,
                      rf
                    );

      if ((exists && !onlynonexisting) || (!exists && !onlyexisting)) {
        lv->SetItemState(iItem, LVIS_SELECTED, LVIS_SELECTED);
      }
    }
  }

  GetDocument()->ProgressStop();
  return true;
}
/*
	Remove all selections. Can't believe there's no built in function to do this???
*/
void CMultismartView::ClearSelections(void) {
  for (s32 i = 0; i < lv->GetItemCount(); i++) {
    lv->SetItemState(i, 0, LVIS_SELECTED | LVIS_FOCUSED);
  }
}
/*
*/
bool CMultismartView::CopyRequestToClipboard(void) {
  return true;
}
/*
	Return a list of real and virtual files from actual files selected
*/
bool CMultismartView::Selected2Real(CMapStringToPtr* mapReal) {
  CString csFnameKey, csDisplayFname;
  CStringList listSelected;
  POSITION pos;
  bool fFound = false;
  // Create list of the selected files.
  TRACE("CMultismartView::Selected2Real()  create list of selected files\n");
  u32 iItem = -1;

  while ((iItem = lv->GetNextItem(iItem, LVNI_SELECTED)) != -1) {
    pos = arrMapPos[iItem];
    map.GetNextAssoc(pos, csFnameKey, csDisplayFname);
    listSelected.AddTail(csDisplayFname);
  }

  TRACE("CMultismartView::Selected2Real()  notify all containers\n");
  /*
  	notify containers of selected files. the containers examine the selected
  	files, and add real files to mapReal. Look in each container's GetSelect
  	function for details on which files are added
  */
  GetDocument()->ProgressStart();
  GetDocument()->ProgressSet("Converting selection to real and virtual files...", 00);
  fFound |= GetDocument()->CVDisk::GetSelect(&listSelected, mapReal);
  GetDocument()->ProgressSet("Converting selection to real and virtual files...", 20);
  fFound |= GetDocument()->CVPar::GetSelect(&listSelected, mapReal);
  GetDocument()->ProgressSet("Converting selection to real and virtual files...", 20);
  fFound |= GetDocument()->CVSfv::GetSelect(&listSelected, mapReal);
  GetDocument()->ProgressSet("Converting selection to real and virtual files...", 40);
  fFound |= GetDocument()->CVHighest::GetSelect(&listSelected, mapReal);
  GetDocument()->ProgressSet("Converting selection to real and virtual files...", 60);
  fFound |= GetDocument()->CVGap::GetSelect(&listSelected, mapReal);
  GetDocument()->ProgressSet("Converting selection to real and virtual files...", 80);
  fFound |= GetDocument()->CVRarInfo::GetSelect(&listSelected, mapReal);
  GetDocument()->ProgressStop();
  return fFound;
}
/*
*/
bool CMultismartView::CopyToClipboard(void) {
  CMapStringToPtr mapReal; // ptr not used
  // Key in mapReal is csDisplayFname.
  CString csFnameKey, csDisplayFname, csReal, csRealKey;
  POSITION pos;
  void* junk;
  CVDiskCont df;
  TRACE("CMultismartView::CopyToClipboard()  start\n");
  // Get real and virtual files from selection.
  Selected2Real(&mapReal);
  // Determine if virtual and/or real files have been selected.
  bool fVirtualSelected = false;
  bool fRealSelected = false;
  pos = mapReal.GetStartPosition();

  while (pos && (!fVirtualSelected || !fRealSelected)) {
    mapReal.GetNextAssoc(pos, csReal, junk);
    csRealKey = csReal;
    csRealKey.MakeLower();

    if (GetDocument()->CVDisk::Lookup(csRealKey, &df)) {
      fRealSelected = true;
    }
    else {
      fVirtualSelected = true;
    }
  }

  // If both virtual and existing files were selected, bring up dialog to ask
  // what kind of files to copy.
  if (fVirtualSelected && fRealSelected) {
    CCopyDlg d;

    if (d.DoModal() != IDOK) {
      // User cancelled the entire copy operation.
      return false;
    }

    if (d.radio_existing == RADIO_EXISTING) {
      // Delete virtual.
      pos = mapReal.GetStartPosition();

      while (pos) {
        mapReal.GetNextAssoc(pos, csReal, junk);
        csRealKey = csReal;
        csRealKey.MakeLower();

        if (!GetDocument()->CVDisk::Lookup(csRealKey, &df)) {
          mapReal.RemoveKey(csReal);
        }
      }
    }

    if (d.radio_existing == RADIO_VIRTUAL) {
      // Delete existing.
      pos = mapReal.GetStartPosition();

      while (pos) {
        mapReal.GetNextAssoc(pos, csReal, junk);
        csRealKey = csReal;
        csRealKey.MakeLower();

        if (GetDocument()->CVDisk::Lookup(csRealKey, &df)) {
          mapReal.RemoveKey(csReal);
        }
      }
    }
  }

  // Copy map to sortable array and sort array.
  CSortableStringArray arrReal;
  arrReal.SetSize(mapReal.GetCount());
  pos = mapReal.GetStartPosition();
  s32 arrCnt = 0;

  while (pos) {
    mapReal.GetNextAssoc(pos, csReal, junk);
    arrReal[arrCnt++] = csReal;
  }

  arrReal.Sort();
  // Create copy string.
  CString csFnames;

  for (arrCnt = 0; arrCnt < arrReal.GetSize(); arrCnt++) {
    csFnames += arrReal[arrCnt] + "\r\n";
  }

  // Copy string to clipboard.
  CopyCStringToClipboard(csFnames);
  return true;
}
/*
	Delete files.
	1. Create list of all selected files (virtual and real)
	2. Pass this list to all containers, letting the containers add actual files to another list.
	3. Ask user if he wants to delete preview the list of actual files that will be deleted
	4. Actually delete the files

	because deleting one actual file might make virtual files disappear anywhere
	in the list, it was a challenge to find a way to correctly position the marker
	after the delete. I wanted it to be positioned on the first deleted file. I
	solved in the following maner: to find the new position of the marker in the
	new list, make a "snapshot" of the old list, and after creating the new list,
	position the marker at the first file that is changed.

	TODO: handle file delete errors
*/
bool CMultismartView::DeleteSelected(void) {
  CMapStringToPtr mapReal; // ptr not used
  CString csFnameKey, csDisplayFname, csReal, csRealKey;
  POSITION pos;
  void* junk;
  CVDiskCont df;
  // Get real and virtual files from selection.
  Selected2Real(&mapReal);
  // Remove virtual files.
  pos = mapReal.GetStartPosition();

  while (pos) {
    mapReal.GetNextAssoc(pos, csReal, junk);
    csRealKey = csReal;
    csRealKey.MakeLower();

    if (!GetDocument()->CVDisk::Lookup(csRealKey, &df)) {
      mapReal.RemoveKey(csReal);
    }
  }

  // Give message and exit if no files to delete.
  if (!mapReal.GetCount()) {
    AfxMessageBox("You have selected only virtual files. \
The file(s) you have selected are not actual files and they \
can not be deleted. These files display information \
about or from actual files and they will be automatically \
deleted when the actual files are deleted.", MB_ICONINFORMATION);
    return false;
  }

  // Display delete confirmation.
  CDeleteConfirmDlg d(&mapReal, this);

  if (d.DoModal() != IDOK) {
    return false;
  }

  // Make snapshot.
  TRACE("CMultismartView::DeleteSelected()  taking snapshot\n");
  CStringArray arrSnap;
  arrSnap.SetSize(map.GetCount());

  for (int i = 0; i < map.GetCount(); i++) {
    // Use tmp p because getnextassoc changes it.
    POSITION p = arrMapPos[i];
    map.GetNextAssoc(p, csFnameKey, csDisplayFname);
    arrSnap[i] = csFnameKey;
  }

  // Do deletes.
  TRACE("CMultismartView::DeleteSelected()  deleting\n");
  GetDocument()->ProgressStart();
  u32 iDeleteTrouble = 0;
  pos = mapReal.GetStartPosition();
  int iTotal = static_cast<int>(mapReal.GetCount());
  int iDeleted = 0;

  while (pos) {
    mapReal.GetNextAssoc(pos, csReal, junk);

    if (!DeleteFile(csReal)) {
      iDeleteTrouble++;
    }

    GetDocument()->ProgressSet("Deleting files...", (int)(((float)iDeleted++ / (float)iTotal) * 100));
  }

  GetDocument()->ProgressStop();

  if (iDeleteTrouble) {
    CString csMsg;
    csMsg.Format("Trouble deleting %d of %d file(s)", iDeleteTrouble, mapReal.GetCount());
    AfxMessageBox(csMsg, MB_ICONWARNING);
  }

  // Reload folder, quick.
  Refresh(true);
  // Compare and position marker if a change is found.
  TRACE("CMultismartView::DeleteSelected()  start - comparing actual with snapshot\n");

  for (int i = 0; i < map.GetCount(); i++) {
    // Use tmp p because getnextassoc changes it.
    POSITION p = arrMapPos[i];
    map.GetNextAssoc(p, csFnameKey, csDisplayFname);

    if (arrSnap[i] != csFnameKey) {
      lv->SetItemState(i, LVIS_FOCUSED | LVIS_SELECTED, LVIS_FOCUSED | LVIS_SELECTED);
      lv->EnsureVisible(i, false);
      break;
    }
  }

  TRACE("CMultismartView::DeleteSelected()  end - comparing actual with snapshot\n");
  return true;
}
/* Input: Array containing archive part names. Output: */
bool CMultismartView::CreateCompressedSequence(CArray<s32, s32>* arrPart, CString* csCompress) {
  /* *csCompress = "compressed: "; for (int i = 0; i <= arrPart->GetUpperBound();
     i++) { CString msg; msg.Format("%d", arrPart->GetAt(i)); csCompress += msg; }
     csCompress += "\n"; arrPart->RemoveAll(); */
  *csCompress = "";
  CString msg;
  int i = 0;
  int iUpper = static_cast<int>(arrPart->GetUpperBound());
  int iCur, iCnt;
  bool fInRun = false;
  bool fGotOne = false;

  while (i <= iUpper && (iCur = arrPart->GetAt(i++))) {
    if (!fInRun) {
      if (!fGotOne) {
        iCnt = iCur;
        msg.Format("%d", iCnt);
        *csCompress += msg;
        fGotOne = true;
      }
      else {
        if (++iCnt == iCur) {
          *csCompress += "-";
          fInRun = true;
        }
        else {
          msg.Format("%d, ", iCnt);
          *csCompress += msg;
        }
      }
    }
    // In a run.
    else {
      if (++iCnt != iCur) {
        // End run.
        msg.Format("%d, ", iCnt);
        *csCompress += msg;
        fInRun = false;
      }
    }
  }

  *csCompress += "\n";
  TRACE(*csCompress);
  arrPart->RemoveAll();
  return true;
}

bool CMultismartView::RequestSelected(void) {
  CMapStringToPtr mapReal; // ptr not used
  CString csFnameKey, csDisplayFname, csReal, csRealKey;
  POSITION pos;
  void* junk;
  CVDiskCont df;
  // Get real and virtual files from selection.
  Selected2Real(&mapReal);
  // Delete files that exist from list.
  pos = mapReal.GetStartPosition();

  while (pos) {
    mapReal.GetNextAssoc(pos, csReal, junk);
    csRealKey = csReal;
    csRealKey.MakeLower();

    if (GetDocument()->CVDisk::Lookup(csRealKey, &df)) {
      mapReal.RemoveKey(csReal);
    }
  }

  // Give message and exit if no files to request.
  if (!mapReal.GetCount()) {
    AfxMessageBox
    (
      "You have selected only existing files. \
There are no files to request. Please select virtual (non existing) files \
to request.",
      MB_ICONINFORMATION
    );
    return false;
  }

  // Create requests.
  TRACE("CMultismartView::RequestSelected()  creating requests\n");
  // Copy map to sortable array and sort array.
  CSortableStringArray arrReal;
  arrReal.SetSize(mapReal.GetCount());
  u32 i = 0;
  pos = mapReal.GetStartPosition();

  while (pos) {
    mapReal.GetNextAssoc(pos, csReal, junk);
    arrReal[i++] = csReal;
  }

  arrReal.Sort();
  // Do magic.
  bool fInRAR = false;
  CString csFnameFull; // full name of file
  CString csFnameFirst; // first name of file
  CString csFnameLast; // last name of file
  CString csFnameFirstPrevious; // previous first name of file
  CString csTmp; // used for preparing a file name
  CString csClip; // resulting string (gets copied to clipboard in the end)
  CArray<s32, s32>	arrPart;
  arrPart.SetSize(1024, 1024);
  CString csCompress;
  arrPart.RemoveAll(); // Why is this necessary?
  // Process all file names.
  s32 arrCnt;

  for (arrCnt = 0; arrCnt < arrReal.GetSize(); arrCnt++) {
    csFnameFull = arrReal[arrCnt];

    // If RAR file.
    if (SplitRAR(csFnameFull, &csFnameFirst, &csFnameLast)) {
      // If not in a RAR.
      if (!fInRAR) {
        // Add name of RAR part.
        arrPart.Add(Rar2Int(csFnameLast));
        csTmp.Format("%s ", csFnameFirst);
        csClip += csTmp;
      }
      // Already in a RAR.
      else {
        // Continue RAR sequence if file name is same as last time.
        if (csFnameFirst == csFnameFirstPrevious) {
          arrPart.Add(Rar2Int(csFnameLast));
        }
        // End old RAR and start new RAR.
        else {
          CreateCompressedSequence(&arrPart, &csTmp);
          csClip += csTmp;
          arrPart.Add(Rar2Int(csFnameLast));
          csTmp.Format("\n%s ", csFnameFirst);
          csClip += csTmp;
        }
      }

      // Start RAR.
      csFnameFirstPrevious = csFnameFirst;
      fInRAR = true;
    }
    // not RAR
    else {
      // If was in a RAR sequence.
      if (fInRAR) {
        CreateCompressedSequence(&arrPart, &csTmp);
        csClip += csTmp;
        csTmp.Format("%s\n", csFnameFull);
        csClip += csTmp;
      }
      else {
        // Display SINGLE.
        csTmp.Format("%s\n", csFnameFull);
        csClip += csTmp;
      }

      fInRAR = false;
    }
  }

  if (fInRAR) {
    CreateCompressedSequence(&arrPart, &csTmp);
    csClip += csTmp;
  }

  TRACE(csClip);
  CopyCStringToClipboard(csClip);
  return true;
}
/* Command Handlers and UI Enable / Disable */
void CMultismartView::OnViewRefresh(void) {
  // Refresh(false); // load all containers.
  GetDocument()->CRCFilesAsyncStart();
}

void CMultismartView::OnUpdateViewRefresh(CCmdUI* pCmdUI) {
  // Refresh is always available.
  pCmdUI->Enable(TRUE);
}

void CMultismartView::OnViewPause(void) {
  UINT iButtonID;
  UINT iButtonStyle;
  int iButtonImage;
  CToolBar& tool = ((CMainFrame*)AfxGetMainWnd())->m_wndToolBar;
  tool.GetButtonInfo(tool.CommandToIndex(ID_VIEW_PAUSE), iButtonID, iButtonStyle, iButtonImage);
  GetDocument()->CRCFilesAsyncPause((iButtonStyle & TBBS_CHECKED) != 0);
}

void CMultismartView::OnUpdateViewPause(CCmdUI* pCmdUI) {
  pCmdUI->Enable(GetDocument()->CRCFilesAsyncIsRunning());
  pCmdUI->SetCheck(GetDocument()->CRCFilesAsyncIsPaused());
}

void CMultismartView::OnToolsAutoselect(void) {
  AutoSelect();
}

void CMultismartView::OnUpdateToolsAutoselect(CCmdUI* pCmdUI) {
  // Enable autoselect at all times.
  pCmdUI->Enable(GetListCtrl().GetItemCount() > 0);
}
void CMultismartView::OnToolsDuplicates(void) {
  GetDocument()->ProcessDuplicates();
  Refresh(false);
}

void CMultismartView::OnUpdateToolsDuplicates(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
}

void CMultismartView::OnToolsPar(void) {
  GetDocument()->RestoreAllSets();
}

void CMultismartView::OnUpdateToolsPar(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
}

void CMultismartView::OnToolsRequests(void) {
  RequestSelected();
}

void CMultismartView::OnUpdateToolsRequests(CCmdUI* pCmdUI) {
  // Enable request button if any items selected.
  pCmdUI->Enable(GetListCtrl().GetSelectedCount() > 0);
}

void CMultismartView::OnEditDelete(void) {
  DeleteSelected();
}

void CMultismartView::OnUpdateEditDelete(CCmdUI* pCmdUI) {
  // Enable delete button if any items selected.
  pCmdUI->Enable(GetListCtrl().GetSelectedCount() > 0);
}

void CMultismartView::OnEditCut(void) {
}

void CMultismartView::OnUpdateEditCut(CCmdUI* pCmdUI) {
}

void CMultismartView::OnEditCopy(void) {
  CopyToClipboard();
}

void CMultismartView::OnUpdateEditCopy(CCmdUI* pCmdUI) {
  // Enable copy button if any items selected.
  pCmdUI->Enable(GetListCtrl().GetSelectedCount() > 0);
}

void CMultismartView::OnEditPaste(void) {
  ASSERT(0);
}

void CMultismartView::OnUpdateEditPaste(CCmdUI* pCmdUI) {
  ASSERT(0);
}

void CMultismartView::OnEditUndo(void) {
  ASSERT(0);
}

void CMultismartView::OnUpdateEditUndo(CCmdUI* pCmdUI) {
  ASSERT(0);
}

void CMultismartView::OnChkShowexisting(void) {
  /* it may seem not to be such a good idea to just ! the variable, but if the
     message from the user clicking the control disappears, the variable doesn't get
     !'ed, and the UI updater below will then restore the control. so this is safe. */
  fShowExisting = !fShowExisting;
  VirtualFileSync();
}

void CMultismartView::OnUpdateViewChkShowexisting(CCmdUI* pCmdUI) {
  pCmdUI->Enable(TRUE);
  pCmdUI->SetCheck(fShowExisting);
}

void CMultismartView::OnChkShowmissing(void) {
  fShowMissing = !fShowMissing;
  VirtualFileSync();
}

void CMultismartView::OnUpdateViewChkShowmissing(CCmdUI* pCmdUI) {
  pCmdUI->Enable(TRUE);
  pCmdUI->SetCheck(fShowMissing);
}

void CMultismartView::OnUpdateSelected(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
  CString csSel;
  csSel.Format("Selected: %d / %d", GetListCtrl().GetSelectedCount(), GetListCtrl().GetItemCount());
  pCmdUI->SetText(csSel);
}

void CMultismartView::OnUpdateTotal(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
  pCmdUI->SetText(CString("Folder: ") + ToSensible(GetDocument()->iTotalSize));
}

void CMultismartView::OnUpdateFree(CCmdUI* pCmdUI) {
  pCmdUI->Enable();

  if (GetProcAddress(GetModuleHandle("kernel32.dll"), "GetDiskFreeSpaceExA")) {
    ULARGE_INTEGER i64FreeBytesToCaller, i64TotalBytes, i64FreeBytes;
    BOOL fResult = GetDiskFreeSpaceEx(NULL, &i64FreeBytesToCaller, &i64TotalBytes, &i64FreeBytes);
    pCmdUI->SetText(CString("Free: ") + ToSensible(i64FreeBytesToCaller.QuadPart));
  }
  else {
    DWORD dwSectPerClust, dwBytesPerSect, dwFreeClusters, dwTotalClusters;
    BOOL fResult = GetDiskFreeSpace(NULL, &dwSectPerClust, &dwBytesPerSect, &dwFreeClusters, &dwTotalClusters);
    pCmdUI->SetText(CString("Free: ") + ToSensible(dwBytesPerSect * dwSectPerClust * dwFreeClusters));
  }
}
