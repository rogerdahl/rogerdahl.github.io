#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// Find the first occurrence of Find in Str, where the search is limited to the
// first nStrLen characters of Find. Find must be null-terminated.
//
// Optimized by only calling strncmp if 1 character is known to match.
s8* strnstr(s8* pStr, const s8* pFind, u32 nStrLen) {
  s8 c, sc;

  // Exit immediately if pFind is empty.
  if ((c = *pFind++) != '\0') {
    u32 len = static_cast<u32>(strlen(pFind));

    do {
      do {
        if ((sc = *pStr++) == '\0' || nStrLen-- < 1) {
          return (NULL);
        }
      }
      while (sc != c);

      if (len > nStrLen) {
        return (NULL);
      }
    }
    while (strncmp(pStr, pFind, len) != 0);

    pStr--;
  }

  return pStr;
}

bool FindString(s8* pStr, s8* pFind, u32 nStrLen, u32* pnFoundOffset) {
  s8* pInitialPos = pStr;

  s8 c, sc;

  // Exit immediately if pFind is empty.
  if ((c = *pFind++) != '\0') {
    u32 len = static_cast<u32>(strlen(pFind));

    do {
      do {
        if ((sc = *pStr++) == '\0' || nStrLen-- < 1) {
          return false;
        }
      }
      while (sc != c);

      if (len > nStrLen) {
        return false;
      }
    }
    while (strncmp(pStr, pFind, len) != 0);

    pStr--;
  }

  if (pnFoundOffset) {
    *pnFoundOffset = static_cast<u32>(pStr - pInitialPos);
  }

  return true;
}

/*
	In:
		Filename

	Out:
		if file is a rar part or rar head
			return true
			cs1 = first name
			cs2 = lower case rar part name
		else
			return false

	Covers 400 rar parts + rar head.

	NEWEDIT: covers partxxx.rar too
*/
bool SplitRAR(CString csIn, CString* cs1, CString* cs2) {
  // Static avoids RegEx being recompiled every time SplitRAR is called. Recompiling is *very* expensive..
  //	static boost::RegEx r("^(.*)\\.([rstu]\\d\\d|rar).*$", true /* case insensitive */);
  static boost::RegEx r("^(.*?)\\.((part\\d{1,4}.rar)|([rstu]\\d\\d|rar))$", true /* case insensitive */); //NEWEDIT
  //	static boost::RegEx r("^(.*)\\.(part\\d\\d\\d\\.rar)$", true /* case insensitive */); //NEWEDIT

  if (r.Match(csIn)) {
    *cs1 = csIn.Mid(static_cast<u32>(r.Position(1)), static_cast<u32>(r.Length(1)));
    *cs2 = csIn.Mid(static_cast<u32>(r.Position(2)), static_cast<u32>(r.Length(2)));
    cs2->MakeLower();

    return true;
  }

  return false;
}

/*
	In:
		Filename

	Out:
		if file is a PAR head or Pxx part
			return true
			cs1 = first name
			cs2 = lower case rar part name
		else
			return false

	Covers 200 rar parts (PAR, Pxx, Qxx).
*/
bool SplitPAR(CString csIn, CString* cs1, CString* cs2) {
  // Static avoids RegEx being recompiled every time SplitRAR is called. recompiling is *very* expensive..
  //	static boost::RegEx r("^(.*)\\.([pq]\\d\\d|par).*$", true /* case insensitive */);
  static boost::RegEx r("^(.*)\\.([pq]\\d\\d|par)$", true /* case insensitive */); //NEWEDIT

  if (r.Match(csIn)) {
    *cs1 = csIn.Mid(static_cast<u32>(r.Position(1)), static_cast<u32>(r.Length(1)));
    *cs2 = csIn.Mid(static_cast<u32>(r.Position(2)), static_cast<u32>(r.Length(2)));
    cs2->MakeLower();

    return true;
  }

  return false;
}

// Convert RAR last-name to integer ("rar" = -1).

s32 Rar2Int(CString csIn) {
  csIn.MakeLower();

  if (csIn == "rar") {
    return -1;
  }

  return (csIn[0] - 'r') * 100 + (csIn[1] - '0') * 10 + (csIn[2] - '0');
}

// Convert integer to RAR last-name ("rar" = -1).
CString Int2Rar(s32 iPart) {
  if (iPart == -1) {
    return CString("rar");
  }

  char buf[4];
  buf[0] = 'r' + iPart / 100;
  buf[1] = '0' + (iPart % 100) / 10;
  buf[2] = '0' + iPart % 10;
  buf[3] = 0x00;

  return CString(buf);
}


/*
	0 B - 999 B = B
	1000 B - 500 K = K
	500 K - 500 M = M
	500 M -> G
*/
CString ToSensible(s64 i) {
  CString cs;

  double d = (double)i;

  if (i >= (s64)1000 * 1024 * 1024 * 1024) {
    cs.Format("%.1f TB", d / ((s64)1024 * 1024 * 1024 * 1024));
    return cs;
  }

  if (i >= 1000 * 1024 * 1024) {
    cs.Format("%0.1f GB", d / (1024 * 1024 * 1024));
    return cs;
  }

  if (i >= 500 * 1024) {
    cs.Format("%.1f MB", d / (1024 * 1024));
    return cs;
  }

  if (i >= 1000) {
    cs.Format("%.1f KB", d / 1024);
    return cs;
  }

  if (i >= 0) {
    cs.Format("%d Bytes", i);
    return cs;
  }

  cs = "Unknown";
  return cs;
}

CString GetLocaleTime(CTime ct) {
  CString csDate;
  SYSTEMTIME time;

  ct.GetAsSystemTime(time);
  GetDateFormat(NULL, DATE_SHORTDATE, &time, NULL, csDate.GetBuffer(1024), 1024);
  csDate.ReleaseBuffer();

  return csDate;
}

u8 GetRarPartType(CString csPart) {
  static boost::RegEx rxType1("^.*[rstu]\\d\\d|rar$", true /* case insensitive */); //NEWEDIT
  static boost::RegEx rxType2("^.*part\\d{1,4}.rar$", true /* case insensitive */); //NEWEDIT

  if (rxType1.Match(csPart)) {
    return 1;
  }

  if (rxType2.Match(csPart)) {
    return 2;
  }

  // Not a known type.
  MYASSERT(0);
  return 0;
}

CString GetRarPartNameFromNumber(u32 n, u8 nType) {
  CString csExt;

  if (nType == 1) {
    csExt.Format("%c%02d", (n / 100) + 'r', n % 100);
    return csExt;
  }

  if (nType == 2) {
    csExt.Format("part%03d.rar", n);
    return csExt;
  }

  // Not a known type.
  MYASSERT(0);
  return "";
}

// Convert RAR part extension to number (rar = 0, r00 = 1 etc). Can also be
// given complete filename.
u32 GetRarPartNumber(CString csPart) {
  static boost::RegEx rxType1("^.*([pq]\\d\\d|par)$", true /* case insensitive */); //NEWEDIT
  static boost::RegEx rxType2("^.*part(\\d{1,4}).rar$", true /* case insensitive */); //NEWEDIT
  csPart.MakeLower();
  CString csNum;

  // Handle type 1.
  if (rxType1.Match(csPart)) {
    csNum = csPart.Mid(static_cast<u32>(rxType1.Position(1)), static_cast<u32>(rxType1.Length(1)));

    if (csNum == "rar") {
      return 0;
    }

    u32 n((csNum[0] - 'r') * 100);
    n += (csNum[1] - '0') * 10;
    n += (csNum[2] - '0') + 1; // add one because r00 = 1, not 0
    return n;
  }

  // Handle type 2.
  if (rxType2.Match(csPart)) {
    csNum = csPart.Mid(static_cast<u32>(rxType2.Position(1)), static_cast<u32>(rxType2.Length(1)));
    return atoi(csNum);
  }

  // Was given something that doesn't look like a rar.
  return 0;
}

/*
	Compare RAR parts.

	r1 > r2		1
	r1 == r2	0
	r1 < r2		-1
*/
s32 CmpRarPartNames(CString r1, CString r2) {
  u32 n1(GetRarPartNumber(r1));
  u32 n2(GetRarPartNumber(r2));

  if (n1 == n2) {
    return 0;
  }
  else if (n1 > n2) {
    return 1;
  }
  else {
    return -1;
  }

  MYASSERT(0);
  return 0;
}

void LastErrorMessageBox(CString csMsg) {
  LPVOID lpMsgBuf;

  FormatMessage(
    FORMAT_MESSAGE_ALLOCATE_BUFFER |
    FORMAT_MESSAGE_FROM_SYSTEM |
    FORMAT_MESSAGE_IGNORE_INSERTS,
    NULL,
    GetLastError(),
    // Default language.
    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
    (LPTSTR) &lpMsgBuf,
    0,
    NULL
  );

  CString csMsg2;
  csMsg2.Format("\n\nCause: %s\n", lpMsgBuf);
  AfxMessageBox(csMsg + csMsg2, MB_ICONWARNING);

  LocalFree(lpMsgBuf);
}

CString& MyGetLastError() {
  static CString csErr;

  LPVOID lpMsgBuf;

  FormatMessage(
    FORMAT_MESSAGE_ALLOCATE_BUFFER |
    FORMAT_MESSAGE_FROM_SYSTEM |
    FORMAT_MESSAGE_IGNORE_INSERTS,
    NULL,
    GetLastError(),
    // Default language
    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
    (LPTSTR) &lpMsgBuf,
    0,
    NULL
  );

  csErr = (u8*)lpMsgBuf;

  return csErr;

  LocalFree(lpMsgBuf);
}

bool CopyCStringToClipboard(CString csTxt) {
  // Get a global mem block and fill it with csTxt.
  HGLOBAL hGmem = GlobalAlloc(GMEM_MOVEABLE, csTxt.GetLength() + 1);
  s8* pMem = (s8*)GlobalLock(hGmem);
  strcpy((char*)pMem, csTxt.GetBuffer(0));
  GlobalUnlock(hGmem);

  // Give mem block to Clipboard.
  if (!::OpenClipboard(NULL)) {
    AfxMessageBox("Cannot open the Clipboard", MB_ICONWARNING);
    return false;
  }

  if (!EmptyClipboard()) {
    AfxMessageBox("Cannot empty the Clipboard", MB_ICONWARNING);
    return false;
  }

  if (::SetClipboardData(CF_TEXT, hGmem) == NULL) {
    AfxMessageBox("Unable to set Clipboard data", MB_ICONWARNING);
    return false;
  }

  CloseClipboard();

  // Don't GlobalFree(hGmem) because Clipboard now owns the memory block.

  return true;
}

bool BstrToStr(BSTR Input, LPTSTR Result) {
  bool outval = false;

  int cbOriginalLen = WideCharToMultiByte(CP_ACP, NULL, Input, -1, NULL, 0, NULL, NULL);
  char* lpMultiByteStr = new char[cbOriginalLen + 1];
  ZeroMemory(lpMultiByteStr, cbOriginalLen);
  int retval = WideCharToMultiByte(CP_ACP, NULL, Input, cbOriginalLen,
                                   lpMultiByteStr, cbOriginalLen, NULL, NULL);
#ifdef UNICODE
  mbstowcs(Result, lpMultiByteStr, cbOriginalLen);
#else
  _tcscpy(Result, lpMultiByteStr);
#endif

  if (retval != 0) {
    outval = true;
  }

  delete [] lpMultiByteStr;

  return (outval);
}

bool StrToBstr(LPTSTR Input, BSTR Result) {
  bool outval = false;
  int needed, retval;

#ifndef UNICODE
  needed = MultiByteToWideChar(CP_ACP, NULL, Input, -1, NULL, NULL);
#else
  needed = _tcslen(Input);
#endif

#ifndef UNICODE
  wchar_t* temp = new wchar_t[needed];
  //Converting to BSTR
  retval = MultiByteToWideChar(CP_ACP, NULL, Input, -1, temp, needed);
  HRESULT hr = ::SysReAllocStringLen(&Result, temp, needed);
#else
  HRESULT hr = ::SysReAllocStringLen(&Result, Input, needed);
#endif

  if (SUCCEEDED(hr) && (retval != 0)) {
    outval = true;
  }

#ifndef UNICODE
  delete [] temp;
#endif

  return (outval);
}

//void AFXAPI SerializeElements(CArchive& ar, CString* pElements, INT_PTR nCount) {
//	SerializeElementsInsertExtract(ar, pElements, nCount);
//}
