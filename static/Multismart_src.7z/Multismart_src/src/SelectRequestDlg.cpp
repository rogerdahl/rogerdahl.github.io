#include "stdafx.h"
#include "Multismart.h"
#include "SelectRequestDlg.h"
#include "SelectDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CSelectRequestDlg::CSelectRequestDlg(CWnd* pParent /*=NULL*/)
  : CDialog(CSelectRequestDlg::IDD, pParent) {
  EnableAutomation();

  request_edit_daylast = 0;
  request_edit_parts = 1;
}


void CSelectRequestDlg::OnFinalRelease() {
  // When the last reference for an automation object is released,
  // OnFinalRelease is called. The base class will automatically delete the
  // object. Add additional cleanup required for your. Object before calling the
  // base class.
  CDialog::OnFinalRelease();
}

void CSelectRequestDlg::DoDataExchange(CDataExchange* pDX) {
  CDialog::DoDataExchange(pDX);
  DDX_Text(pDX, id_request_edit_daylast, request_edit_daylast);
  DDV_MinMaxUInt(pDX, request_edit_daylast, 0, 1000);
  DDX_Text(pDX, id_request_edit_parts, request_edit_parts);
  DDV_MinMaxUInt(pDX, request_edit_parts, 1, 1000);
}


BEGIN_MESSAGE_MAP(CSelectRequestDlg, CDialog)
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CSelectRequestDlg, CDialog)
END_DISPATCH_MAP()

static const IID IID_IDlgSelectRequest = { 0xc8d715bf, 0x2d79, 0x4779, { 0x88, 0x89, 0x4c, 0x1b, 0x3f, 0x71, 0x7e, 0xa7 } };

BEGIN_INTERFACE_MAP(CSelectRequestDlg, CDialog)
INTERFACE_PART(CSelectRequestDlg, IID_IDlgSelectRequest, Dispatch)
END_INTERFACE_MAP()


// CSelectRequestDlg message handlers.

BOOL CSelectRequestDlg::OnInitDialog()  {
  CDialog::OnInitDialog();

  // Fetch setup info from registry, and apply. Use defaults if no registry
  // info.

  HKEY	myhnd;
  DWORD	num, dsize;

  RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\dahlsys\\Multismart", 0, KEY_READ, &myhnd);

  dsize = sizeof(num);

  if (RegQueryValueEx(myhnd, "request_edit_daylast", NULL, NULL, (BYTE*)&num, &dsize)
      == ERROR_SUCCESS) {
    request_edit_daylast = num;
  }
  else {
    request_edit_daylast = 1;
  }

  dsize = sizeof(num);

  if (RegQueryValueEx(myhnd, "request_edit_parts", NULL, NULL, (BYTE*)&num, &dsize)
      == ERROR_SUCCESS) {
    request_edit_parts = num;
  }
  else {
    request_edit_parts = 5;
  }

  RegCloseKey(myhnd);

  UpdateData(false);

  // Return TRUE unless you set the focus to a control.
  return TRUE;
}

bool CSelectRequestDlg::MyVerify() {
  if (!UpdateData(true)) {
    return false;
  }

  HKEY	myhnd;
  DWORD	num, dsize = sizeof(num);
  CString csNum;

  RegCreateKeyEx(HKEY_CURRENT_USER, "Software\\dahlsys\\Multismart", 0, " ",
                 REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS | KEY_WRITE, NULL, &myhnd, NULL);

  num = request_edit_daylast;
  RegSetValueEx(myhnd, "request_edit_daylast", 0, REG_DWORD, (BYTE*)&num, dsize);

  num = request_edit_parts;
  RegSetValueEx(myhnd, "request_edit_parts", 0, REG_DWORD, (BYTE*)&num, dsize);

  RegCloseKey(myhnd);

  return true;
}

void CSelectRequestDlg::OnOK()  {
  GetParent()->GetParent()->SendMessage(UWM_CLICK_OK);
}

void CSelectRequestDlg::OnCancel()  {
  GetParent()->GetParent()->SendMessage(WM_CLOSE);
}
