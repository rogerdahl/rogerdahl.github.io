#include "stdafx.h"
#include "Multismart.h"
#include "MultismartDoc.h"
#include "DuplicatesThread.h"
#include <shlwapi.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

IMPLEMENT_DYNCREATE(CMultismartDoc, CDocument)

BEGIN_MESSAGE_MAP(CMultismartDoc, CDocument)
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CMultismartDoc, CDocument)
  DISP_FUNCTION(CMultismartDoc, "GetFileWanted", GetFileWanted, VT_BOOL, VTS_BSTR)
  DISP_FUNCTION(CMultismartDoc, "Open", Open, VT_BOOL, VTS_BSTR)
END_DISPATCH_MAP()

static const IID IID_IMultismart = { 0x1b31a0f9, 0x1971, 0x4ecd, { 0xb4, 0xc0, 0xa8, 0x52, 0x83, 0x47, 0x3d, 0x58 } };

BEGIN_INTERFACE_MAP(CMultismartDoc, CDocument)
INTERFACE_PART(CMultismartDoc, IID_IMultismart, Dispatch)
END_INTERFACE_MAP()

CMultismartDoc::CMultismartDoc() {
  EnableAutomation();

  AfxOleLockApp();
}

CMultismartDoc::~CMultismartDoc() {
  AfxOleUnlockApp();
}

BOOL CMultismartDoc::OnNewDocument() {
  // Don't automatically create new documents.
  return FALSE;
}

// CMultismartDoc serialization.

void CMultismartDoc::Serialize(CArchive& ar) {
  if (ar.IsStoring()) {
    // TODO: Add storing code here.
  }
  else {
    // TODO: Add loading code here.
  }
}

// CMultismartDoc diagnostics.

#ifdef _DEBUG
void CMultismartDoc::AssertValid() const {
  CDocument::AssertValid();
}

void CMultismartDoc::Dump(CDumpContext& dc) const {
  CDocument::Dump(dc);
}
#endif

// CMultismartDoc commands.

BOOL CMultismartDoc::GetFileWanted(LPCTSTR bstrFilename)  {
  CVGapCont itemGap;
  TRACE("%d", CVGap::map.GetCount());

  if (CVGap::map.Lookup(bstrFilename, itemGap)) {
    return TRUE;
  }
  else {
    return FALSE;
  }
}

void CMultismartDoc::OnCloseDocument()  {
  // Tried putting this in CVDisk destructor, but it caused a weird vtable
  // error, as if the document class was destroyed BEFORE the CVDisk class even
  // though CVDisk is a base class of CDocument.
  CRCFilesAsyncStop();
  CDocument::OnCloseDocument();
}

// Manipule display. See .h file for more info about why this is here.
bool CMultismartDoc::ProgressStart() {
#ifdef _DEBUG
  return true;
#endif
  //// Create progress bar in status bar.

  //RECT rc;
  //m_wndStatusBar.GetItemRect(1, &rc);
  //CProgressCtrl* wndProgress = new CProgressCtrl;
  //VERIFY (wndProgress->Create(WS_CHILD | WS_VISIBLE, rc, &m_wndStatusBar, 1));
  //return true;

  threadLoadProgress = AfxBeginThread(RUNTIME_CLASS(CProgressThread), THREAD_PRIORITY_HIGHEST);

  return true;
}

bool CMultismartDoc::ProgressSet(CString csMessage, u32 iProg) {
#ifdef _DEBUG
  return true;
#endif

  CString* csTransfer = new CString;
  *csTransfer = csMessage;
  threadLoadProgress->PostThreadMessage(UWM_UPDATEPROGRESS, (WPARAM)csTransfer, iProg);

  return true;
}

bool CMultismartDoc::ProgressStop() {
#ifdef _DEBUG
  return true;
#endif

  threadLoadProgress->PostThreadMessage(WM_QUIT, 0, 0);

  return true;
}

/*
	This function is used by classes instantiated by this CWnd-
	based class to send messages to this window.

	I have been speculating a lot about if this is the best way /
	most logical way for a child class to communicate with its
	parent.

	What I actually need in this case is a "callback" function. I
	have called a function in a child class, and I need to be
	notified about work that function does. Because that function
	runs in another thread, using an actual callback function is
	not a good idea as it would have to be made thread-safe. So I
	don't have any code in this function, I just post a message
	to this window. That way, this thread itself will be able to
	perform the function.

	The alternative to using a virtual function would be to make the CWnd
	or HWND of this window available to the child class so that it could
	post the messages itself.

	The biggest advantage with messages, as I see it, is that by
	using messages, things don't need to be made thread safe. Because
	instead of calling into a function from another thread, you are
	asking the thread that "owns" that function to call the function.
*/
void CMultismartDoc::PostMessageView(u32 m, WPARAM w, LPARAM l) {
  POSITION pos = GetFirstViewPosition();
  CView* pFirstView = GetNextView(pos);
  // This only works with one single view for each document.
  MYASSERT(pos == NULL);
  // SendMessage here deadlocks the app.
  pFirstView->PostMessage(m, w, l);
}
/*
	load all info into all classes
*/
bool CMultismartDoc::LoadFolder(bool fQuick) {
  ProgressStart();

  CVRarInfo::LoadFolder(fQuick);

  ProgressStop();

  return true;
}
/*
	Override.
	Async update CRC for all files in current folder that are in PAR/SFV files
*/
bool CMultismartDoc::CRCFilesAsyncStart() {
  // Create alphabetical list of files to CRC.

  CVDiskCont df;
  CVParChildItem* pf;
  CVParParentItem* pItemParent;
  CVSfvCont sf;
  CString csFnameKey, csDisplayFname;
  CSortableStringArray* csarrFnames = new CSortableStringArray;

  // Add PAR and SFV.
  POSITION pos = CVDisk::GetStartPosition();

  while (pos != NULL) {
    CVDisk::GetNextAssoc(&pos, &csFnameKey, &df);

    if (df.iCrcStatus < CRCSTATUS_CALCULATED &&
        (CVSfv::map.Lookup(csFnameKey, sf) ||
         CVPar::mapChildNameToItem.Lookup(csFnameKey, pf)) ||
        CVPar::mapParentNameToItem.Lookup(csFnameKey, pItemParent)) {
      csarrFnames->Add(df.csDisplayFname);
    }
  }

  csarrFnames->Sort();

  return CVDisk::CRCFilesAsyncStart(csarrFnames);
}
/*
	Process Duplicate files.
*/
bool CMultismartDoc::ProcessDuplicates() {
  // User confirm.
  CDuplicatesConfirmDlg dlgConfirm;

  if (dlgConfirm.DoModal() != IDOK) {
    return false;
  }

	// Create duplicates dialog
  //
	// RUNTIME_CLASS returns a pointer to a CRuntimeClass structure for the class
	// specified by class_name. Only CObject-derived classes declared with
  // DECLARE_DYNAMIC, DECLARE_DYNCREATE, or DECLARE_SERIAL will return pointers
	// to a CRuntimeClass structure.
  //
	// RD: It is possible to click the Dup button several times and the global
	// variables of CDuplicatesDlg remain different in each thread. This is
  // because CDuplicatesDlg is a CWinThread derived class, and AfxBeginThread
	// creates a new object each time which the thread runs in. So multiple
	// threads of CDuplicatesDlg do not share the same object.
  CDuplicatesThread* threadDuplicates = (CDuplicatesThread*)AfxBeginThread(RUNTIME_CLASS(CDuplicatesThread), THREAD_PRIORITY_ABOVE_NORMAL);

  u32 iCntDeleted = 0, iCntRenamed = 0;

  CVDiskCont dfDuplicate, dfReal;
  CVSfvCont sf;
  CVRarInfoCont rf;

  CString csFnameDuplicate, csFnameReal, csFnameRealKey;
  CString csFnameFirst, csFnameLast, csFnameFirstKey;
  CString csMsg;

  u32 crc;
  CMd5 md5File;

  // Match a 00nn file and a "Copy Of" file.
  boost::RegEx regexDuplicate("^(.*)-\\(?00\\d{2}\\)?\\.(.*)$|^Copy( \\(\\d+\\))? of (.*)$", true);

  // Iterate through all disk files.

  POSITION pos = CVDisk::GetStartPosition();

  while (pos != NULL) {
    CVDisk::GetNextAssoc(&pos, &csFnameDuplicate, &dfDuplicate);
    // Use display name instead of key.
    csFnameDuplicate = dfDuplicate.csDisplayFname;

    // Found a new disk file. now check if it is a duplicate file.

    if (regexDuplicate.Match(csFnameDuplicate)) {
      try {
        // Is an Duplicate file. now find the real name of the file.

        // Did first or last part match?
        if (regexDuplicate.Length(1) > 0)
          csFnameReal.Format("%s.%s",
                             csFnameDuplicate.Mid(
                               static_cast<u32>(regexDuplicate.Position(1)),
                               static_cast<u32>(regexDuplicate.Length(1))),
                             csFnameDuplicate.Mid(
                               static_cast<u32>(regexDuplicate.Position(2)),
                               static_cast<u32>(regexDuplicate.Length(2))));
        else
          csFnameReal.Format("%s",
                             csFnameDuplicate.Mid(
                               static_cast<u32>(regexDuplicate.Position(4)),
                               static_cast<u32>(regexDuplicate.Length(4))));

        csFnameRealKey = csFnameReal;
        csFnameRealKey.MakeLower();

        csMsg.Format("Examining DUPLICATE: %s\r\nORIGINAL: %s\r\n", csFnameDuplicate, csFnameReal);
        threadDuplicates->AddStr(csMsg);

        // Check if real file exists.
        if (CVDisk::Lookup(csFnameRealKey, &dfReal)) {
          // Check if real file has SFV parent.
          if (CVSfv::map.Lookup(csFnameRealKey, sf)) {
            // Has SFV parent. base health check on crc.
            threadDuplicates->AddStr("ORIGINAL exists and has an SFV parent. Check is based on CRC.\r\n");

            if (dfReal.iCrcStatus == CRCSTATUS_CALCULATED) {
              // Real file has been CRC'ed.
              if (dfReal.crc == sf.crc) {
                // Real file is healthy. Delete Duplicate file.
                CFile::Remove(GetWorkingFolder() + csFnameDuplicate);
                iCntDeleted++;
                threadDuplicates->AddStr("Deleted DUPLICATE because ORIGINAL has valid CRC.\r\n");
              }
              else { // (dfReal.crc == sf.crc)
                // Real file has incorrect CRC. check if Duplicate file matches CRC.
                threadDuplicates->AddStr("ORIGINAL does not have valid CRC.\r\n");

                if (CVDisk::CRCFile(csFnameDuplicate, &crc, &md5File)) {
                  // CRC'ed Duplicate file. Now compare.
                  csMsg.Format("Calculated CRC of DUPLICATE. Value: %x.\r\n", crc);
                  threadDuplicates->AddStr(csMsg);

                  if (crc == sf.crc) {
                    // Duplicate file matches CRC of real file. so replace real file.
                    CFile::Remove(GetWorkingFolder() + csFnameReal);
                    iCntDeleted++;
                    CFile::Rename(GetWorkingFolder() + csFnameDuplicate, GetWorkingFolder() + csFnameReal);
                    iCntRenamed++;
                    threadDuplicates->AddStr("Replaced ORIGINAL with DUPLICATE because replacement matches CRC of original file.\r\n");
                  }
                  else { // if (crc == sf.crc)
                    // Duplicate doesn't match CRC either, so delete Duplicate file.
                    CFile::Remove(GetWorkingFolder() + csFnameDuplicate);
                    iCntDeleted++;
                    threadDuplicates->AddStr("Deleted DUPLICATE because it doesn't match CRC of ORIGINAL.\r\n");
                  }
                }
                else { // if (CVDisk::CRCFile(csFnameDuplicate, &crc, &md5File))
                  // CRC'ing of Duplicate file failed.
                  threadDuplicates->AddStr("Was not able to CRC DUPLICATE. Will ignore it for now. Try again later.\r\n");
                }
              }
            }
            else { // if (dfReal.iCrcStatus == CRCSTATUS_CALCULATED)
              // Real file has not been CRC'ed.
              threadDuplicates->AddStr("Ignored DUPLICATE because ORIGINAL has not been CRC'ed. Run CRCs and try again later.\r\n");
            }
          }
          else { // if (CVSfv::map.Lookup(csFnameRealKey, sf))
            // Real file does not have SFV parent. base health check on size.

            threadDuplicates->AddStr("ORIGINAL exists but does not have an SFV parent. Check is based on file sizes.\r\n");

            CVHighestCont hf;
            CString csFnameFirst, csFnameLast, csFnameFirstKey;

            if (SplitRAR(csFnameDuplicate, &csFnameFirst, &csFnameLast)) {
              // Real file is a rar file. Find size info from highestfiles.
              CString csFnameFirstKey = csFnameFirst;
              csFnameFirstKey.MakeLower();

              if (CVHighest::map.Lookup(csFnameFirstKey, hf)) {
                // Found entry in highestfiles.
                if (dfReal.m_size == hf.u64MaxSize) {
                  // Real file is a RAR part that has same size as other parts in the archive.
                  CFile::Remove(GetWorkingFolder() + csFnameDuplicate);
                  iCntDeleted++;
                  threadDuplicates->AddStr("Deleted DUPLICATE because ORIGINAL has correct size.\r\n");
                }
                else { // (dfReal.m_size == hf.u64MaxSize)
                  // Real file is a RAR part that does not have correct size..
                  if (dfDuplicate.m_size <= dfReal.m_size) {
                    // Real file does not have correct size but Duplicate file is smaller.
                    CFile::Remove(GetWorkingFolder() + csFnameDuplicate);
                    iCntDeleted++;
                    threadDuplicates->AddStr("Deleted DUPLICATE because it is smaller or same size as ORIGINAL (Neither ORIGINAL nor DUPLICATE has correct size.)\r\n");
                  }
                  else { // if (dfDuplicate.m_size <= dfReal.m_size)
                    CFile::Remove(GetWorkingFolder() + csFnameReal);
                    iCntDeleted++;
                    CFile::Rename(GetWorkingFolder() + csFnameDuplicate, GetWorkingFolder() + csFnameReal);
                    iCntRenamed++;
                    threadDuplicates->AddStr("Replaced DUPLICATE with REAL because replacement has more correct size (Neither original or replacement file has correct size.)\r\n");
                  }
                }
              }
              else { // if (CVHighest::map.Lookup(csFnameFirstKey, hf))
                // RAR file not in highestfiles map.
                ASSERT(false);
              }
            }
            else { // if (SplitRAR(csFnameDuplicate, &csFnameFirst, &csFnameLast))
              // Real file is not RAR file. Simply use the biggest file.
              if (dfReal.m_size < dfDuplicate.m_size) {
                CFile::Remove(GetWorkingFolder() + csFnameReal);
                iCntDeleted++;
                CFile::Rename(GetWorkingFolder() + csFnameDuplicate, GetWorkingFolder() + csFnameReal);
                iCntRenamed++;
                threadDuplicates->AddStr("Replaced ORIGINAL with DUPLICATE because DUPLICATE is larger.\r\n");
              }
              else { // if (dfReal.m_size < dfDuplicate.m_size)
                CFile::Remove(GetWorkingFolder() + csFnameDuplicate);
                iCntDeleted++;
                threadDuplicates->AddStr("Deleted DUPLICATE because it is smaller or same size as ORIGINAL.\r\n");
              }
            }
          }
        }
        else { // if (CVDisk::Lookup(csFnameRealKey, &dfReal))
          // Real file doesn't exist. Just rename Duplicate file.
          CFile::Rename(GetWorkingFolder() + csFnameDuplicate, GetWorkingFolder() + csFnameReal);
          iCntRenamed++;
          threadDuplicates->AddStr("Renamed DUPLICATE to ORIGINAL because ORIGINAL doesn't exist.\r\n");
        }

        threadDuplicates->AddStr("\r\n");
      }
      catch (CException* e) {
        threadDuplicates->AddStr("Trouble dealing with file. Maybe it is open in another app. Try again later.\r\n\r\n");
        e->Delete();
      }
    }
  }

  csMsg.Format("Deleted %d file(s)\r\nRenamed %d files(s)", iCntDeleted, iCntRenamed);
  threadDuplicates->AddStr(csMsg);

  return true;
}

/*
	called when a new folder is opened though Automation.
*/
BOOL CMultismartDoc::Open(LPCTSTR bstrFolder)  {
  csFolder = bstrFolder;
  LoadFolder(false);

  return TRUE;
}

/*
	framework calls this as part of document creation process. I override it so that
	I can copy the given lpszPathName to csFolder.
*/
BOOL CMultismartDoc::OnOpenDocument(LPCTSTR lpszPathName)  {
  if (lpszPathName == "") {
    return FALSE;
  }

  csFolder = lpszPathName;
  PathAddBackslash(csFolder.GetBuffer(MAX_PATH));
  csFolder.ReleaseBuffer();

  return TRUE;
}

/*
	framework calls this when setting the title for the window. I override it
	so that I can set the title as the full path name instead of just a short title
*/
void CMultismartDoc::SetTitle(LPCTSTR lpszTitle)  {
  if (csFolder.GetLength() > 0) {
    CDocument::SetTitle(csFolder.Left(csFolder.GetLength() - 1));
  }
}
