#pragma once

class CDuplicatesDlg : public CDialog {
  public:
    // Standard constructor.
    CDuplicatesDlg(CWnd* pParent = NULL);

    // Dialog Data.
    enum { IDD = id_dlg_duplicates };
    CRichEditCtrl	rich_info;

    // Overrides.
  protected:
    // DDX/DDV support.
    virtual void DoDataExchange(CDataExchange* pDX);
    virtual void PostNcDestroy();

    // Implementation.
  protected:

    virtual void OnOK();
    DECLARE_MESSAGE_MAP()
};
