#pragma once

class CMainFrame : public CMDIFrameWnd {
    DECLARE_DYNAMIC(CMainFrame)
  public:
    CMainFrame();

    // Overrides.
    virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

    // Implementation.
  public:
    virtual ~CMainFrame();
#ifdef _DEBUG
    virtual void AssertValid() const;
    virtual void Dump(CDumpContext& dc) const;
#endif

    // Moved this to public so I can send messages to it from View.
    CDialogBar	m_wndDlgBar;
    CStatusBar  m_wndStatusBar;
    CToolBar    m_wndToolBar;
    CReBar      m_wndReBar;

    // Generated message map functions.
  protected:
    // These are here to clear the status bar when no view handlers exist.
    afx_msg void OnUpdateSelected(CCmdUI* pCmdUI);
    afx_msg void OnUpdateTotal(CCmdUI* pCmdUI);
    afx_msg void OnUpdateFree(CCmdUI* pCmdUI);
    afx_msg void OnUpdateViewChkShowexisting(CCmdUI* pCmdUI);
    afx_msg void OnUpdateViewChkShowmissing(CCmdUI* pCmdUI);
    afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
    afx_msg void OnViewDialogBar();
    afx_msg void OnUpdateViewDialogBar(CCmdUI* pCmdUI);
    DECLARE_MESSAGE_MAP()
};
