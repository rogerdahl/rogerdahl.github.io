#include "stdafx.h"
#include "multismart.h"
#include "Base64.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CBase64::CBase64() {

}

CBase64::~CBase64() {
}
/*
Convert binary->char (3 bytes becomes 4 chars).

Buffer must be ordered with the most-significant-byte first.

nInBufLen must be divisible by 3.
*/
bool CBase64::Encode(s8* pInBuf, s8* pOutBuf, u32 nInBufLen) {
  u8 dtable[256];
  u32 i;
  u32 nInCnt = 0;
  u32 nOutCnt = 0;

  // Build conversion table.
  for (i = 0; i  <  9; i++) {
    dtable[i] = 'A' + i;
    dtable[i + 9] = 'J' + i;
    dtable[26 + i] = 'a' + i;
    dtable[26 + i + 9] = 'j' + i;
  }

  for (i = 0; i < 8; i++) {
    dtable[i + 18] = 'S' + i;
    dtable[26 + i + 18] = 's' + i;
  }

  for (i = 0; i < 10; i++) {
    dtable[52 + i] = '0' + i;
  }

  dtable[62] = '+';
  dtable[63] = '/';

  // Perform conversion.
  while (nInCnt < nInBufLen - 3) {
    u8 igroup[3];
    igroup[0] = igroup[1] = igroup[2] = 0;

    // Read three input bytes.
    for (int n = 0; n < 3; n++) {
      igroup[n] = pInBuf[nInCnt++];
    }

    // Create 4 characters.
    pOutBuf[nOutCnt + 0] = dtable[igroup[0] >> 2];
    pOutBuf[nOutCnt + 1] = dtable[((igroup[0] & 3) << 4) | (igroup[1] >> 4)];
    pOutBuf[nOutCnt + 2] = dtable[((igroup[1] & 0xF) << 2) | (igroup[2] >> 6)];
    pOutBuf[nOutCnt + 3] = dtable[igroup[2] & 0x3F];
    nOutCnt += 4;

    // If 72 chars, create new line.
    if (!(nOutCnt % 72)) {
      strcpy(pOutBuf, "=\r\n");
      pOutBuf += 3;
    }
  }

  return true;
}

/*
Convert 4 chars -> 3 bytes (binary)

nInBufLen must be divisible by 4.
*/
bool CBase64::Decode(s8* pInBuf, s8* pOutBuf, u32 nInBufLen) {
  int i;
  u8 dtable[256];

  // Build conversion table.
  for (i = 0; i < 255; i++) {
    dtable[i] = 0x80;
  }

  for (i = 'A'; i <= 'I'; i++) {
    dtable[i] = 0 + (i - 'A');
  }

  for (i = 'J'; i <= 'R'; i++) {
    dtable[i] = 9 + (i - 'J');
  }

  for (i = 'S'; i <= 'Z'; i++) {
    dtable[i] = 18 + (i - 'S');
  }

  for (i = 'a'; i <= 'i'; i++) {
    dtable[i] = 26 + (i - 'a');
  }

  for (i = 'j'; i <= 'r'; i++) {
    dtable[i] = 35 + (i - 'j');
  }

  for (i = 's'; i <= 'z'; i++) {
    dtable[i] = 44 + (i - 's');
  }

  for (i = '0'; i <= '9'; i++) {
    dtable[i] = 52 + (i - '0');
  }

  dtable['+'] = 62;
  dtable['/'] = 63;
  dtable['='] = 0;

  u32 nInCnt = 0;
  u32 nOutCnt = 0;

  // Convert buffer (char -> binary).
  while (nInCnt < nInBufLen - 4) {
    u8 a[4], pTmpBin[4];

    for (i = 0; i < 4; i++) {
      char c = pInBuf[nInCnt];

      if (dtable[c] & 0x80) {
        TRACE("Illegal character '%c' in input file.\n", c);
        return false;

        i--;
        continue;
      }

      a[i] = c;
      pTmpBin[i] = dtable[c];
    }

    pOutBuf[nOutCnt + 0] = (pOutBuf[nOutCnt + 0] << 2) | (pTmpBin[1] >> 4);
    pOutBuf[nOutCnt + 1] = (pOutBuf[nOutCnt + 1] << 4) | (pTmpBin[2] >> 2);
    pOutBuf[nOutCnt + 2] = (pOutBuf[nOutCnt + 2] << 6) |  pTmpBin[3];
    nOutCnt += 3;
    // Skip ='s (or something).
    i = a[2] == '=' ? 1 : (a[3] == '=' ? 2 : 3);
  }

  return true;
}

/*
UUDecode

Assumes about data in pInBuf:
- 1st byte in buffer is start of a uu data line
- no partial or truncated lines
- all lines end with \r\n

Returns:
- true while there's more to decode
- false when last chunk has been decoded

nInBufSize is signed because it may become negative.
*/
#define DEC(c) (((c) - ' ') & 077)
bool decode(s8* pInBuf, u8* pOutBuf, s32 nInBufSize, u32* pnOutBufSize) {
  //	MYASSERT(nInBufSize >= 3); // shortest possible line within uu is `\r\n. not true. could get \r\n

  u32 nOutBufCnt = 0;

  while (nInBufSize > 0) {
    // Fast-forward over any empty lines.
    if (!strncmp(pInBuf, "\r\n", 2)) {
      pInBuf += 2;
      nInBufSize -= 2;
      continue;
    }

    s8 nChars = DEC(pInBuf[0]); // line starts with count of bytes encoded in the line

    if ((nChars == 0)) {
      // Found end marker `.
      *pnOutBufSize = nOutBufCnt;
      return false; // have decoded last line of file
    }

    // Calculate expected # of chars and pad if necessary.
    /*		u32 nExpected = ((nChars + 2) / 3)<<2; // number of chars needed to encode nChars
    for (u32 i = strlen(pInBuf) - 1; i <= nExpected; i++)
    pInBuf[i] = ' ';
    */
    // Check that line contains expected number of chars. see above.
    MYASSERT(((nChars + 2) / 3) << 2 == strstr(pInBuf, "\r\n") - pInBuf - 1);

    pInBuf++; // skip byte count
    nInBufSize--;

    while (nChars > 0) { // nChars >= 3 until end of file, when it may be 1, 2 or 3
      MYASSERT(nInBufSize < 1024 * 1024); // sanity check
      MYASSERT(nChars < 200);

      if (nChars >= 1) {
        pOutBuf[nOutBufCnt++] = DEC(pInBuf[0]) << 2 | DEC(pInBuf[1]) >> 4;
      }

      if (nChars >= 2) {
        pOutBuf[nOutBufCnt++] = DEC(pInBuf[1]) << 4 | DEC(pInBuf[2]) >> 2;
      }

      if (nChars >= 3) {
        pOutBuf[nOutBufCnt++] = DEC(pInBuf[2]) << 6 | DEC(pInBuf[3]);
      }

      pInBuf += 4;
      nInBufSize -= 4;
      nChars -= 3;
    }

    pInBuf += 2; // skip \r\n
    nInBufSize -= 2;
  }

  *pnOutBufSize = nOutBufCnt;
  return true; // there's more parts
}

// M12341234\r\n
// M12341234\r\n
// \1234\r\n
// `\r\n
