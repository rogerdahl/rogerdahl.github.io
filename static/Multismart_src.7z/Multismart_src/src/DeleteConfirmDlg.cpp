#include "stdafx.h"
#include "Multismart.h"
#include "DeleteConfirmDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CDeleteConfirmDlg dialog.


CDeleteConfirmDlg::CDeleteConfirmDlg(CMapStringToPtr* mapRealIn, CWnd* pParent)
  : CDialog(CDeleteConfirmDlg::IDD, pParent) {
  mapReal = mapRealIn;

  chk_nomore = FALSE;
}


void CDeleteConfirmDlg::DoDataExchange(CDataExchange* pDX) {
  CDialog::DoDataExchange(pDX);
  DDX_Control(pDX, id_list_files, list_files);
  DDX_Control(pDX, id_static_warning, static_warning);
  DDX_Check(pDX, id_chk_nomore, chk_nomore);
}


BEGIN_MESSAGE_MAP(CDeleteConfirmDlg, CDialog)
END_MESSAGE_MAP()


// CDeleteConfirmDlg message handlers.

BOOL CDeleteConfirmDlg::OnInitDialog()  {
  CDialog::OnInitDialog();

  // Set icon.

  HICON h = LoadIcon(NULL, IDI_WARNING);
  static_warning.SetIcon(h);

  // Fill list.

  void* junk;
  CString csReal;
  POSITION p = mapReal->GetStartPosition();

  while (p) {
    mapReal->GetNextAssoc(p, csReal, junk);
    list_files.AddString(csReal);
  }

  // return TRUE unless you set the focus to a control
  return TRUE;
}

bool CDeleteConfirmDlg::AddFile(CString csFname) {
  return list_files.AddString(csFname) != 0;
}

void CDeleteConfirmDlg::OnOK()  {
  UpdateData(TRUE);

  HKEY	myhnd;
  DWORD	num, dsize = sizeof(num);

  if (chk_nomore) {
    // User selected to remove confirmation from now on so create registry key.

    RegCreateKeyEx(HKEY_CURRENT_USER, "Software\\dahlsys\\multismart", 0, " ",
                   REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS | KEY_WRITE, NULL, &myhnd, NULL);
    num = 1;
    RegSetValueEx(myhnd, "chk_hide_delete_confirmation", 0, REG_DWORD, (BYTE*)&num, dsize);
  }

  CDialog::OnOK();
}

void CDeleteConfirmDlg::OnCancel()  {
  CDialog::OnCancel();
}

INT_PTR CDeleteConfirmDlg::DoModal()  {
  // Return IDOK if dialog has been disabled.

  HKEY	myhnd;
  DWORD	num, dsize = sizeof(num);

  RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\dahlsys\\multismart", 0, KEY_READ, &myhnd);

  if (RegQueryValueEx(myhnd, "chk_hide_delete_confirmation", NULL, NULL, (BYTE*)&num, &dsize) == ERROR_SUCCESS) {
    // Dialog has been disabled, so return IDOK.
    return IDOK;
  }

  return CDialog::DoModal();
}
