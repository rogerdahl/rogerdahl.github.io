#include "stdafx.h"
#include "mytempl.h"
#include "vpar.h"

// Tried using ConstructElements to automatically increase reference counter for
// "smart pointer", but pElements has not been initialized with pointer to
// object when ConstructElements are called so can't reach object from here. The
// alternative is to "new" the object here. For that to be usable, an object has
// to be mapped first, a pointer retrieved and then the object filled in. I
// might want to consider doing that later because "new"-ing here might have
// performance benefits as I can use the in-place new that the default version
// of ConstructElements uses and by setting a map size, I can new many objects
// at the same time.

/*
template<> void AFXAPI ConstructElements<CVParChildItem*>(CVParChildItem** pElements, int nCount)
{
	TRACE("ConstructElements<CVParChildItem*> %d %d\n", pElements, nCount);
	for (int i = 0; i < nCount; i++)
	{
		TRACE("%d\n", pElements[i]->iRefCnt); <-- error. pElements[i] doesn't point to anything yet
		(pElements[i]->iRefCnt)++;
	}
}
*/

//template<> void AFXAPI DestructElements<CVParSetItem*>(CVParSetItem** pElements, int nCount)
//{
//	for (int i = 0; i < nCount; i++)
//	{
//		if (! --(pElements[i]->iRefCnt))
//		{
////			TRACE("DestructElements<CVParParentItem*> %d %d %s\n", pElements, nCount, (*pElements)->csName);
//			delete pElements[i];
//		}
//	}
//}
//
//template<> void AFXAPI DestructElements<CVParParentItem*>(CVParParentItem** pElements, int nCount)
//{
//	for (int i = 0; i < nCount; i++)
//	{
//		if (! --(pElements[i]->iRefCnt))
//		{
////			TRACE("DestructElements<CVParParentItem*> %d %d %s\n", pElements, nCount, (*pElements)->csDisplayFname);
//			delete pElements[i];
//		}
//	}
//}
//
//template<> void AFXAPI DestructElements<CVParChildItem*>(CVParChildItem** pElements, int nCount)
//{
//	for (int i = 0; i < nCount; i++)
//	{
//		if (! --(pElements[i]->iRefCnt))
//		{
////			TRACE("DestructElements<CVParChildItem*> %d %d %s\n", pElements, nCount, (*pElements)->csDisplayFname);
//			delete pElements[i];
//		}
//	}
//}
