#include "stdafx.h"
#include "Multismart.h"
#include "VDescr.h"
#include "DescriptionCleanDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CVDescr::CVDescr() {
}

CVDescr::~CVDescr() {
}

bool CVDescr::LoadFolder(bool fQuick) {
  CVDisk::LoadFolder(fQuick);

  if (fQuick) {
    TRACE("CVDescr::LoadFolder() - skipping\n");
  }
  else {
    ProgressSet("Reading Descript.ion database...", 45);
    LoadDescriptions();
  }

  return true;
}

// CVDescr holds a map of the contents of descript.ion if there is one. This
// syncs the map with the file.
//
// Instead of buff1 and buff2 I first used csDescription.GetBuffer(10*1024) and
// csDescription.ReleaseBuffer(), but for some reason this tied up *huge*
// amounts of memory.
bool CVDescr::LoadDescriptions() {
  TRACE("CVDescr::LoadDescriptions()  Started\n");

  CString csLine;
  CString csDescrFname;
  CString csDescription;
  CStdioFile cF;
  CVDiskCont df;

  u32 iCntTotalDescriptions = 0, iCntUsedDescriptions = 0;

  if (cF.Open(GetWorkingFolder() + "descript.ion", CFile::modeRead)) {
    // There is a descript.ion file. Now start loading from it.

    // Filename.
    char* buff1 = (char*)malloc(MAX_PATH);
    // Description.
    char* buff2 = (char*)malloc(10 * 1024);

    map.RemoveAll();

    while (cF.ReadString(csLine)) {
      iCntTotalDescriptions++;

      sscanf(csLine, "\"%[^\"]\"%[^\n]", buff1, buff2);
      csDescrFname = buff1;
      csDescription = buff2;

      csDescrFname.TrimRight();
      csDescrFname.TrimLeft();
      csDescrFname.MakeLower();
      csDescription.TrimRight();
      csDescription.TrimLeft();

      if (CVDisk::Lookup(csDescrFname, &df)) {
        map.SetAt(csDescrFname, csDescription);
        iCntUsedDescriptions++;
        // TRACE("CVDisk::SyncFolder() Added to descript.ion map:  %s - %s\n", csDescrFname, csDescription);.
      }
    }

    delete buff1;
    delete buff2;

    cF.Close();

    // Check if new description file should be written.

    if (iCntUsedDescriptions < iCntTotalDescriptions / 2) {
      // More than 50 percent of descriptions are unused. Should write new file.

      CDescrCleanConfirmDlg dlgConfirm;

      if (dlgConfirm.DoModal() == IDOK) {
        // Write new descript.ion file (cleaned up).

        TRACE("CVDescr::LoadDescriptions()  Writing new Descript.ion file\n");

        if (cF.Open(GetWorkingFolder() + "descript.ion", CFile::modeWrite | CFile::modeCreate)) {
          CString c1, c2, c3;
          POSITION pos = map.GetStartPosition();

          while (pos != NULL) {
            map.GetNextAssoc(pos, c1, c2);
            c3.Format("\"%s\" %s\n", c1, c2);
            cF.WriteString(c3);
          }
        }
        else {
          AfxMessageBox("Descript.ion Cleaning\n\nCould not write new Descript.ion file", MB_ICONSTOP);
        }
      }
    }

    TRACE("CVDescr::LoadDescriptions() Ended - True\n");

    return true;
  }


  TRACE("CVDescr::LoadDescriptions() Ended - False\n");

  return false;
}

