#pragma once

#include "DuplicatesDlg.h"
#include "DuplicatesConfirmDlg.h"
#include "ProgressThread.h"
#include "VRarInfo.h"

class CMultismartDoc : public CDocument, public CVRarInfo {
  public:
    bool LoadFolder(bool fQuick);
    // Async update CRC for all files in current folder that are in PAR/SFV
    // files.
    bool CRCFilesAsyncStart();
    bool PostString(CWinThread* thread, CString csMsg);
    bool ProcessDuplicates();
    // Progress dialog.
    bool ProgressStart();
    bool ProgressSet(CString, u32);
    bool ProgressStop();

    void PostMessageView(u32, WPARAM w, LPARAM l);
    CString GetWorkingFolder() {
      return csFolder;
    };
  private:
    // csKeyFname and csDisplayFname
    CMapStringToString map;
    // Sort elements in map.
    CArray<POSITION, POSITION&> arrMapPos;
    // Set by VirtualFileSync. used for calc in DrawItem and AutoSelect.
    CTime timeNow;
    CWinThread* threadLoadProgress;

    // The folder that this document monitors.
    CString csFolder;

  public:
    virtual BOOL OnNewDocument();
    virtual void Serialize(CArchive& ar);
    virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
    virtual void SetTitle(LPCTSTR lpszTitle);
    virtual void OnCloseDocument();

    virtual ~CMultismartDoc();
#ifdef _DEBUG
    virtual void AssertValid() const;
    virtual void Dump(CDumpContext& dc) const;
#endif

  // Create from serialization only.
  protected:
    CMultismartDoc();
    DECLARE_DYNCREATE(CMultismartDoc)
    DECLARE_MESSAGE_MAP()

    // Generated OLE dispatch map functions.
    afx_msg BOOL GetFileWanted(LPCTSTR bstrFilename);
    afx_msg BOOL Open(LPCTSTR bstrFolder);
    DECLARE_DISPATCH_MAP()
    DECLARE_INTERFACE_MAP()
};
