#pragma once

// Sent by tab windows to click ok button.
#define UWM_CLICK_OK_MSG _T("UWM_CLICK_OK_34098REUSHSDOHSGDHWEROITYWTO98EWRGSLDIUHWAE")
static UINT UWM_CLICK_OK = ::RegisterWindowMessage(UWM_CLICK_OK_MSG);


// CSelectDlg dialog.

class CSelectDlg : public CDialog {
  public:
    u32 iParts;
    u32 iDaysLast;
    bool fLessThan;
    CSelectDlg(CWnd* pParent = NULL); // standard constructor

    // Dialog Data.
    enum { IDD = id_dlg_select };
    CStatic	pic_info2;
    CStatic	pic_info;
    CTabCtrl	tab;

  public:
    virtual void OnFinalRelease();
  protected:
    virtual void DoDataExchange(CDataExchange* pDX); // DDX/DDV support

    // Implementation.
  protected:
    LRESULT CSelectDlg::OnUWM_CLICK_OK(WPARAM wParam, LPARAM lParam);

    // Generated message map functions.
    virtual BOOL OnInitDialog();
    afx_msg void OnSelchangingtab(NMHDR* pNMHDR, LRESULT* pResult);
    afx_msg void OnSelchangetab(NMHDR* pNMHDR, LRESULT* pResult);
    afx_msg void OnDestroy();
    virtual void OnOK();
    DECLARE_MESSAGE_MAP()
    DECLARE_DISPATCH_MAP()
    DECLARE_INTERFACE_MAP()
};
