#pragma once

#include "VRarHighest.h"

//

class CVGapCont {
  public:
    // Filename for display (key is lower case).
    CString csDisplayFname;
};

// Key in CVGap is RAR archive part lower case firstname.lastname.

class CVGap : public CVHighest {
  public:
    CVGap();
    virtual ~CVGap();

    bool LoadFolder(bool fQuick);
    bool FindGaps();
    bool GetSelect(CStringList* csFnames, CMapStringToPtr* mapReal);

    CMap<CString, LPCSTR, CVGapCont, CVGapCont&> map;

    virtual bool ProgressStart() = 0;
    virtual bool ProgressStop() = 0;
    virtual bool ProgressSet(CString, u32) = 0;
    virtual void PostMessageView(u32, WPARAM, LPARAM) = 0;
    virtual CString GetWorkingFolder() = 0;
  private:
};
