#pragma once

class CBase64 {
  public:
    CBase64();
    virtual ~CBase64();

    bool Decode(s8* pInBuf, s8* pOutBuf, u32 nInBufLen);
    bool Encode(s8* pInBuf, s8* pOutBuf, u32 nInBufLen);
};

bool decode(s8* pInBuf, u8* pOutBuf, s32 nInBufSize, u32* pnOutBufSize);
