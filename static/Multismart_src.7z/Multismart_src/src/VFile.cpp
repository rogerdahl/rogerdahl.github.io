#include "stdafx.h"
#include "VFile.h"
#include <afxmt.h>
#include "md5.h"
#include <shlwapi.h>
#include "Multismart.h"
#include "MultismartView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// The default implementation returns the result of the comparison of *pElement1
// and *pElement2.
//
// CompareElements: The default implementation uses the simple assignment
// operator ( = ) to perform the copy iperation. If the type being copied does
// not have an overloaded operator=, then the default implementation performs a
// bitwise copy.
//
// CopyElements: This function is called when new array, list, and map elements
// are constructed. The default version initializes all bits of the new elements
// to 0 and calls the stored objects' constructors in a loop.

// The default implementation does a bit-wise read or write.
template<>
void AFXAPI SerializeElements<CVDiskCont>(CArchive& ar, CVDiskCont* pElement, INT_PTR nCount) {
  for (s32 i = 0; i < nCount; i++, pElement++) {
    pElement->Serialize(ar);
  }
}
// Generates the C++ code necessary for a dynamic CObject-derived class with
// run-time access to the class name and position within the hierarchy. .
IMPLEMENT_SERIAL(CVDiskCont, CObject, VERSIONABLE_SCHEMA | 2);

CVDisk::CVDisk() {
  // Used for signaling CRC thread to pause.
  hEvent = ::CreateEvent(NULL, true, true, NULL);
  // Protect map.
  InitializeCriticalSection(&critMap);
  // Protect thread.
  InitializeCriticalSection(&critThread);
  fRunning = false;
  fThreadExists = false;
  fPaused = false;
  iTotalSize = 0;
}
CVDisk::~CVDisk() {
  // Stop thread if it is running.
  DeleteCriticalSection(&critMap);
  DeleteCriticalSection(&critThread);
  TRACE("CVDisk::~CVDisk()\n");
}
/*
	thread safe direct map access
*/
void CVDisk::RemoveAll() {
  EnterCriticalSection(&critMap);
  map.RemoveAll();
  iTotalSize = 0;
  LeaveCriticalSection(&critMap);
}

POSITION CVDisk::GetStartPosition() {
  EnterCriticalSection(&critMap);
  POSITION pos = map.GetStartPosition();
  LeaveCriticalSection(&critMap);
  return pos;
}

void CVDisk::GetNextAssoc(POSITION* pos, CString* csFname, CVDiskCont* df) {
  EnterCriticalSection(&critMap);
  map.GetNextAssoc(*pos, *csFname, *df);
  LeaveCriticalSection(&critMap);
}

bool CVDisk::Lookup(CString csFname, CVDiskCont* df) {
  EnterCriticalSection(&critMap);
  csFname.MakeLower();
  bool res = map.Lookup(csFname, *df) != 0;
  LeaveCriticalSection(&critMap);
  return res;
}

bool CVDisk::SetAt(CString csFname, CVDiskCont* df) {
  EnterCriticalSection(&critMap);
  csFname.MakeLower();
  map.SetAt(csFname, *df);
  LeaveCriticalSection(&critMap);
  return true;
}

// GetSelect is called when virtual files need to be translated to real files.
// CVDisk responds by returning a list of real files. (files that exist in the
// CVDisk map).
bool CVDisk::GetSelect(CStringList* csFnames, CMapStringToPtr* mapReal) {
  TRACE("CVDisk::GetSelect()  begin\n");
  POSITION pos;
  CString csFname, csFnameKey;
  bool fAdded = false;
  CVDiskCont df;
  EnterCriticalSection(&critMap);

  for (pos = csFnames->GetHeadPosition(); pos != NULL;) {
    csFname = csFnames->GetNext(pos);
    csFnameKey = csFname;
    csFnameKey.MakeLower();

    if (map.Lookup(csFnameKey, df)) {
      //			iTotalSize -= df.m_size;
      (*mapReal)[csFname] = NULL;
      fAdded = true;
      TRACE("Added: %s\n", csFname);
    }
  }

  LeaveCriticalSection(&critMap);
  TRACE("CVDisk::GetSelect()  end\n");
  return fAdded;
}

// NotifyNew notifies CVDisk that a new file has appeared in the folder. CVDisk
// responds by adding the file to the map. If file already exists in map, it is
// overwritten.
bool CVDisk::NotifyNew(CStringList* csFnames) {
  POSITION pos;
  CVDiskCont df;
  CFile file;
  CFileStatus filestat;
  CString csFname;
  EnterCriticalSection(&critMap);

  for (pos = csFnames->GetHeadPosition(); pos != NULL;) {
    csFname = csFnames->GetNext(pos);
    // Get file info.
    file.GetStatus(GetWorkingFolder() + csFname, filestat);

    if (Lookup(csFname, &df)) {
      iTotalSize -= df.m_size;
    }

    // Fill CVDiskCont.
    df.csDisplayFname = csFname; // display name
    df.iCrcStatus = CRCSTATUS_NOTATTEMPTED; // CRC has not been attempted
    df.m_size = (u32)filestat.m_size; // size of file
    df.m_mtime = filestat.m_mtime; // last modified
    // Map it.
    map.SetAt(csFname, df);
    iTotalSize += df.m_size;
  }

  LeaveCriticalSection(&critMap);
  return true;
}
/*
	CRC and MD5 a file at the same time.
	If the file is a PAR or Pxx file, the MD5 is generated from byte 0x20 and outwards,
	so that it can be compared with the MD5s that are stored in those files.
*/
bool CVDisk::CRCFile(CString csFname, u32* pCrc, CMd5* pMd5) {
  static const u32 crctab[] = {
    0x00000000, 0x77073096, 0xee0e612c, 0x990951ba, 0x076dc419, 0x706af48f, 0xe963a535, 0x9e6495a3,
    0x0edb8832, 0x79dcb8a4, 0xe0d5e91e, 0x97d2d988, 0x09b64c2b, 0x7eb17cbd, 0xe7b82d07, 0x90bf1d91,
    0x1db71064, 0x6ab020f2, 0xf3b97148, 0x84be41de, 0x1adad47d, 0x6ddde4eb, 0xf4d4b551, 0x83d385c7,
    0x136c9856, 0x646ba8c0, 0xfd62f97a, 0x8a65c9ec, 0x14015c4f, 0x63066cd9, 0xfa0f3d63, 0x8d080df5,
    0x3b6e20c8, 0x4c69105e, 0xd56041e4, 0xa2677172, 0x3c03e4d1, 0x4b04d447, 0xd20d85fd, 0xa50ab56b,
    0x35b5a8fa, 0x42b2986c, 0xdbbbc9d6, 0xacbcf940, 0x32d86ce3, 0x45df5c75, 0xdcd60dcf, 0xabd13d59,
    0x26d930ac, 0x51de003a, 0xc8d75180, 0xbfd06116, 0x21b4f4b5, 0x56b3c423, 0xcfba9599, 0xb8bda50f,
    0x2802b89e, 0x5f058808, 0xc60cd9b2, 0xb10be924, 0x2f6f7c87, 0x58684c11, 0xc1611dab, 0xb6662d3d,
    0x76dc4190, 0x01db7106, 0x98d220bc, 0xefd5102a, 0x71b18589, 0x06b6b51f, 0x9fbfe4a5, 0xe8b8d433,
    0x7807c9a2, 0x0f00f934, 0x9609a88e, 0xe10e9818, 0x7f6a0dbb, 0x086d3d2d, 0x91646c97, 0xe6635c01,
    0x6b6b51f4, 0x1c6c6162, 0x856530d8, 0xf262004e, 0x6c0695ed, 0x1b01a57b, 0x8208f4c1, 0xf50fc457,
    0x65b0d9c6, 0x12b7e950, 0x8bbeb8ea, 0xfcb9887c, 0x62dd1ddf, 0x15da2d49, 0x8cd37cf3, 0xfbd44c65,
    0x4db26158, 0x3ab551ce, 0xa3bc0074, 0xd4bb30e2, 0x4adfa541, 0x3dd895d7, 0xa4d1c46d, 0xd3d6f4fb,
    0x4369e96a, 0x346ed9fc, 0xad678846, 0xda60b8d0, 0x44042d73, 0x33031de5, 0xaa0a4c5f, 0xdd0d7cc9,
    0x5005713c, 0x270241aa, 0xbe0b1010, 0xc90c2086, 0x5768b525, 0x206f85b3, 0xb966d409, 0xce61e49f,
    0x5edef90e, 0x29d9c998, 0xb0d09822, 0xc7d7a8b4, 0x59b33d17, 0x2eb40d81, 0xb7bd5c3b, 0xc0ba6cad,
    0xedb88320, 0x9abfb3b6, 0x03b6e20c, 0x74b1d29a, 0xead54739, 0x9dd277af, 0x04db2615, 0x73dc1683,
    0xe3630b12, 0x94643b84, 0x0d6d6a3e, 0x7a6a5aa8, 0xe40ecf0b, 0x9309ff9d, 0x0a00ae27, 0x7d079eb1,
    0xf00f9344, 0x8708a3d2, 0x1e01f268, 0x6906c2fe, 0xf762575d, 0x806567cb, 0x196c3671, 0x6e6b06e7,
    0xfed41b76, 0x89d32be0, 0x10da7a5a, 0x67dd4acc, 0xf9b9df6f, 0x8ebeeff9, 0x17b7be43, 0x60b08ed5,
    0xd6d6a3e8, 0xa1d1937e, 0x38d8c2c4, 0x4fdff252, 0xd1bb67f1, 0xa6bc5767, 0x3fb506dd, 0x48b2364b,
    0xd80d2bda, 0xaf0a1b4c, 0x36034af6, 0x41047a60, 0xdf60efc3, 0xa867df55, 0x316e8eef, 0x4669be79,
    0xcb61b38c, 0xbc66831a, 0x256fd2a0, 0x5268e236, 0xcc0c7795, 0xbb0b4703, 0x220216b9, 0x5505262f,
    0xc5ba3bbe, 0xb2bd0b28, 0x2bb45a92, 0x5cb36a04, 0xc2d7ffa7, 0xb5d0cf31, 0x2cd99e8b, 0x5bdeae1d,
    0x9b64c2b0, 0xec63f226, 0x756aa39c, 0x026d930a, 0x9c0906a9, 0xeb0e363f, 0x72076785, 0x05005713,
    0x95bf4a82, 0xe2b87a14, 0x7bb12bae, 0x0cb61b38, 0x92d28e9b, 0xe5d5be0d, 0x7cdcefb7, 0x0bdbdf21,
    0x86d3d2d4, 0xf1d4e242, 0x68ddb3f8, 0x1fda836e, 0x81be16cd, 0xf6b9265b, 0x6fb077e1, 0x18b74777,
    0x88085ae6, 0xff0f6a70, 0x66063bca, 0x11010b5c, 0x8f659eff, 0xf862ae69, 0x616bffd3, 0x166ccf45,
    0xa00ae278, 0xd70dd2ee, 0x4e048354, 0x3903b3c2, 0xa7672661, 0xd06016f7, 0x4969474d, 0x3e6e77db,
    0xaed16a4a, 0xd9d65adc, 0x40df0b66, 0x37d83bf0, 0xa9bcae53, 0xdebb9ec5, 0x47b2cf7f, 0x30b5ffe9,
    0xbdbdf21c, 0xcabac28a, 0x53b39330, 0x24b4a3a6, 0xbad03605, 0xcdd70693, 0x54de5729, 0x23d967bf,
    0xb3667a2e, 0xc4614ab8, 0x5d681b02, 0x2a6f2b94, 0xb40bbe37, 0xc30c8ea1, 0x5a05df1b, 0x2d02ef8d
  };

#define TARGETBUFSIZE (10 * 1024 * 1024)

  u32 crc = 0xffffffff; // init CRC
  CFile cf;
  u32 buffsize;
  CMd5 md5;
  CMd5::md5_ctx ctx;
  md5.md5_init_ctx(&ctx);
  HANDLE hFile = CreateFile(csFname, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_NO_BUFFERING, NULL);

  if (hFile == INVALID_HANDLE_VALUE) {
    return false;
  }

  // When FILE_FLAG_NO_BUFFERING is used, ReadFile can only read whole sectors
  // to properly aligned memory.
  DWORD dwMySectorsPerCluster, dwMyBytesPerSector, dwMyNumberOfFreeClusters, dwMyTotalNumberOfClusters;

  if (!GetDiskFreeSpace(NULL, &dwMySectorsPerCluster, &dwMyBytesPerSector, &dwMyNumberOfFreeClusters, &dwMyTotalNumberOfClusters)) {
    LastErrorMessageBox("CVDisk::CRCFile, GetDiskFreeSpace FAILED.");
    return false;
  }

  // Calculate size of buffer from target size (buffersize must be multiple of
  // bytes per sector). I don't think anyone will ever have a sector size that
  // will cause buffsize to differ from TARGETBUFSIZE as long as TARGETBUFSIZE
  // is selected as a multiple of a number that is a power of two.
  buffsize = (TARGETBUFSIZE / dwMyBytesPerSector) * dwMyBytesPerSector;
  // Alloc properly aligned memory.
  LPVOID buf;

  if (!(buf = VirtualAlloc(NULL, buffsize, MEM_COMMIT, PAGE_READWRITE))) {
    LastErrorMessageBox("CVDisk::CRCFile, VirtualAlloc FAILED.");
    CloseHandle(hFile);
    return false;
  }

  // CRC and MD5 loop.
  DWORD dwMyNumberOfBytesRead;
  bool fFirstBlock = true;

  do {
    // Read.
    BOOL fReadSuccess;
    fReadSuccess = ReadFile(hFile, buf, buffsize, &dwMyNumberOfBytesRead, NULL);

    if (!fReadSuccess || dwMyNumberOfBytesRead == 0) {
      break;
    }

    // CRC.
    for (u32 i = 0; i < dwMyNumberOfBytesRead; i++) {
      crc = ((crc >> 8) & 0xFFFFFF) ^ crctab[(u8)((crc & 0xff) ^((u8*)buf)[i])];
    }

    // MD5.
    if (fFirstBlock &&
        dwMyNumberOfBytesRead >= 0x20 &&
        !strncmp((s8*)buf, "PAR\0\0\0\0\0\0\0\0\1\0\0\0\0", 16)) { // TRUE if PAR0000 v1.00
      // Skip first 0x20 bytes in MD5 of this is PAR or Pxx file.
      md5.md5_process_bytes((u8*)buf + 0x20, dwMyNumberOfBytesRead - 0x20, &ctx);
    }
    else {
      // Normal file.
      md5.md5_process_bytes(buf, dwMyNumberOfBytesRead, &ctx);
    }

    fFirstBlock = false;
  }
  while (dwMyNumberOfBytesRead == buffsize);

  // Copy MD5 from ctx to my format.
  u8 iMd5[16];
  md5.md5_finish_ctx(&ctx, &iMd5);
  md5.md5_read_ctx(&ctx, &iMd5);
  pMd5->LoadMem(iMd5);
  *pCrc = ~crc;

  // Finish.
  CloseHandle(hFile);
  VirtualFree(buf, NULL, MEM_RELEASE);
  TRACE("CVDisk::CRCFile()  CRC'ed %s\n", csFname);
  return true;
}
bool CVDisk::LoadFolder(bool fQuick) {
  // Attempt to load .sfvdb if map is completely empty.
  if (!map.GetCount()) {
    ProgressSet("Reading SFV database (.sfvdb)...", 15);
    Load();
  }

  // Sync.
  ProgressSet("Detecting new and removed files...\n", 30);
  SyncFolder();
  return true;
}
bool CVDisk::SyncFolder() {
  TRACE("CVDisk::SyncFolder()  started\n");
  CVDiskCont df;
  // Lock map.
  EnterCriticalSection(&critMap);
  // Map new files that exist on disk.
  CString csFnameKey, csFnameDisplay;
  CMapStringToPtr csFnameExistingKey; // hold existing filenames
  TRACE("CVDisk::SyncFolder()  Finding new files...\n");
  CTime ctTmp;
  CFileFind finder;
  BOOL bWorking = finder.FindFile(GetWorkingFolder() + "*.*");

  while (bWorking) {
    bWorking = finder.FindNextFile();

    if (!finder.IsDirectory()) {
      csFnameDisplay = finder.GetFileName();
      csFnameKey = csFnameDisplay;
      csFnameKey.MakeLower();
      csFnameExistingKey[csFnameKey] = NULL; // remember existing file (ptr is junk)

      if (!(map.Lookup(csFnameKey, df)  // if NOT... file is in map...
            && (finder.GetLastWriteTime(ctTmp), ctTmp == df.m_mtime) // ...and has same modified time...
            && finder.GetLength() == df.m_size)) {	// ...and has same size...
        // File is not the same as the one in map, or it doesn't exist in map,
        // so add/overwrite it.
        if (map.Lookup(csFnameKey, df)) {
          iTotalSize -= df.m_size;
        }

        // Fill CVDiskCont.
        df.csDisplayFname = csFnameDisplay; // display name
        df.iCrcStatus = CRCSTATUS_NOTATTEMPTED; // CRC has not been attempted
        df.m_size = (u32)finder.GetLength(); // size of file
        finder.GetLastWriteTime(df.m_mtime); // last modified
        // Map it.
        map.SetAt(csFnameKey, df);
        iTotalSize += df.m_size;
      }
    }
  }

  TRACE("CVDisk::SyncFolder()  Detecting removed files...\n");
  // Remove files that no longer exist on disk from map.
  void* junk;
  POSITION pos = map.GetStartPosition();

  while (pos != NULL) {
    map.GetNextAssoc(pos, csFnameKey, df);

    if (!csFnameExistingKey.Lookup(csFnameKey, junk)) {
      map.RemoveKey(csFnameKey);
      iTotalSize -= df.m_size;
    }
  }

  // Release map.
  LeaveCriticalSection(&critMap);
  TRACE("CVDisk::SyncFolder()  Loaded %d items\n", map.GetCount());
  return true;
}
/*
	read previous DB of disk files if it exists
*/
bool CVDisk::Load() {
  TRACE("CVDisk::Load()  Start\n");
  CFile cF;

  if (!cF.Open(GetWorkingFolder() + ".sfvdb", CFile::modeRead)) {
    return false;
  }

  CArchive cA(&cF, CArchive::load);
  EnterCriticalSection(&critMap);

  RemoveAll();
  map.Serialize(cA);
  LeaveCriticalSection(&critMap);
  cA.Close();
  cF.Close();
  // Calculate total size.
  EnterCriticalSection(&critMap);
  CString csFname;
  CVDiskCont df;
  POSITION pos = map.GetStartPosition();

  while (pos != NULL) {
    map.GetNextAssoc(pos, csFname, df);
    iTotalSize += df.m_size;
  }

  LeaveCriticalSection(&critMap);

  TRACE("CVDisk::Load()  End - True\n");
  return true;
}

bool CVDisk::Save() {
  TRACE("CVDisk::Save()  Start\n");
  CString csFname;
  CVDiskCont df;
  EnterCriticalSection(&critMap);
  // Store.
  TRACE("CVDisk::Save()  Storing\n");
  CFile cF;

  if (!cF.Open(GetWorkingFolder() + ".sfvdb", CFile::modeWrite | CFile::modeCreate)) {
    return false;
  }

  ProgressStart();
  ProgressSet("Updating SFV database (.sfvdb)...", 100);
  CArchive cA(&cF, CArchive::store);
  map.Serialize(cA);
  cA.Close();
  cF.Close();
  LeaveCriticalSection(&critMap);
  ProgressStop();
  TRACE("CVDisk::Save()  End - True\n");
  return true;
}
/*
	async functions
	The function argument for a worker thread can not be part of a class, so I give it
	a global function that calls directly into the class.
*/
u32 CRCFilesAsyncThread(LPVOID param) {
  bool res;
  CVDisk* me = (CVDisk*)param;
  res = me->CRCFiles();
  TRACE("CRCFilesAsyncThread() Exit\n");
  return res;
}
/*
	This function it less efficient than it could be because it is written to not
	be in the critical section for long periods of time, and to not be in the critical
	section while it is being paused. Also, it should handle changes being made to the
	map by other threads while it is going.
*/
bool CVDisk::CRCFiles() {
  CVDiskCont df;
  CString csFname;
  u32 crc;
  u8 iCrcStatus;
  CMd5 md5;
  TRACE("CVDisk::CRCFiles()  Started\n");
  // Find root name of drive (also handles UNC paths).
  CString csRoot(GetWorkingFolder());
  PathStripToRoot(csRoot.GetBuffer(MAX_PATH));
  csRoot.ReleaseBuffer();
  // Mutex doesn't like \ in name, and all I care about is that the name is
  // unique for each drive.
  csRoot.Replace("\\", "&");
  // Get lock on name. if same drive is being processed elsewhere, wait here
  // forever.
  TRACE("CVDisk::CRCFiles()  obtaining drive lock\n");
  CMutex pMutexBlockSame(FALSE, CString("multismart&") + csRoot, NULL);
  pMutexBlockSame.Lock(INFINITE);

  TRACE("CVDisk::CRCFiles()  drive lock obtained\n");
  // Clear all "couldn't open file for reading" statuses, so that CRC is
  // attempted again then next time db is opened.
  TRACE("CVDisk::CRCFiles()  Resetting CRCSTATUS_OPENERROR to Status CRCSTATUS_NOTATTEMPTED\n");
  EnterCriticalSection(&critMap);
  POSITION pos = map.GetStartPosition();

  while (pos != NULL) {
    map.GetNextAssoc(pos, csFname, df);

    if (df.iCrcStatus == CRCSTATUS_OPENERROR) {
      df.iCrcStatus = CRCSTATUS_NOTATTEMPTED;
      map.SetAt(csFname, df);
    }
  }

  LeaveCriticalSection(&critMap);
  TRACE("CVDisk::CRCFiles()  CRCing\n");
  int arrpos = 0;

  while (fRunning) {
    // Pause here if user checks pause. fPaused is a global volatile.
    if (fPaused)
      switch (::WaitForSingleObject(hEvent, 1000)) {
        case WAIT_OBJECT_0:
          TRACE("CVDisk::CRCFiles()  Wait Ended\n");
          break;
        case WAIT_TIMEOUT:
          TRACE("CVDisk::CRCFiles()  Wait Timeout\n");
          continue;
      }

    // Exit at top of loop if running is false, and here if no more work to be
    // done.
    if (arrpos > csarrFnames->GetUpperBound()) {
      break;
    }

    // Find next file to CRC.
    csFname = csarrFnames->GetAt(arrpos++);
    // Have filename, are not in critical section and it's not a problem if
    // position (pos) of file in map is altered. Now CRC the file.
    bool fAttemptedCRC = false;
    CFileStatus fileStat;

    if (CFile::GetStatus(GetWorkingFolder() + csFname, fileStat) && // CRC file IF file exists on disk AND
        Lookup(csFname, &df) && // ...file exists in map AND
        (
          df.iCrcStatus != CRCSTATUS_CALCULATED || // crc has not been calculated before OR
          fileStat.m_mtime != df.m_mtime || // ...file on disk has been modified
          (u32)fileStat.m_size != df.m_size // ...file on disk has changed size
        )) {
      if (CRCFile(GetWorkingFolder() + csFname, &crc, &md5)) {
        iCrcStatus = CRCSTATUS_CALCULATED;
      }
      else {
        iCrcStatus = CRCSTATUS_OPENERROR;
      }

      fAttemptedCRC = true;
    }

    // Update map if I attempted crc and filename still exists.
    if (fAttemptedCRC) {
      EnterCriticalSection(&critMap);
      CString csFnameKey = csFname;
      csFnameKey.MakeLower();

      if (map.Lookup(csFnameKey, df)) {
        df.crc = crc;
        df.md5 = md5;
        df.iCrcStatus = iCrcStatus;
        // Map it.
        map.SetAt(csFnameKey, df);
        // Notify owner window that I CRC'ed this file.

        // TODO: Bug: May not be worth fixing: Causes memory leak if app is
        // closed while CRC is running.
        CString* csTransfer = new CString;
        *csTransfer = csFname;
        PostMessageView(UWM_NEWFILESTATUS, (WPARAM)csTransfer, df.iCrcStatus);
      }

      LeaveCriticalSection(&critMap);
    }
  }

  // Notify window of change.
  PostMessageView(UWM_DONECRC, 0, 0);
  TRACE("CVDisk::CRCFiles  Ended\n");
  fRunning = false;
  delete csarrFnames;
  return true;
}

bool CVDisk::CRCFilesAsyncStart(CSortableStringArray* csarrFnamesIn) {
  // Stop thread if it is already running.
  CRCFilesAsyncStop();
  // Start thread.
  EnterCriticalSection(&critThread);

  if (fRunning) {
    TRACE("CVDisk::CRCFilesAsyncStart()  Called but already running\n");
    return false;
  }

  TRACE("CVDisk::CRCFilesAsyncStart()  Called\n");
  fRunning = true;
  fThreadExists = true;
  csarrFnames = csarrFnamesIn;
  threadWorker = AfxBeginThread(CRCFilesAsyncThread, this, THREAD_PRIORITY_BELOW_NORMAL, 0, CREATE_SUSPENDED);
  fThreadExists = true;
  threadWorker->m_bAutoDelete = false;
  threadWorker->ResumeThread();
  LeaveCriticalSection(&critThread);
  return true;
}

bool CVDisk::CRCFilesAsyncPause(bool pauseIn) {
  EnterCriticalSection(&critThread);

  if (!fRunning) {
    return false;
  }

  if (pauseIn) {
    TRACE("CVDisk::CRCFilesAsyncPause  fPaused flag ON, hEvent OFF");
    fPaused = true;
    ::ResetEvent(hEvent);
  }
  else {
    TRACE("CVDisk::CRCFilesAsyncPause  fPaused flag OFF, hEvent ON");
    fPaused = false;
    ::SetEvent(hEvent);
  }

  LeaveCriticalSection(&critThread);
  return true;
}

bool CVDisk::CRCFilesAsyncStop() {
  /*
  	About critThread: I want to be able to call Stop() safely no matter what the status of the
  	thread is. Without the mutex, this function wouldn't be safe becase if multiple threads
  	called it, two or more threads would be able to pass the "if (fThreadExists)" before fThreadExists
  	is set to false.
  */
  EnterCriticalSection(&critThread);

  if (fThreadExists) {
    fThreadExists = false;
    fRunning = false;
    WaitForSingleObject(threadWorker->m_hThread, INFINITE);
    delete threadWorker;
  }

  LeaveCriticalSection(&critThread);
  TRACE("CVDisk::CRCFilesAsyncStop()  Exit\n");
  return true;
}

bool CVDisk::CRCFilesAsyncIsRunning() {
  return fRunning;
}

bool CVDisk::CRCFilesAsyncIsPaused() {
  return fPaused;
}
