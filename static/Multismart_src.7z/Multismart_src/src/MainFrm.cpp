#include "stdafx.h"
#include "Multismart.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMainFrame.

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
  ON_WM_CREATE()
  ON_COMMAND(ID_VIEW_DIALOG_BAR, OnViewDialogBar)
  ON_UPDATE_COMMAND_UI(ID_VIEW_DIALOG_BAR, OnUpdateViewDialogBar)
  // These are here to clear the status bar when no view handlers exist.
  ON_UPDATE_COMMAND_UI(ID_INDICATOR_SELNO, OnUpdateSelected)
  ON_UPDATE_COMMAND_UI(ID_INDICATOR_TOT, OnUpdateTotal)
  ON_UPDATE_COMMAND_UI(ID_INDICATOR_FREE, OnUpdateFree)
  ON_UPDATE_COMMAND_UI(ID_VIEW_CHK_SHOWEXISTING, OnUpdateViewChkShowexisting)
  ON_UPDATE_COMMAND_UI(ID_VIEW_CHK_SHOWMISSING, OnUpdateViewChkShowmissing)
END_MESSAGE_MAP()

static UINT indicators[] = {
  ID_SEPARATOR, // status line indicator
  ID_INDICATOR_SELNO,
  ID_INDICATOR_TOT,
  ID_INDICATOR_FREE,
  ID_INDICATOR_CAPS,
  ID_INDICATOR_NUM,
  ID_INDICATOR_SCRL,
};

CMainFrame::CMainFrame() {
}

CMainFrame::~CMainFrame() {
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) {
  if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1) {
    return -1;
  }

  if (!m_wndToolBar.CreateEx(this) ||
      !m_wndToolBar.LoadToolBar(IDR_MAINFRAME)) {
    TRACE0("Failed to create toolbar\n");
    return -1;
  }

  if (!m_wndDlgBar.Create(this, IDR_MAINFRAME,
                          CBRS_ALIGN_TOP, AFX_IDW_DIALOGBAR)) {
    TRACE0("Failed to create dialogbar\n");
    return -1;
  }

  if (!m_wndReBar.Create(this) ||
      !m_wndReBar.AddBar(&m_wndToolBar) ||
      !m_wndReBar.AddBar(&m_wndDlgBar)) {
    TRACE0("Failed to create rebar\n");
    return -1;
  }

  if (!m_wndStatusBar.Create(this) ||
      !m_wndStatusBar.SetIndicators(indicators,
                                    sizeof(indicators) / sizeof(UINT))) {
    TRACE0("Failed to create status bar\n");
    return -1;
  }

  // TODO: Remove this if you don't want tool tips.
  m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
                           CBRS_TOOLTIPS | CBRS_FLYBY);

  //m_wndStatusBar.P
  m_wndStatusBar.SetPaneInfo(0, ID_SEPARATOR, SBPS_NOBORDERS | SBPS_STRETCH, 0); // status messages
  m_wndStatusBar.SetPaneInfo(1, ID_INDICATOR_SELNO, SBPS_NORMAL, 100); // selected
  m_wndStatusBar.SetPaneInfo(2, ID_INDICATOR_TOT, SBPS_NORMAL, 100); // size selected
  m_wndStatusBar.SetPaneInfo(3, ID_INDICATOR_FREE, SBPS_NORMAL, 100); // size selected

  return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs) {
  if (!CMDIFrameWnd::PreCreateWindow(cs)) {
    return FALSE;
  }

  // TODO: Modify the Window class or styles here by modifying the CREATESTRUCT
  // cs.

  return TRUE;
}


// CMainFrame diagnostics.

#ifdef _DEBUG
void CMainFrame::AssertValid() const {
  CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const {
  CMDIFrameWnd::Dump(dc);
}

#endif


// CMainFrame message handlers.

/*
bool ReadWindowPlacement( const CString& strWin, LPWINDOWPLACEMENT pWP ) {
	CString strKey;
	strKey= _T("WinPos");
	CString strBuf= AfxGetApp()->GetProfileString( strKey, strWin );
	if ( strBuf.IsEmpty() || pWP == NULL )
		return( false );

	int nCnt;
	nCnt= sscanf( (LPCTSTR)strBuf, _T("%u,%u,%d,%d,%d,%d,%d,%d,%d,%d"),
		&pWP->flags, &pWP->showCmd,
		&pWP->ptMinPosition.x, &pWP->ptMinPosition.y,
		&pWP->ptMaxPosition.x, &pWP->ptMaxPosition.y,
		&pWP->rcNormalPosition.left, &pWP->rcNormalPosition.top,
		&pWP->rcNormalPosition.right, &pWP->rcNormalPosition.bottom );
	if ( nCnt != 10 )
		return( false );

	pWP->length= sizeof( WINDOWPLACEMENT );
	return( true );
}

void WriteWindowPlacement( const CString& strWin, LPWINDOWPLACEMENT pWP ) {
	CString strKey;
	CString strBuf;

	strBuf.Format( _T("%u,%u,%d,%d,%d,%d,%d,%d,%d,%d"),
		pWP->flags, pWP->showCmd,
		pWP->ptMinPosition.x, pWP->ptMinPosition.y,
		pWP->ptMaxPosition.x, pWP->ptMaxPosition.y,
		pWP->rcNormalPosition.left, pWP->rcNormalPosition.top,
		pWP->rcNormalPosition.right, pWP->rcNormalPosition.bottom );
	strKey= _T("WinPos");
	AfxGetApp()->
		WriteProfileString( strKey, (LPCTSTR)strWin, (LPCTSTR)strBuf );
}

In your MDI frame class add these handlers/overrides.

void CMyFrame::SaveWindowLocation( void ) {
    WINDOWPLACEMENT wp;
    wp.length= sizeof( wp );
    if ( GetWindowPlacement( &wp ) ) {
        if ( IsZoomed() )
            wp.flags= WPF_RESTORETOMAXIMIZED;
        ::WriteWindowPlacement( _T("MyChild"), &wp );
    }
}

BOOL CMyFrame::PreCreateWindow( CREATESTRUCT& cs ) {
    WINDOWPLACEMENT wp;

    if ( ::ReadWindowPlacement( _T("MyChild"), &wp ) ) {
        cs.x= wp.rcNormalPosition.left;
        cs.y= wp.rcNormalPosition.top;
        cs.cx= wp.rcNormalPosition.right - cs.x;
        cs.cy= wp.rcNormalPosition.bottom - cs.y;
    }
    else {
		cs.x= 0;
		cs.y= 0;
		cs.cx= 628;
		cs.cy= 381;
	} return( CMDIChildWnd::PreCreateWindow( cs ) );
}

void CMyFrame::OnClose()  {
	// Save the window's current size and position..
	SaveWindowLocation();
	CMDIChildWnd::OnClose();
}

In your view class add this to your OnInitialUpdate (or create it):
	WINDOWPLACEMENT wp;
	if ( ::ReadWindowPlacement( _T("MyChild"), &wp ) )
		GetParentFrame()->SetWindowPlacement( &wp );
	else
		GetParentFrame()->ShowWindow( SW_SHOWNORMAL );
}

This will save your MDI view to the app's registry key (or .INI file if
registry isn't being used) in ASCII format as for the toolbar(s) you can
use the LoadBarState/SaveBarState in the CMainFrame class's
OnCreate/OnClose functions (respectively).  These functions take a CString
argument specifing what key to use in the registry (or .INI file).  This
information will also be stored in ASCII format (but probably wouldn't be
much use to an end-user).

>   Finally, I can't seem to delete the old views before I create the new
> ones.

If your create the functions and follow the outline above the framework
will do the rest (you need not delete the 'old' ones).

HTH
*/

void CMainFrame::OnViewDialogBar()  {
  // Toggle the dialog bar.
  if (m_wndDlgBar.IsWindowVisible()) {
    ShowControlBar(&m_wndDlgBar, FALSE, FALSE);
  }
  else {
    ShowControlBar(&m_wndDlgBar, TRUE, FALSE);
  }
}

void CMainFrame::OnUpdateViewDialogBar(CCmdUI* pCmdUI)  {
  // Update the check mark in the menu.
  pCmdUI->SetCheck(m_wndDlgBar.IsWindowVisible());
}

void CMainFrame::OnUpdateSelected(CCmdUI* pCmdUI) {
  pCmdUI->SetText("");
}

void CMainFrame::OnUpdateTotal(CCmdUI* pCmdUI) {
  pCmdUI->SetText("");
}

void CMainFrame::OnUpdateFree(CCmdUI* pCmdUI) {
  pCmdUI->SetText("");
}

void CMainFrame::OnUpdateViewChkShowexisting(CCmdUI* pCmdUI)  {
  pCmdUI->Enable(FALSE);
  pCmdUI->SetCheck(FALSE);
}

void CMainFrame::OnUpdateViewChkShowmissing(CCmdUI* pCmdUI)  {
  pCmdUI->Enable(FALSE);
  pCmdUI->SetCheck(FALSE);
}

