#include "stdafx.h"
#include "Multismart.h"
#include "SelectCleanupDlg.h"
#include "SelectDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CSelectCleanupDlg::CSelectCleanupDlg(CWnd* pParent /*=NULL*/)
  : CDialog(CSelectCleanupDlg::IDD, pParent) {
  EnableAutomation();

  select_edit_daylast = 0;
  select_edit_parts = 1;
}


void CSelectCleanupDlg::OnFinalRelease() {
  CDialog::OnFinalRelease();
}

void CSelectCleanupDlg::DoDataExchange(CDataExchange* pDX) {
  CDialog::DoDataExchange(pDX);
  DDX_Text(pDX, id_select_edit_daylast, select_edit_daylast);
  DDV_MinMaxUInt(pDX, select_edit_daylast, 0, 1000);
  DDX_Text(pDX, id_select_edit_parts, select_edit_parts);
  DDV_MinMaxUInt(pDX, select_edit_parts, 0, 1000);
}


BEGIN_MESSAGE_MAP(CSelectCleanupDlg, CDialog)
  ON_WM_DESTROY()
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CSelectCleanupDlg, CDialog)
END_DISPATCH_MAP()

static const IID IID_IDlgSelectCleanup = { 0x907c2cd, 0xa907, 0x46ae, { 0x9d, 0x23, 0xce, 0x8b, 0xd, 0xa6, 0x2a, 0x8b } };

BEGIN_INTERFACE_MAP(CSelectCleanupDlg, CDialog)
INTERFACE_PART(CSelectCleanupDlg, IID_IDlgSelectCleanup, Dispatch)
END_INTERFACE_MAP()

// CSelectCleanupDlg message handlers.

BOOL CSelectCleanupDlg::OnInitDialog()  {
  CDialog::OnInitDialog();

  // Fetch setup info from registry, and apply. use defaults if no registry
  // info.

  HKEY	myhnd;
  DWORD	num, dsize;

  RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\dahlsys\\Multismart", 0, KEY_READ, &myhnd);

  dsize = sizeof(num);

  if (RegQueryValueEx(myhnd, "select_edit_daylast", NULL, NULL, (BYTE*)&num, &dsize)
      == ERROR_SUCCESS) {
    select_edit_daylast = num;
  }
  else {
    select_edit_daylast = 3;
  }

  dsize = sizeof(num);

  if (RegQueryValueEx(myhnd, "select_edit_parts", NULL, NULL, (BYTE*)&num, &dsize)
      == ERROR_SUCCESS) {
    select_edit_parts = num;
  }
  else {
    select_edit_parts = 5;
  }

  RegCloseKey(myhnd);

  UpdateData(false);

  // return TRUE unless you set the focus to a control
  return TRUE;
}


bool CSelectCleanupDlg::MyVerify() {
  if (!UpdateData(true)) {
    return false;
  }

  HKEY	myhnd;
  DWORD	num, dsize = sizeof(num);
  CString csNum;

  RegCreateKeyEx(HKEY_CURRENT_USER, "Software\\dahlsys\\Multismart", 0, " ",
                 REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS | KEY_WRITE, NULL, &myhnd, NULL);

  num = select_edit_daylast;
  RegSetValueEx(myhnd, "select_edit_daylast", 0, REG_DWORD, (BYTE*)&num, dsize);

  num = select_edit_parts;
  RegSetValueEx(myhnd, "select_edit_parts", 0, REG_DWORD, (BYTE*)&num, dsize);

  RegCloseKey(myhnd);

  return true;
}

void CSelectCleanupDlg::OnDestroy()  {
  CDialog::OnDestroy();
}

void CSelectCleanupDlg::OnOK()  {
  GetParent()->GetParent()->SendMessage(UWM_CLICK_OK);
}

void CSelectCleanupDlg::OnCancel()  {
  GetParent()->GetParent()->SendMessage(WM_CLOSE);
}
