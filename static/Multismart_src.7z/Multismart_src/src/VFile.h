#pragma once

#include "md5.h"
#include "SortableStringArray.h"

// Container used in CVDisk represents one file in folder.

// iCrcStatus values:
// - CRCSTATUS_NOTATTEMPTED - no CRC - CRC has not been attempted
// - CRCSTATUS_OPENERROR - no CRC - couldn't open file for reading
// - CRCSTATUS_CALCULATED - CRC has been calculated
enum enumCrcStatus {CRCSTATUS_NOTATTEMPTED, CRCSTATUS_OPENERROR, CRCSTATUS_CALCULATED};

class CVDiskCont : public CObject {
  public:
    CString csDisplayFname; // filename for display (key is lower case)
    CTime m_mtime; // file creation date
    u32 m_size; // file size
    u32 crc; // file crc
    CMd5 md5; // file MD5
    u8 iCrcStatus; // see below

    // Overide the Serialize member in CObject.
    virtual void Serialize(CArchive& ar) {
      // Does nothing by default (as I understand it).
      CObject::Serialize(ar);

      if (ar.IsStoring()) {
        //TRACE("CVDiskCont::Serialize -- storing\n");
        ar << csDisplayFname << m_mtime << m_size << crc << iCrcStatus;
        md5.Serialize(ar);
      }
      else {
        //TRACE("CVDiskCont::Serialize -- reading\n");
        ar >> csDisplayFname >> m_mtime >> m_size >> crc >> iCrcStatus;
        md5.Serialize(ar);
      }
    };
    // CObject makes compiler not create defaults for copy and assignment, and
    // map class needs these to be able to use the class.
    CVDiskCont() {
      // TRACE("Constructor\n");.
    };
    // When cmap destroys elements that are classes, the destructor is called.
    ~CVDiskCont() {
      // TRACE("Destructor\n");.
    };
    // Copy constructor.
    CVDiskCont(const CVDiskCont& s) {
      // TRACE("CVDiskCont -- copy ctor\n");.
      csDisplayFname = s.csDisplayFname;
      m_mtime = s.m_mtime;
      m_size = s.m_size;
      crc = s.crc;
      md5 = s.md5;
      iCrcStatus = s.iCrcStatus;
    }
    // Assignment operator.
    CVDiskCont& operator=(const CVDiskCont& s) {
      // TRACE("CVDiskCont -- assignment operator\n");.
      csDisplayFname = s.csDisplayFname;
      m_mtime = s.m_mtime;
      m_size = s.m_size;
      crc = s.crc;
      md5 = s.md5;
      iCrcStatus = s.iCrcStatus;

      return *this;
    }

    DECLARE_SERIAL(CVDiskCont)
};

// Map collection represents all physical files in DL folder.

// Note: in order for the specialization to be accepted by the compiler the
// prototype for SerializeElements (or any other specialization)
// must be visible when the template is expanded.  It is best to place
// these declarations in the header file to avoid any unexpected results.

template<>
void AFXAPI SerializeElements<CVDiskCont>(CArchive& ar, CVDiskCont* pElement, INT_PTR nCount);

// Key in CVDisk is lower case firstname.lastname.
class CVDisk {
  public:
    CVDisk();
    virtual ~CVDisk();
    // Direct map access. these are thread safe and can be used while async CRC
    // is running.
    void RemoveAll();
    POSITION GetStartPosition();
    void GetNextAssoc(POSITION* pos, CString* csFname, CVDiskCont* df);
    bool SetAt(CString csFname, CVDiskCont* df);
    // Find CRC of file in map.
    bool Lookup(CString csFname, CVDiskCont* df);
    bool GetSelect(CStringList* csFnames, CMapStringToPtr* mapReal);
    // Gen.
    bool NotifyNew(CStringList* csFnames);
    bool LoadFolder(bool fQuick);
    // Sync map with actual folder.
    bool SyncFolder();
    // Find CRC and MD5 for one file.
    bool CRCFile(CString csFname, u32* pCrc, CMd5* pMd5);
    bool Load();
    bool Save();

    // Async functions.

    // Async update CRC for all files in current folder that are in SFV files.
    bool CRCFilesAsyncStart(CSortableStringArray* csarrFnames);
    bool CRCFilesAsyncPause(bool pauseIn);
    bool CRCFilesAsyncStop();
    bool CRCFilesAsyncIsRunning();
    bool CRCFilesAsyncIsPaused();

    // Internal helpers.

    // This should be private but must be public to be reached by thread
    // function.
    bool CRCFiles();
    virtual bool ProgressStart() = 0;
    virtual bool ProgressStop() = 0;
    virtual bool ProgressSet(CString, u32) = 0;
    virtual void PostMessageView(u32, WPARAM, LPARAM) = 0;
    virtual CString GetWorkingFolder() = 0;
    // Total size of all files contained.
    u64 iTotalSize;
  private:
    CMap<CString, LPCSTR, CVDiskCont, CVDiskCont&> map;
    // For worker thread.

    // Signal / control that thread is running.
    volatile bool fRunning;
    // Signal / control that thread exists.
    volatile bool fThreadExists;
    // Signal that thread is paused (optimization hack together with eventPause).
    volatile bool fPaused;
    HANDLE hEvent;
    // Protect the map.
    CRITICAL_SECTION critMap;
    // Protect the functions that control the thread.
    CRITICAL_SECTION critThread;
    //	CEvent eventPause;
    //	CEvent eventBlockSame;
    CMutex* pMutexBlockSame;
    CWinThread* threadWorker;

    // Initalized by CRCFilesAsyncStart so it can be reached by thread. Used for
    // CRC'ing in alphabetical order.
    CSortableStringArray* csarrFnames;
};

// First, I built CVDisk as an expansion of CMap, but that proved later not to
// be smart because I needed to make CVDisk thread safe, and I only wanted to
// expose certain functions that would all be thread safe. So it was better to
// have CMap as a member variable, expose the functions that are needed, and
// wrap them in mutex'es.
//
// About CVDiskCont:
//
// I thought the container would need to implement serialize so that cmap would
// be able to serialize instanses of it, but apparently, CMap writes the whole
// object directy to disk. The serialize func below did not even get called. For
// the same reason, I thought container would need to be derived from CObject
// (to get serialize functionality). I think that if container was used in a
// class less smart than CMap, I would have to do all the stuff that is in
// coments here. Snipped from MFC doc:
//
// >>>
//
// The CArray, CList, and CMap classes call SerializeElements to store
// collection elements to or read them from an archive.
//
// The default implementation of the SerializeElements helper function does a
// bitwise write from the objects to the archive, or a bitwise read from the
// archive to the objects, depending on whether the objects are being stored in
// or retrieved from the archive.
//
// Override SerializeElements if this action is not appropriate.
//
// <<<
