#pragma once

class CSelectRequestDlg : public CDialog {
  public:
    bool MyVerify();
    CSelectRequestDlg(CWnd* pParent = NULL); // standard constructor

    // Dialog Data.
    enum { IDD = id_dlg_select_request };
    UINT	request_edit_daylast;
    UINT	request_edit_parts;

    // Overrides.
  public:
    virtual void OnFinalRelease();
  protected:
    virtual void DoDataExchange(CDataExchange* pDX); // DDX/DDV support

    // Implementation.
  protected:

    // Generated message map functions.
    virtual BOOL OnInitDialog();
    virtual void OnOK();
    virtual void OnCancel();

    DECLARE_MESSAGE_MAP()
    DECLARE_DISPATCH_MAP()
    DECLARE_INTERFACE_MAP()
};
