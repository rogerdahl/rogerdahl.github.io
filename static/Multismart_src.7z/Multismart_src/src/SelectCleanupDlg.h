#pragma once

class CSelectCleanupDlg : public CDialog {
  public:
    bool MyVerify();
    CSelectCleanupDlg(CWnd* pParent = NULL); // standard constructor

    // Dialog Data.
    enum { IDD = id_dlg_select_cleanup };
    UINT	select_edit_daylast;
    UINT	select_edit_parts;

  public:
    virtual void OnFinalRelease();
  protected:
    virtual void DoDataExchange(CDataExchange* pDX); // DDX/DDV support

    // Implementation.
  protected:

    // Generated message map functions.
    virtual BOOL OnInitDialog();
    afx_msg void OnDestroy();
    virtual void OnOK();
    virtual void OnCancel();
    DECLARE_MESSAGE_MAP()
    DECLARE_DISPATCH_MAP()
    DECLARE_INTERFACE_MAP()
};
