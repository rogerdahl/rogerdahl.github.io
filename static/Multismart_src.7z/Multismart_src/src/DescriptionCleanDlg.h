#pragma once

class CDescrCleanConfirmDlg : public CDialog {
  public:
    // Standard constructor.
    CDescrCleanConfirmDlg(CWnd* pParent = NULL);

    // Dialog Data.
    enum { IDD = id_dlg_description_cleaning };
    CStatic	pic_question;
    BOOL	chk_nomore;

    // Overrides.
  public:
    virtual void OnFinalRelease();
    virtual INT_PTR DoModal();
  protected:
    // DDX/DDV support.
    virtual void DoDataExchange(CDataExchange* pDX);

    // Implementation.
  protected:
    virtual BOOL OnInitDialog();
    virtual void OnOK();
    virtual void OnCancel();

    DECLARE_MESSAGE_MAP()
    DECLARE_DISPATCH_MAP()
    DECLARE_INTERFACE_MAP()
};
