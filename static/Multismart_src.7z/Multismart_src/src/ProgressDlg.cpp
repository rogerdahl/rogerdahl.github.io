#include "stdafx.h"
#include "Multismart.h"
#include "ProgressDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CProgressDlg::CProgressDlg(CWnd* pParent /*=NULL*/)
  : CDialog(CProgressDlg::IDD, pParent) {


  // Create window. Parent has to be Desktop because Create() tries to talk to
  // parent, and default parent (NULL) is busy doing the calculation when the
  // this happens.
  CWnd CWndDesktop;
  CWndDesktop.FromHandle(::GetDesktopWindow());
  Create(CProgressDlg::IDD, &CWndDesktop);

  SetWindowText("Multismart Progress");
}

void CProgressDlg::DoDataExchange(CDataExchange* pDX) {
  CDialog::DoDataExchange(pDX);
  DDX_Control(pDX, id_static_message, static_message);
  DDX_Control(pDX, id_progress_loading, progress_loading);
}


BEGIN_MESSAGE_MAP(CProgressDlg, CDialog)
END_MESSAGE_MAP()

// CProgressDlg message handlers.

void CProgressDlg::PostNcDestroy()  {
  delete this;

  CDialog::PostNcDestroy();
}
