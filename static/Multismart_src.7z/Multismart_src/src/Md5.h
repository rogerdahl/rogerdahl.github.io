#pragma once

// This global func lets CMd5 be the key in CMap(CMap calls it to create hash keys)..
class CMd5;
template<>
UINT AFXAPI HashKey(CMd5& key);

class CMd5 : public CObject {
  public:
    CMd5();
    CMd5(CMd5&);
    CMd5(const void* buf);
    virtual ~CMd5();

#ifdef _DEBUG
    virtual void Dump(CDumpContext& dc) const;
#endif

    void LoadMem(const void* buf);

    int operator==(const CMd5&) const;
    int operator!=(const CMd5&) const;
    CMd5& operator=(const CMd5& s);
    CMd5& operator=(const void* buf);
    operator CString();

    void Serialize(CArchive& ar);

    // Create hash key from data.
    UINT HashKey();

    // DECLARE_SERIAL generates the C++ header code necessary for a
    // CObject-derived class that can be serialized.
    DECLARE_SERIAL(CMd5)

  private:
    u64 iMd5[2];

  public:

    //
    // 3rd party.
    //

    /* Structure to save state of computation between the single steps. */
    struct md5_ctx {
      u32 A;
      u32 B;
      u32 C;
      u32 D;

      u32 total[2];
      u32 buflen;
      char buffer[128];
    };

    /*
     * The following three functions are build up the low level used in
     * the functions `md5_stream' and `md5_buffer'.
     */

    /* Initialize structure containing state of computation.
     (RFC 1321, 3.3: Step 3) */
    void md5_init_ctx(struct md5_ctx* ctx);

    /* Starting with the result of former calls of this function (or the
     initialization function update the context for the next LEN bytes
     starting at BUFFER.
     It is necessary that LEN is a multiple of 64!!! */
    void md5_process_block(const void* buffer, size_t len, struct md5_ctx* ctx);

    /* Starting with the result of former calls of this function (or the
     initialization function update the context for the next LEN bytes
     starting at BUFFER.
     It is NOT required that LEN is a multiple of 64. */
    void md5_process_bytes(const void* buffer, size_t len, struct md5_ctx* ctx);

    /* Process the remaining bytes in the buffer and put result from CTX
     in first 16 bytes following RESBUF. The result is always in little
     endian byte order, so that a byte-wise output yields to the wanted
     ASCII representation of the message digest.

     IMPORTANT: On some systems it is required that RESBUF be correctly
     aligned for a 32 bits value. */
    void* md5_finish_ctx(struct md5_ctx* ctx, void* resbuf);


    /* Put result from CTX in first 16 bytes following RESBUF. The result is
     always in little endian byte order, so that a byte-wise output yields
     to the wanted ASCII representation of the message digest.

     IMPORTANT: On some systems it is required that RESBUF is correctly
     aligned for a 32 bits value. */
    void* md5_read_ctx(const struct md5_ctx* ctx, void* resbuf);


    /* Compute MD5 message digest for bytes read from STREAM. The
     resulting message digest number will be written into the 16 bytes
     beginning at RESBLOCK. */
    u64 md5_stream(FILE* stream, void* resblock);

    /* Compute MD5 message digest for LEN bytes beginning at BUFFER. The
     result is always in little endian byte order, so that a byte-wise
     output yields to the wanted ASCII representation of the message
     digest. */
    void* md5_buffer(const char* buffer, size_t len, void* resblock);
};
