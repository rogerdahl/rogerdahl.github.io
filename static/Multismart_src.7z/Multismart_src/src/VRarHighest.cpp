#include "stdafx.h"
#include "Multismart.h"
#include "VRarHighest.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CVHighest::CVHighest() {

}
CVHighest::~CVHighest() {

}


// Gen.

bool CVHighest::LoadFolder(bool fQuick) {
  CVPar::LoadFolder(fQuick);

  ProgressSet("Estimating RAR part counts...", 65);
  FindHighestRar();
  return true;
}

bool CVHighest::FindHighestRar() {
  CVHighest::map.RemoveAll();
  CVHighestCont hf;
  CString csRarFullNameKey, csRarFirstNameKey, csRarLastNameKey;
  POSITION pos;

  // Create map that contains only unique RAR archive names from folder (one
  // name for each multipart archive). each name maps to the highest RAR part
  // found.
  //
  // Do this first from PAR and SFV files because of fCntVerified flag.

  // Search PAR.
  CVParChildItem* pItemChild;
  pos = CVPar::mapChildNameToItem.GetStartPosition();

  while (pos != NULL) {
    CVPar::mapChildNameToItem.GetNextAssoc(pos, csRarFullNameKey, pItemChild);
    u32 nPart = GetRarPartNumber(csRarFullNameKey);

    if (nPart) {
      // Update highest RAR part.
      if (!CVHighest::map.Lookup(csRarFirstNameKey, hf) || nPart == hf.nLast) {
        hf.u64MaxSize = 0;
        hf.csDisplayFname = pItemChild->csDisplayFname.Left(pItemChild->csDisplayFname.GetLength() - 4);
        hf.nRarType = GetRarPartType(csRarFullNameKey);
        hf.nFirst = 0;
        hf.nLast = nPart;
        hf.u64LastSize = 0;
        hf.fCntVerified = true;
        CVHighest::map.SetAt(csRarFirstNameKey, hf);
      }
    }
  }

  // Repeat with SFV.

  CVSfvCont sf;
  pos = CVSfv::map.GetStartPosition();

  while (pos != NULL) {
    CVSfv::map.GetNextAssoc(pos, csRarFullNameKey, sf);
    u32 nPart = GetRarPartNumber(csRarFullNameKey);

    // Update highest RAR part.
    if (nPart) {
      if (!CVHighest::map.Lookup(csRarFirstNameKey, hf) || nPart == hf.nLast) {
        hf.u64MaxSize = 0;
        hf.csDisplayFname = sf.csDisplayFname.Left(sf.csDisplayFname.GetLength() - 4);
        hf.nRarType = GetRarPartType(csRarFullNameKey);
        hf.nFirst = 0;
        hf.nLast = nPart;
        hf.u64LastSize = 0;
        hf.fCntVerified = true;
        CVHighest::map.SetAt(csRarFirstNameKey, hf);
      }
    }
  }

  // Repeat for DISK files.

  CVDiskCont df;
  pos = CVDisk::GetStartPosition();
  hf.nFirst = 0;

  while (pos != NULL) {
    CVDisk::GetNextAssoc(&pos, &csRarFullNameKey, &df);

    if (SplitRAR(csRarFullNameKey, &csRarFirstNameKey, &csRarLastNameKey)) {
      // Update highest RAR part if part not already found in PAR or SFV file.
      if (!CVHighest::map.Lookup(csRarFirstNameKey, hf)) {
        CString csDisplayFnameFirst, csDisplayFnameLast;
        SplitRAR(df.csDisplayFname, &csDisplayFnameFirst, &csDisplayFnameLast);
        //NEWEDIT: df.csDisplayFname.Left(df.csDisplayFname.GetLength() - 4);
        hf.csDisplayFname = csDisplayFnameFirst;
        hf.nRarType = GetRarPartType(csRarLastNameKey);
        hf.nFirst = GetRarPartNumber(csRarLastNameKey);
        hf.nLast = GetRarPartNumber(csRarLastNameKey);
        hf.u64LastSize = df.m_size;
        hf.u64MaxSize = df.m_size;
        hf.fCntVerified = false;
        CVHighest::map.SetAt(csRarFirstNameKey, hf);
      }
      else {
        bool fSet = false;

        if (hf.u64MaxSize < df.m_size) {
          hf.u64MaxSize = df.m_size;
          fSet = true;
        }

        if (GetRarPartNumber(csRarLastNameKey) == hf.nLast) {
          hf.nLast = GetRarPartNumber(csRarLastNameKey);
          hf.u64LastSize = df.m_size;
          fSet = true;
        }

        if (hf.nFirst == 0 || GetRarPartNumber(csRarLastNameKey) < hf.nFirst) {
          hf.nFirst = GetRarPartNumber(csRarLastNameKey);
          fSet = true;
        }

        if (fSet) {
          CVHighest::map.SetAt(csRarFirstNameKey, hf);
        }
      }
    }
  }

  TRACE("CVHighest::FindHighestRar()  Loaded %d items\n", CVHighest::map.GetCount());

  return true;
}


/*
	GetSelect is called when virtual files need to be translated to
	real files.

	Currently, CVHighest does not add any real files to the list of files
	to delete.
*/
bool CVHighest::GetSelect(CStringList* csFnames, CMapStringToPtr* mapReal) {
  TRACE("CVHighest::GetSelect()  begin\n");

  TRACE("CVHighest::GetSelect()  end\n");

  // No files added.
  return false;
}
