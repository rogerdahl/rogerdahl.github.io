#include "stdafx.h"
#include "Multismart.h"
#include "DescriptionCleanDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CDescrCleanConfirmDlg dialog.


CDescrCleanConfirmDlg::CDescrCleanConfirmDlg(CWnd* pParent /*=NULL*/)
  : CDialog(CDescrCleanConfirmDlg::IDD, pParent) {
  EnableAutomation();

  chk_nomore = FALSE;
}


void CDescrCleanConfirmDlg::OnFinalRelease() {
  CDialog::OnFinalRelease();
}

void CDescrCleanConfirmDlg::DoDataExchange(CDataExchange* pDX) {
  CDialog::DoDataExchange(pDX);
  DDX_Control(pDX, id_pic_question, pic_question);
  DDX_Check(pDX, id_chk_nomore, chk_nomore);
}

BEGIN_MESSAGE_MAP(CDescrCleanConfirmDlg, CDialog)
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CDescrCleanConfirmDlg, CDialog)
END_DISPATCH_MAP()

static const IID IID_IDlgDescriptionClean = { 0xdba36c78, 0xf947, 0x47e9, { 0xa1, 0xfa, 0x8e, 0x47, 0xbd, 0xed, 0x7f, 0xdc } };

BEGIN_INTERFACE_MAP(CDescrCleanConfirmDlg, CDialog)
INTERFACE_PART(CDescrCleanConfirmDlg, IID_IDlgDescriptionClean, Dispatch)
END_INTERFACE_MAP()


// CDescrCleanConfirmDlg message handlers.

BOOL CDescrCleanConfirmDlg::OnInitDialog()  {
  CDialog::OnInitDialog();

  // Questionmark icon.

  HICON h = LoadIcon(NULL, IDI_QUESTION);
  pic_question.SetIcon(h);

  // return TRUE unless you set the focus to a control
  return TRUE;
}

void CDescrCleanConfirmDlg::OnOK()  {
  UpdateData(true);

  HKEY	myhnd;
  DWORD	num, dsize = sizeof(num);

  if (chk_nomore) {
    // User selected to remove confirmation from now on so create registry key.

    RegCreateKeyEx(HKEY_CURRENT_USER, "Software\\dahlsys\\multismart", 0, " ",
                   REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS | KEY_WRITE, NULL, &myhnd, NULL);
    num = 1;
    RegSetValueEx(myhnd, "chk_hide_description_confirmation", 0, REG_DWORD, (BYTE*)&num, dsize);
  }

  CDialog::OnOK();
}

void CDescrCleanConfirmDlg::OnCancel()  {
  // TODO: Add extra cleanup here.

  CDialog::OnCancel();
}

INT_PTR CDescrCleanConfirmDlg::DoModal()  {
  // Return IDOK if dialog has been disabled.

  HKEY	myhnd;
  DWORD	num, dsize = sizeof(num);

  RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\dahlsys\\multismart", 0, KEY_READ, &myhnd);

  if (RegQueryValueEx(myhnd, "chk_hide_description_confirmation", NULL, NULL, (BYTE*)&num, &dsize) == ERROR_SUCCESS) {
    // Dialog has been disabled, so return IDOK.

    return IDOK;
  }

  return CDialog::DoModal();
}
