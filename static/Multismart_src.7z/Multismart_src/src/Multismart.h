#pragma once

#ifndef __AFXWIN_H__
#error include 'stdafx.h' before including this file for PCH
#endif

#include "../res/resource.h"       // main symbols

//template<> void AFXAPI SerializeElements<CStringA> (CArchive& ar, CStringA* pElements, INT_PTR nCount);
//template<> void AFXAPI SerializeElements<CStringW> (CArchive& ar, CStringW* pElements, INT_PTR nCount);
//

//template<>
//void AFXAPI SerializeElements< CStringA >(CArchive& ar, CStringA* pElements, INT_PTR nCount)
//{
//	SerializeElementsInsertExtract(ar, pElements, nCount);
//}

//template<class CString>
//void AFXAPI SerializeElements(CArchive& ar, CString* pElement, INT_PTR nCount) {
//	if (ar.IsStoring()) {
//		//for (s32 i = 0; i < nCount; i++, pElement++)
//		//	(*pElement)->Serialize(ar);
//	}
//	else {
//		//for (s32 i = 0; i < nCount; i++, pElement++) {
//		//	*pElement = new CString;
//		//	(*pElement)->Serialize(ar);
//		//}
//	}
//}


// CMultismartApp:.
// See Multismart.cpp for the implementation of this class.
//

class CMultismartApp : public CWinApp {
  public:
    CMultismartApp();
    virtual BOOL InitInstance();

    // Implementation.
    COleTemplateServer m_server;
    // Server object for document creation.
    afx_msg void OnAppAbout();
    afx_msg void OnUpdateFileOpen(CCmdUI* pCmdUI);
    afx_msg void OnFileOpen();
    afx_msg void OnToolsReset();
    afx_msg void OnTest();
    afx_msg void OnUpdateTest(CCmdUI* pCmdUI);
    afx_msg void OnTest2();

    u32 CountOpenDocuments();
    bool HaveOpenDocuments();
    DECLARE_MESSAGE_MAP()
};
