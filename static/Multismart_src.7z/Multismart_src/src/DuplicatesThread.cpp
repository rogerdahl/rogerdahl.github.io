#include "stdafx.h"
#include "Multismart.h"
#include "DuplicatesThread.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CDuplicatesThread.

IMPLEMENT_DYNCREATE(CDuplicatesThread, CWinThread)

CDuplicatesThread::CDuplicatesThread() {
  TRACE("CDuplicatesThread::CDuplicatesThread()\n");
}

CDuplicatesThread::~CDuplicatesThread() {
  TRACE("CDuplicatesThread::~CDuplicatesThread()\n");
}

BOOL CDuplicatesThread::InitInstance() {
  pDlg = new CDuplicatesDlg;

  iTxtCnt = 0;

  return TRUE;
}

int CDuplicatesThread::ExitInstance() {
  return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CDuplicatesThread, CWinThread)
  ON_THREAD_MESSAGE(UWM_ADDSTR, OnMsgAddStr)
END_MESSAGE_MAP()


// CDuplicatesThread message handlers.

void CDuplicatesThread::OnMsgAddStr(WPARAM wParam, LPARAM lParam) {
  CString* csInfo = (CString*) wParam;

  pDlg->rich_info.SetSel(iTxtCnt, iTxtCnt);
  pDlg->rich_info.ReplaceSel(*csInfo);

  iTxtCnt += csInfo->GetLength();

  delete csInfo;
}

bool CDuplicatesThread::AddStr(CString cs) {
  CString* csTransfer = new CString;
  *csTransfer = cs;
  this->PostThreadMessage(UWM_ADDSTR, (WPARAM)csTransfer, 0);

  return true;
}
