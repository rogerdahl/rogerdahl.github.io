#include "stdafx.h"
#include "Multismart.h"
#include "DuplicatesDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CDuplicatesDlg dialog.


CDuplicatesDlg::CDuplicatesDlg(CWnd* pParent /*=NULL*/)
  : CDialog(CDuplicatesDlg::IDD, pParent) {
  AfxInitRichEdit();

  CWnd CWndDesktop;
  CWndDesktop.FromHandle(::GetDesktopWindow());
  Create(CDuplicatesDlg::IDD, &CWndDesktop);
}

void CDuplicatesDlg::DoDataExchange(CDataExchange* pDX) {
  CDialog::DoDataExchange(pDX);
  DDX_Control(pDX, id_rich_info, rich_info);
}


BEGIN_MESSAGE_MAP(CDuplicatesDlg, CDialog)
END_MESSAGE_MAP()


// CDuplicatesDlg message handlers.

void CDuplicatesDlg::OnOK()  {
  DestroyWindow(); // used in modeless dialogs instead of call to base class
  ::PostQuitMessage(0); // best way to quit UI thread

  // AfxEndThread is only used to exit worker threads or to prematurely quit thread.
  // If it is used, ExitInstance() is not called.
  // AfxEndThread(0 /*nExitCode*/);.
}

void CDuplicatesDlg::PostNcDestroy()  {
  delete this;

  CDialog::PostNcDestroy();
}
