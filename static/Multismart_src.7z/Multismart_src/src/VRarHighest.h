#pragma once

#include "VPar.h"

// Hold the highest known RAR part of every known RAR archive. The highest known
// part may exist either on disk or in an SFV file. If it was found in an SFV
// file, the fCntVerified flag it set.
//
// Also holds the highest known file size of every known RAR archive. Is
// undefined if fCntVerified flag is set.
//
// Also holds last name of first known disk file. I know that according to the
// name of the container, it doesn't belong here but it is very convenient to
// have it here and I don't want to make a separate class for "lowest files".

class CVHighestCont {
  public:
    CString csDisplayFname; // filename.RAR for display (key is lower case)
    u8 nRarType; // type of RAR. Type1 = rar, r01, r02 etc. Type2 = part000.rar, part001.rar etc.
    u32 nFirst; // number of first existing disk file
    u32 nLast; // number of last existing disk file
    u64 u64LastSize;// size of last known part (0 if last known part is SFV child)
    u64 u64MaxSize; // highest known disk file size
    bool fCntVerified;// highest was found in SFV or PAR file (false if found on disk)
};

// Key in CVHighest is lower case RAR archive firstname.

class CVHighest : public CVPar {
  public:
    CVHighest();
    virtual ~CVHighest();

    bool LoadFolder(bool fQuick);
    bool FindHighestRar();
    bool GetSelect(CStringList* csFnames, CMapStringToPtr* mapReal);

    CMap<CString, LPCSTR, CVHighestCont, CVHighestCont&> map;

    virtual bool ProgressStart() = 0;
    virtual bool ProgressStop() = 0;
    virtual bool ProgressSet(CString, u32) = 0;
    virtual void PostMessageView(u32, WPARAM, LPARAM) = 0;
    virtual CString GetWorkingFolder() = 0;
  private:
};
