#include "stdafx.h"
#include "Multismart.h"
#include "SelectDlg.h"
#include "SelectCleanupDlg.h"
#include "SelectRequestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CSelectDlg::CSelectDlg(CWnd* pParent /*=NULL*/)
  : CDialog(CSelectDlg::IDD, pParent) {
  EnableAutomation();
}


void CSelectDlg::OnFinalRelease() {
  CDialog::OnFinalRelease();
}

void CSelectDlg::DoDataExchange(CDataExchange* pDX) {
  CDialog::DoDataExchange(pDX);
  DDX_Control(pDX, id_pic_info, pic_info2);
  DDX_Control(pDX, id_tab, tab);
}


BEGIN_MESSAGE_MAP(CSelectDlg, CDialog)
  ON_REGISTERED_MESSAGE(UWM_CLICK_OK, OnUWM_CLICK_OK)
  ON_NOTIFY(TCN_SELCHANGING, id_tab, OnSelchangingtab)
  ON_NOTIFY(TCN_SELCHANGE, id_tab, OnSelchangetab)
  ON_WM_DESTROY()
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CSelectDlg, CDialog)
END_DISPATCH_MAP()

static const IID IID_IDlgSelect = { 0xadc07d2d, 0x1b19, 0x4d86, { 0x87, 0xa5, 0x3c, 0x55, 0xeb, 0xfe, 0x2, 0x52 } };

BEGIN_INTERFACE_MAP(CSelectDlg, CDialog)
INTERFACE_PART(CSelectDlg, IID_IDlgSelect, Dispatch)
END_INTERFACE_MAP()

// CSelectDlg message handlers.

BOOL CSelectDlg::OnInitDialog()  {
  CDialog::OnInitDialog();

  // Create tabs.

  TC_ITEM TabItem;
  TabItem.mask = TCIF_TEXT;
  TabItem.pszText = "For Delete";
  tab.InsertItem(0, &TabItem);
  TabItem.pszText = "For Copy / Request";
  tab.InsertItem(1, &TabItem);

  // Calc pos.

  RECT re;
  re.top = 18;
  re.left = 5;
  re.right = 0;
  re.bottom = 0;
  MapDialogRect(&re);

  // Create page 1 and save it's handle in tab1 user space and show window in
  // correct space.

  CSelectCleanupDlg* pPage1 = new CSelectCleanupDlg;

  TabItem.mask = TCIF_PARAM;
  TabItem.lParam = (LPARAM)pPage1;
  tab.SetItem(0, &TabItem);

  VERIFY(pPage1->Create(CSelectCleanupDlg::IDD, &tab));
  pPage1->SetWindowPos(NULL, re.left, re.top, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
  pPage1->ShowWindow(SW_SHOW);
  pPage1->EnableWindow(TRUE);

  // Same for page 2.

  CSelectRequestDlg* pPage2 = new CSelectRequestDlg;

  TabItem.mask = TCIF_PARAM;
  TabItem.lParam = (LPARAM)pPage2;
  tab.SetItem(1, &TabItem);

  VERIFY(pPage2->Create(CSelectRequestDlg::IDD, &tab));
  pPage2->SetWindowPos(NULL, re.left, re.top, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
  pPage2->ShowWindow(SW_HIDE);
  pPage2->EnableWindow(TRUE);

  // Information icon.

  HICON h = LoadIcon(NULL, IDI_INFORMATION);
  pic_info2.SetIcon(h);

  // return TRUE unless you set the focus to a control
  return TRUE;
}

void CSelectDlg::OnSelchangingtab(NMHDR* pNMHDR, LRESULT* pResult)  {
  // Fetch window handle from relevant tab and hide window.

  int	iTab = tab.GetCurSel();
  TC_ITEM	tci;

  tci.mask = TCIF_PARAM;
  tab.GetItem(iTab, &tci);
  ASSERT(tci.lParam);

  if (iTab == 0) {
    CSelectCleanupDlg* pWnd = (CSelectCleanupDlg*)tci.lParam;

    if (!pWnd->MyVerify()) {
      *pResult = -1;
      return;
    }

    pWnd->ShowWindow(SW_HIDE);
    pWnd->EnableWindow(FALSE);

    *pResult = 0;
  }
  else {
    CSelectRequestDlg* pWnd = (CSelectRequestDlg*)tci.lParam;

    if (!pWnd->MyVerify()) {
      *pResult = -1;
      return;
    }

    pWnd->ShowWindow(SW_HIDE);
    pWnd->EnableWindow(FALSE);

    *pResult = 0;
  }
}

void CSelectDlg::OnSelchangetab(NMHDR* pNMHDR, LRESULT* pResult)  {
  // Fetch window handle from relevant tab and show window.

  int	iTab = tab.GetCurSel();
  TC_ITEM	tci;
  tci.mask = TCIF_PARAM;
  tab.GetItem(iTab, &tci);
  ASSERT(tci.lParam);

  CWnd* pWnd = (CWnd*)tci.lParam;
  pWnd->ShowWindow(SW_SHOW);
  pWnd->EnableWindow(TRUE);

  *pResult = 0;
}

void CSelectDlg::OnDestroy()  {
  CDialog::OnDestroy();

  // Manually destroy all tab pages, cause they were allocated with new.

  int		iTab = 0;
  TC_ITEM	tci;
  CWnd* pWnd;
  tci.mask = TCIF_PARAM;

  for (int i = 0; i < 2; i++) {
    tab.GetItem(i, &tci);
    ASSERT(tci.lParam);
    pWnd = (CWnd*)tci.lParam;
    pWnd->DestroyWindow();
    delete pWnd;
  }
}

LRESULT CSelectDlg::OnUWM_CLICK_OK(WPARAM wParam, LPARAM lParam) {
  OnOK();
  return 0;
}

void CSelectDlg::OnOK()  {
  int	iTab = tab.GetCurSel();
  TC_ITEM	tci;

  tci.mask = TCIF_PARAM;
  tab.GetItem(iTab, &tci);
  ASSERT(tci.lParam);

  if (iTab == 0) {
    CSelectCleanupDlg* pWnd = (CSelectCleanupDlg*)tci.lParam;

    if (!pWnd->MyVerify()) {
      return;
    }

    iDaysLast = pWnd->select_edit_daylast;
    iParts = pWnd->select_edit_parts;
    fLessThan = false;
  }
  else {
    CSelectRequestDlg* pWnd = (CSelectRequestDlg*)tci.lParam;

    if (!pWnd->MyVerify()) {
      return;
    }

    iDaysLast = pWnd->request_edit_daylast;
    iParts = pWnd->request_edit_parts;
    fLessThan = true;
  }

  CDialog::OnOK();
}
