#include "stdafx.h"
#include "Multismart.h"

#include "MainFrm.h"
#include "ChildFrm.h"
#include "MultismartDoc.h"
#include "MultismartView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

BEGIN_MESSAGE_MAP(CMultismartApp, CWinApp)
  ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
  ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
  ON_COMMAND(ID_TOOLS_RESET, OnToolsReset)
  ON_COMMAND(ID_TEST, OnTest)
  ON_UPDATE_COMMAND_UI(ID_TEST, OnUpdateTest)
  ON_COMMAND(ID_TEST_2, OnTest2)
  ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
  ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
  ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

CMultismartApp::CMultismartApp() {
}

// The one and only CMultismartApp object.

CMultismartApp theApp;

static const CLSID clsid = { 0x522c2223, 0xc7b0, 0x473b, { 0xa7, 0xe1, 0x5b, 0x41, 0xb1, 0x5c, 0x6a, 0x86 } };

// CMultismartApp initialization.

//void AFXAPI SerializeElements< CStringA >(CArchive& ar, CStringA* pElements, INT_PTR nCount)
//{
//	SerializeElementsInsertExtract(ar, pElements, nCount);
//}

BOOL CMultismartApp::InitInstance() {
  if (!AfxSocketInit()) {
    AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
    return FALSE;
  }

  // Initialize OLE libraries.
  if (!AfxOleInit()) {
    AfxMessageBox(IDP_OLE_INIT_FAILED);
    return FALSE;
  }

  AfxEnableControlContainer();

  // Change the registry key under which our settings are stored.

  SetRegistryKey(_T("dahlsys"));

  // Load standard INI file options (including MRU).
  LoadStdProfileSettings();

  // Register the application's document templates.  Document templates
  // serve as the connection between documents, frame windows and views.

  CMultiDocTemplate* pDocTemplate;
  pDocTemplate = new CMultiDocTemplate(
    IDR_MULTISTYPE,
    RUNTIME_CLASS(CMultismartDoc),
    // Custom MDI child frame.
    RUNTIME_CLASS(CChildFrame),
    RUNTIME_CLASS(CMultismartView));
  AddDocTemplate(pDocTemplate);

  // Connect the COleTemplateServer to the document template. The
  // COleTemplateServer creates new documents on behalf of requesting OLE
  // containers by using information specified in the document template..
  m_server.ConnectTemplate(clsid, pDocTemplate, FALSE);

  // Register all OLE server factories as running. This enables the OLE
  // libraries to create objects from other applications.
  COleTemplateServer::RegisterAll();
  // Note: MDI applications register all server objects without regard to the
  // /Embedding or /Automation on the command line.

  // Create main MDI Frame window.
  CMainFrame* pMainFrame = new CMainFrame;

  if (!pMainFrame->LoadFrame(IDR_MAINFRAME)) {
    return FALSE;
  }

  m_pMainWnd = pMainFrame;

  // Parse command line for standard shell commands, DDE, file open.
  CCommandLineInfo cmdInfo;
  ParseCommandLine(cmdInfo);

  // Check to see if launched as OLE server.
  if (cmdInfo.m_bRunEmbedded || cmdInfo.m_bRunAutomated) {
    // Application was run with /Embedding or /Automation.  Don't show the
    // main window in this case.
    return TRUE;
  }

  // When a server application is launched stand-alone, it is a good idea to
  // update the system registry in case it has been damaged..
  m_server.UpdateRegistry(OAT_DISPATCH_OBJECT);
  COleObjectFactory::UpdateRegistryAll();

  // Dispatch commands specified on the command line.
  if (!ProcessShellCommand(cmdInfo)) {
    return FALSE;
  }

  // The main window has been initialized, so show and update it.
  pMainFrame->ShowWindow(m_nCmdShow);
  pMainFrame->UpdateWindow();

  return TRUE;
}

// Open the about dialog.
void CMultismartApp::OnAppAbout() {
  AfxMessageBox("Multismart\n\nHelp and documentation: www.dahlsys.com", MB_ICONINFORMATION | MB_OKCANCEL);
}

// CMultismartApp message handlers.

// Default version of OnFileOpen displays a file open dialog. Since I need a
// folder open dialog, I override it and display that.
void CMultismartApp::OnFileOpen()  {
  BROWSEINFO bi;
  LPITEMIDLIST pidlBrowse;
  LPITEMIDLIST pidlPrograms;
  char dname[MAX_PATH];

  SHGetSpecialFolderLocation(NULL, CSIDL_DESKTOP, &pidlPrograms);

  // Fill in the BROWSEINFO structure.
  bi.hwndOwner = AfxGetMainWnd()->GetSafeHwnd();
  bi.pidlRoot = pidlPrograms;
  bi.pszDisplayName = dname;
  bi.lpszTitle = "Choose Folder";
  bi.ulFlags = BIF_RETURNONLYFSDIRS;// | BIF_USENEWUI;
  bi.lpfn = NULL;
  bi.lParam = 0;

  // Browse for a folder and return its PIDL.
  pidlBrowse = SHBrowseForFolder(&bi);

  if (pidlBrowse == NULL) {
    return;
  }

  SHGetPathFromIDList(pidlBrowse, dname);

  // Free the PIDL returned by SHBrowseForFolder.
  LPMALLOC ima;
  SHGetMalloc(&ima);
  ima->Free(pidlBrowse); // TODO: This is a possible bug.
  ima->Release();

  // Go ahead and try opening the document.
  AfxGetApp()->OpenDocumentFile(dname);
}

u32 CountOpenDocuments() {
  int nDocuments = 0;
  POSITION pos = AfxGetApp()->GetFirstDocTemplatePosition();
  CDocTemplate* pTemplate;

  do  {
    pTemplate = AfxGetApp()->GetNextDocTemplate(pos);
    POSITION docpos = pTemplate->GetFirstDocPosition();

    while (docpos != NULL) {
      nDocuments++;
      pTemplate->GetNextDoc(docpos);
    }
  }
  while (pos != NULL);

  return nDocuments;
}

bool HaveOpenDocuments() {
  POSITION pos = AfxGetApp()->GetFirstDocTemplatePosition();
  CDocTemplate* pTemplate = AfxGetApp()->GetNextDocTemplate(pos);

  if (pTemplate->GetFirstDocPosition()) {
    return true;
  }
  else {
    return false;
  }
}

void CMultismartApp::OnToolsReset()  {
  if (AfxMessageBox("Are you sure you want to reset all tool settings?", MB_ICONQUESTION | MB_OKCANCEL) == IDCANCEL) {
    return;
  }

  RegDeleteKey(HKEY_CURRENT_USER, "Software\\dahlsys\\multismart");
}

void CMultismartApp::OnUpdateTest(CCmdUI* pCmdUI) {
  pCmdUI->Enable();
}

void CMultismartApp::OnTest() {
}

void CMultismartApp::OnTest2() {
}
