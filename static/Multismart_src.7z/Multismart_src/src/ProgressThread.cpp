#include "stdafx.h"
#include "Multismart.h"
#include "ProgressThread.h"
#include "ProgressDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

IMPLEMENT_DYNCREATE(CProgressThread, CWinThread)

CProgressThread::CProgressThread() {
}

CProgressThread::~CProgressThread() {
}

BOOL CProgressThread::InitInstance() {
  pDlg = new CProgressDlg;

  return TRUE;
}

int CProgressThread::ExitInstance() {
  pDlg->DestroyWindow();

  return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CProgressThread, CWinThread)
  ON_THREAD_MESSAGE(UWM_UPDATEPROGRESS, OnMsgUpdateProgress)
END_MESSAGE_MAP()

// CProgressThread message handlers.

void CProgressThread::OnMsgUpdateProgress(WPARAM wParam, LPARAM lParam) {
  TRACE("CThreadLoading::OnMsgUpdateProgress()\n");

  CString* csInfo = (CString*) wParam;

  pDlg->progress_loading.SetPos(static_cast<int>(lParam));
  pDlg->static_message.SetWindowText(*csInfo);

  delete csInfo;
}
