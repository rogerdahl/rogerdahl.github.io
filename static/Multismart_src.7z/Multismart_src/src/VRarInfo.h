#pragma once

#include "VGap.h"

enum enumRarStatus { RAR_OK, RAR_COMPLETEQ, RAR_COMPLETE, RAR_SIZEERROR, RAR_CRCERROR, RAR_PENDING, RAR_OPENERROR };
enum enumKnownParts { KNOWNPARTS_ALL, KNOWNPARTS_PROBABLYALL, KNOWNPARTS_MORE };

class CVRarInfoCont {
  public:
    CVRarInfoCont()				{ };
    virtual ~CVRarInfoCont()	{ };

    void Reset() {
      timeFirst = NULL;
      timeLast = NULL;
      u32DiskParts = 0;
      u32KnownParts = 0;
      u32Substitutions = 0;
      iGoodParents = 0;
      u64DiskSize = 0;
      u64EstSize = 0;
      fCntVerified = 0;
      iWorstError = RAR_OK;
      u8KnownPartsStatus = KNOWNPARTS_ALL;
      iErrors = 0;
      fParExists = false;
    }

    CString csDisplayFname; // filename for display (key is lower case)
    CTime	timeFirst; // earliest date of disk files
    CTime	timeLast; // last date of disk files
    u32		u32DiskParts; // how many disk parts are present
    u32		u32KnownParts; // how many parts does the archive have (estimate)
    u32		u32Substitutions; // number of PAR->RAR substitutions made
    u32		iGoodParents; // associated, known good Pxx archives that have not been used for substitutions
    u64		u64DiskSize; // combined size of all parts on disk
    u64		u64EstSize; // estimated size of all known parts
    bool	fCntVerified; // was last known part in SFV file in addition to being on disk
    u8		iWorstError; // archive status. See enum
    u8		u8KnownPartsStatus; // what is known about known parts
    u32		iErrors; // number of files that have the error in iWorstError. undefined if no error
    bool	fParExists; // Pxx files exist for archive
};

// Key in CVRarInfo is lower case RAR archive firstname.
class CVRarInfo :
  public CVGap {
    /* */
  public:
    CVRarInfo();
    virtual			~CVRarInfo();

    bool			LoadFolder(bool fQuick);
    bool			FindRarInfo();
    bool			GetSelect(CStringList* csFnames, CMapStringToPtr* mapReal);
    bool			FindRarInfoOneArchive(CString csRarFirstNameKey);
    bool			NotifyChange(CString* csFname);

    virtual bool	ProgressStart() = 0;
    virtual bool	ProgressStop() = 0;
    virtual bool	ProgressSet(CString, u32) = 0;

    CMap<CString, LPCSTR, CVRarInfoCont, CVRarInfoCont&>	map;
    virtual void	PostMessageView(u32, WPARAM, LPARAM) = 0;
    virtual CString GetWorkingFolder() = 0;

    /* */
  private:
};
