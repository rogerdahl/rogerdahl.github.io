#include "stdafx.h"
#include "Multismart.h"
#include "SortableStringArray.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CSortableStringArray::CSortableStringArray() {
}

CSortableStringArray::~CSortableStringArray() {
}

int CSortableStringArray::Compare(const CString* pstr1, const CString* pstr2) {
  ASSERT(pstr1);
  ASSERT(pstr2);
  return pstr1->CompareNoCase(*pstr2);
}

void CSortableStringArray::Sort(STRINGCOMPAREFN pfnCompare /*= CSortedStringArray::Compare */) {
  CString* prgstr = GetData();
  qsort(prgstr, GetSize(), sizeof(CString), (GENERICCOMPAREFN)pfnCompare);
}
