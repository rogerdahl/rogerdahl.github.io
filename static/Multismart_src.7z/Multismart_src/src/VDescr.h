#pragma once

#include "VFile.h"

class CVDescr : public CVDisk {
  public:
    CVDescr();
    virtual ~CVDescr();

    bool LoadFolder(bool fQuick);
    bool LoadDescriptions();

    CMapStringToString map;

    virtual bool ProgressStart() = 0;
    virtual bool ProgressStop() = 0;
    virtual bool ProgressSet(CString, u32) = 0;
    virtual void PostMessageView(u32, WPARAM, LPARAM) = 0;
    virtual CString GetWorkingFolder() = 0;
  private:
};

