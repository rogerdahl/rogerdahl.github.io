// Regular ASSERT opens dialog that enables program to continue accepting
// messages and run past the ASSERT. Mine breaks directly to the debugger.
#ifdef _DEBUG
#define MYASSERT(exp) if (!(exp)) AfxDebugBreak();
#else
#define MYASSERT(exp)
#endif

s8* strnstr(s8* pStr, const s8* pFind, u32 nStrLen);
bool FindString(s8* pStr, s8* pFind, u32 nStrLen, u32* pnFoundOffset);

bool SplitRAR(CString csIn, CString* cs1, CString* cs2);
bool SplitPAR(CString csIn, CString* cs1, CString* cs2);
s32 Rar2Int(CString csIn);
CString Int2Rar(s32 iPart);

CString ToSensible(s64 i);
CString GetLocaleTime(CTime ct);
u8 GetRarPartType(CString csPart);
CString GetRarPartNameFromNumber(u32 n, u8 nType);
u32 GetRarPartNumber(CString csPart);
s32 CmpRarPartNames(CString r1, CString r2);
void LastErrorMessageBox(CString); // display message and "cause: lasterror"
CString& MyGetLastError();
bool CopyCStringToClipboard(CString csTxt);
bool BstrToStr(BSTR Input, LPTSTR Result);
bool StrToBstr(LPTSTR Input, BSTR Result);

void AFXAPI SerializeElements(CArchive& ar, CString* pElements, INT_PTR nCount);
