#pragma once

class CDeleteConfirmDlg : public CDialog {
  public:
    bool AddFile(CString csFname);
    // Standard constructor.
    CDeleteConfirmDlg(CMapStringToPtr* mapRealIn, CWnd* pParent = NULL);

    // Dialog Data.
    enum { IDD = id_dlg_delete_confirm };
    CListBox	list_files;
    CStatic	static_warning;
    BOOL	chk_nomore;

    // Overrides.
  public:
    virtual INT_PTR DoModal();
  protected:
    // DDX/DDV support.
    virtual void DoDataExchange(CDataExchange* pDX);

    // Implementation.
  protected:
    CMapStringToPtr* mapReal;

    virtual BOOL OnInitDialog();
    virtual void OnOK();
    virtual void OnCancel();

    DECLARE_MESSAGE_MAP()
};
