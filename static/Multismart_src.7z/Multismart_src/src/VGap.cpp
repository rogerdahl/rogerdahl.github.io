#include "stdafx.h"
#include "VGap.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CVGap::CVGap() {
}

CVGap::~CVGap() {
}

// Gen.

bool CVGap::LoadFolder(bool fQuick) {
  CVHighest::LoadFolder(fQuick);

  ProgressSet("Finding RAR sequence gaps...", 80);
  FindGaps();

  return true;
}

bool CVGap::FindGaps() {
  map.RemoveAll();

  // For each name in RarHighest, generate a RAR sequence up to the highest RAR
  // part found for that archive, and add all files not found in either the file
  // map or the SFV map to the gap map.
  //
  // RAR archive sequence: RAR -> r00 ... r99 -> s00 ........

  CVDiskCont df;
  CVSfvCont sf;
  CVHighestCont hf;
  CVGapCont gf;

  CString csRarFullNameKey, csRarLastNameCnt, csRarFirstNameKey;

  POSITION pos = CVHighest::map.GetStartPosition();

  while (pos != NULL) {
    CVHighest::map.GetNextAssoc(pos, csRarFirstNameKey, hf);

    u32 nLastCnt(0);

    while (hf.nLast != nLastCnt) {
      csRarFullNameKey = hf.csDisplayFname + CString(".") + GetRarPartNameFromNumber(nLastCnt, hf.nRarType);

      if (!CVDisk::Lookup(csRarFullNameKey, &df) && !CVSfv::map.Lookup(csRarFullNameKey, sf)) {
        gf.csDisplayFname = csRarFullNameKey;
        map.SetAt(csRarFullNameKey, gf);
      }

      nLastCnt++;
    }
  }

  TRACE("CVGap::FindGaps()  Loaded %d items\n", map.GetCount());

  return true;
}

/*
	GetSelect is called when virtual files need to be translated to
	real files.

	CVGap responds by adding files that exist in its map to the list.
*/
bool CVGap::GetSelect(CStringList* csFnames, CMapStringToPtr* mapReal) {
  TRACE("CVGap::GetSelect()  begin\n");

  POSITION pos;
  CString csFname, csFnameKey;
  bool fAdded = false;
  CVGapCont gf;

  for (pos = csFnames->GetHeadPosition(); pos != NULL;) {
    csFname = csFnames->GetNext(pos);
    csFnameKey = csFname;
    csFnameKey.MakeLower();

    if (map.Lookup(csFnameKey, gf)) {
      (*mapReal)[csFname] = NULL;
      fAdded = true;

      TRACE("Added: %s\n", csFname);
    }
  }

  TRACE("CVGap::GetSelect()  end\n");

  return fAdded;
}
