#include "stdafx.h"
#include "Multismart.h"
#include "VRarInfo.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CVRarInfo::CVRarInfo() {
}

CVRarInfo::~CVRarInfo() {
}

// Gen.

// Add an entry containing information about the archive given by first name
// key.
//
// The state of a RAR archive is described through two sequences of possible
// errors. One for errors in all the existing files of the archive:
//
// RAR_OK -> RAR_COMPLETEQ -> RAR_COMPLETE -> RAR_SIZEERROR -> RAR_CRCERROR ->
// RAR_PENDING -> RAR_OPENERROR
//
// And one for missing files:
//
// KNOWNPARTS_ALL -> KNOWNPARTS_PROBABLYALL -> KNOWNPARTS_MORE
//
// RAR errors get bumped up through the states. Never down. The error on the
// right is considered most serious.
//
// Strategy:
//
// I first check any PAR parents for the archive. I find out how many there are,
// and I count each of the different types of errors for existing files.
//
// I then check all files in the archive, again counting each of the different
// types of errors for existing files, and also "bumping" the status for missing
// files.
//
// After finding all the facts about PAR files and RAR files in the archive, I
// use present and healthy PAR files to adjust the statistics on the number and
// health of the parts of the archive. If I find that enough PAR files exist to
// complete fix all errors of the archive, I declare the archive healthy no
// matter how many errors it has.
//
// The main design goal for this function was to create rar items that display
// as if missing/broken archive parts have already been restored using available
// PAR parents (even though that can not actually be done until enough parents
// exist to completely fix all the files in the set). And to display errors in
// both PAR and RAR files as if they affect the archive in the exact same way.
bool CVRarInfo::FindRarInfoOneArchive(CString csRarFirstNameKey) {
  CString			csRarFullNameKey;
  CVDiskCont		itemDisk;
  CVSfvCont		itemSfv;
  CVHighestCont	itemHighest;
  CVRarInfoCont	itemRarInfo;
  itemRarInfo.Reset();

  CVHighest::map.Lookup(csRarFirstNameKey, itemHighest);

  s32	iLastPart = itemHighest.nLast;

  // PAR

  // Check if a set exists for this archive.
  CVParSetItem* pItemSet;
  CMd5 md5Parent;

  if (mapChildNameToSet.Lookup(csRarFirstNameKey + ".rar", pItemSet)) {
    CVParParentItem* pItemParent;
    POSITION	posMapParents = pItemSet->mapParents.GetStartPosition();

    while (posMapParents != NULL) {
      pItemSet->mapParents.GetNextAssoc(posMapParents, md5Parent, pItemParent);

      // Ignore the file if it doesn't exist on disk anymore.
      if (!CVDisk::Lookup(pItemParent->csDisplayFname, &itemDisk)) {
        continue;
      }

      itemRarInfo.fParExists = true;

      // Ignore the file if it has no parity information.
      if (pItemParent->iVolumePos == 0) {
        continue;
      }

      // Assume that a parent is good. Reverse this if we find out otherwise later.
      itemRarInfo.iGoodParents++;

      // Adjust time range.
      if (itemRarInfo.timeFirst == NULL || itemRarInfo.timeFirst > itemDisk.m_mtime) {
        itemRarInfo.timeFirst = itemDisk.m_mtime;
      }

      if (itemRarInfo.timeLast == NULL || itemRarInfo.timeLast < itemDisk.m_mtime) {
        itemRarInfo.timeLast = itemDisk.m_mtime;
      }

      // Add to size.
      itemRarInfo.u64DiskSize += itemDisk.m_size;

      // If I still haven't picked a size for estimation, do it now.
      if (!itemRarInfo.u64EstSize) {
        itemRarInfo.u64EstSize = itemDisk.m_size;
      }

      // CRC Status of PAR file.
      switch (itemDisk.iCrcStatus) {
        case CRCSTATUS_NOTATTEMPTED:

          // "bump" up to RAR_PENDING and start counting this type of errors.
          if (itemRarInfo.iWorstError < RAR_PENDING) {
            itemRarInfo.iWorstError = RAR_PENDING;
            itemRarInfo.iErrors = 0;
          }

          // Only count RAR_PENDING errors from now on.
          if (itemRarInfo.iWorstError == RAR_PENDING) {
            itemRarInfo.iErrors++;
          }

          break;

        case CRCSTATUS_OPENERROR:

          if (itemRarInfo.iWorstError < RAR_OPENERROR) {
            itemRarInfo.iWorstError = RAR_OPENERROR;
            itemRarInfo.iErrors = 0;
          }

          if (itemRarInfo.iWorstError == RAR_OPENERROR) {
            itemRarInfo.iErrors++;
          }

          break;

        case CRCSTATUS_CALCULATED:

          // CRC has been calculated. check it.
          if (itemRarInfo.iWorstError <= RAR_CRCERROR && itemDisk.md5 != pItemParent->md5) {
            if (itemRarInfo.iWorstError < RAR_CRCERROR) {
              itemRarInfo.iWorstError = RAR_CRCERROR;
              itemRarInfo.iErrors = 0;
            }

            if (itemRarInfo.iWorstError == RAR_CRCERROR) {
              itemRarInfo.iErrors++;
            }

            itemRarInfo.iGoodParents--;
          }

          break;
      }
    }
  }

  // RAR
  for (s32 iPart = -1 /*rar*/ ; iPart <= iLastPart; iPart++) {
    // Find would-be key name for this rar part.
    csRarFullNameKey = csRarFirstNameKey + "." + Int2Rar(iPart);

    // If file doesn't exist on disk, no more info can be derived from file, so
    // we skip it.
    if (!CVDisk::Lookup(csRarFullNameKey, &itemDisk)) {
      continue;
    }

    // It exists on disk. it may be ok or broken.

    // Check if part is covered by PAR and/or SFV.
    bool fParSetExists = !!CVPar::mapChildNameToSet.Lookup(csRarFullNameKey, pItemSet);
    bool fSfvExists = !!CVSfv::map.Lookup(csRarFullNameKey, itemSfv);

    // Adjust time range.
    if (itemRarInfo.timeFirst == NULL || itemRarInfo.timeFirst > itemDisk.m_mtime) {
      itemRarInfo.timeFirst = itemDisk.m_mtime;
    }

    if (itemRarInfo.timeLast == NULL || itemRarInfo.timeLast < itemDisk.m_mtime) {
      itemRarInfo.timeLast = itemDisk.m_mtime;
    }

    // Add to size.
    itemRarInfo.u64DiskSize += itemDisk.m_size;

    // If I still haven't picked a size for estimation, do it now.
    if (!itemRarInfo.u64EstSize) {
      itemRarInfo.u64EstSize = itemDisk.m_size;
    }

    // CRC / PAR / size status.
    switch (itemDisk.iCrcStatus) {
      case CRCSTATUS_NOTATTEMPTED:

        // If file has SFV or PAR parent...
        if (fParSetExists || fSfvExists) {
          if (itemRarInfo.iWorstError < RAR_PENDING) {
            itemRarInfo.iWorstError = RAR_PENDING;
            itemRarInfo.iErrors = 0;
          }

          itemRarInfo.iErrors++;
        }
        else {
          // If file does not have SFV or PAR parent.
          //
          // If this is not last known part && size is smaller than biggest file
          // found in archive.
          if (iPart != iLastPart && itemDisk.m_size < itemHighest.u64MaxSize) {
            if (itemRarInfo.iWorstError < RAR_SIZEERROR) {
              itemRarInfo.iWorstError = RAR_SIZEERROR;
              itemRarInfo.iErrors = 0;
            }

            itemRarInfo.iErrors++;
          }
          else {
            // Count this healthy part.
            itemRarInfo.u32DiskParts++;
          }
        }

        break;

      case CRCSTATUS_OPENERROR:

        if (itemRarInfo.iWorstError < RAR_OPENERROR) {
          itemRarInfo.iWorstError = RAR_OPENERROR;
          itemRarInfo.iErrors = 0;
        }

        itemRarInfo.iErrors++;
        break;

      case CRCSTATUS_CALCULATED:
        // CRC has been calculated. Compare it with the one stored in the PAR
        // map if it.

        if (fParSetExists) {
          CVParChildItem* cParChildItem;

          if
          (
            itemRarInfo.iWorstError <= RAR_CRCERROR
            &&	CVPar::mapChildNameToItem.Lookup(csRarFullNameKey, cParChildItem)
            &&	cParChildItem->md5 != itemDisk.md5
          ) {
            if (itemRarInfo.iWorstError < RAR_CRCERROR) {
              itemRarInfo.iWorstError = RAR_CRCERROR;
              itemRarInfo.iErrors = 0;
            }

            itemRarInfo.iErrors++;
          }
          else {
            // Count this healthy part.
            itemRarInfo.u32DiskParts++;
          }
        }
        else if
        (
          itemRarInfo.iWorstError <= RAR_CRCERROR			// haven't found more serious errors and...
          &&	CVSfv::map.Lookup(csRarFullNameKey, itemSfv)	// file is SFV child
          &&	itemSfv.crc != itemDisk.crc
        )
        {
          // CRC check failed.
          if (itemRarInfo.iWorstError < RAR_CRCERROR) {
            // "bump" up to RAR_CRCERROR and start counting this type of errors.
            itemRarInfo.iWorstError = RAR_CRCERROR;
            itemRarInfo.iErrors = 0;
          }

          itemRarInfo.iErrors++;
        }
        else {
          // Count this healthy part.
          itemRarInfo.u32DiskParts++;
        }

        break;

      default:
        // Shouldn't get here.
        ASSERT(0);
        break;
    }
  }

  itemRarInfo.fCntVerified = itemHighest.fCntVerified;
  itemRarInfo.csDisplayFname = itemHighest.csDisplayFname;
  // Add 2, one for "rar" and one for "r00".
  itemRarInfo.u32KnownParts = iLastPart + 2;

  // Use any good PAR parts to fix any bad RAR parts (substitutions).
  //
  // How many substs do I need to fix all errors and missing files?
  u16 iNeedSubst = itemRarInfo.u32KnownParts - itemRarInfo.u32DiskParts;

  // Do I need more substs than I have?
  if (iNeedSubst > itemRarInfo.iGoodParents) {
    // Yes. use all I have.
    itemRarInfo.u32Substitutions = itemRarInfo.iGoodParents;
  }
  else {
    // No. use all I need.
    itemRarInfo.u32Substitutions = iNeedSubst;
  }

  // Do the substitutions.
  itemRarInfo.u32DiskParts += itemRarInfo.u32Substitutions;

  // Decide if I know how many parts this archive should have:
  // - I know the number of parts (last part found in par/sfv)
  // - probably know the number of parts (last part not found in par/sfv but
  //   shorter than other parts)
  // - there's more parts (last part found is not in par/sfv but is same size as
  //   other parts)
  // - there's only one part (part is ".rar" and the size is not a round number

  // Last part found in SFV or PAR, so consider number of parts as known.
  if (itemHighest.fCntVerified) {
    itemRarInfo.u8KnownPartsStatus = KNOWNPARTS_ALL;
  }
  else
    // Last part not found in SFV or PAR, so make guestimate based on size of
    // last known part.
    if (itemHighest.u64LastSize < itemHighest.u64MaxSize) {
      itemRarInfo.u8KnownPartsStatus = KNOWNPARTS_PROBABLYALL;
    }
    else
      // Assume that single .rar file without parents is a complete archive IF
      // the size is not a. Round number (divisible by either 1000 or 1024).
      if (itemRarInfo.u32KnownParts == 1 && itemRarInfo.u64DiskSize % 1000 != 0 && itemRarInfo.u64DiskSize % 1024 != 0) {
        itemRarInfo.u8KnownPartsStatus = KNOWNPARTS_PROBABLYALL;
      }
      else {
        itemRarInfo.u8KnownPartsStatus = KNOWNPARTS_MORE;
      }

  /*
  	if I have enough known good parts that this archive can be fixed, then override any errors found
  	and say this archive is complete
  */
  if (itemRarInfo.u32DiskParts >= itemRarInfo.u32KnownParts) {
    switch (itemRarInfo.u8KnownPartsStatus) {
      case KNOWNPARTS_ALL:
        // Have SFV or PAR parent and no errors found, so archive is complete.
        itemRarInfo.iWorstError = RAR_COMPLETE;
        break;
      case KNOWNPARTS_PROBABLYALL:
        itemRarInfo.iWorstError = RAR_COMPLETEQ;
        break;
      case KNOWNPARTS_MORE:
        // Don't do anything. I get here if I have all known parts but I know
        // there's more parts.
        break;
      default:
        // Unknown status.
        ASSERT(0);
        break;
    }
  }

  // Estimated size. if we have known last part, do accurate estimate.
  if (itemHighest.fCntVerified) {
    itemRarInfo.u64EstSize = itemRarInfo.u64EstSize *
                             (itemRarInfo.u32KnownParts - 1) +
                             itemDisk.m_size /* size of last part we know about */ ;
  }
  else {
    // No known last part.
    itemRarInfo.u64EstSize *= itemRarInfo.u32KnownParts;
  }

  // Add rf to map.
  CVRarInfo::map.SetAt(csRarFirstNameKey, itemRarInfo);

  return true;
}

/* */
bool CVRarInfo::LoadFolder(bool fQuick) {
  CVGap::LoadFolder(fQuick);

  ProgressSet("Grouping, counting and matching SVF, PAR and RAR parts...", 100);
  FindRarInfo();

  return true;
}

/* */
bool CVRarInfo::FindRarInfo() {
  CVRarInfo::map.RemoveAll();

  CVHighestCont	itemHighest;

  CString			csRarFirstNameKey;

  // Iterate over RarHighestFile, and create RARINFO entries.

  // (RarHighestFile maps unique RAR archives and highest known part of each archive).
  POSITION pos = CVHighest::map.GetStartPosition();

  while (pos != NULL) {
    CVHighest::map.GetNextAssoc(pos, csRarFirstNameKey, itemHighest);
    FindRarInfoOneArchive(csRarFirstNameKey);
  }

  return true;
}

/*
	GetSelect is called when virtual files need to be translated to
	real files.

	CVRarInfo responds by adding all files that are children of the
	selected RarInfo files.
*/
bool CVRarInfo::GetSelect(CStringList* csFnames, CMapStringToPtr* mapReal) {
  TRACE("CVRarInfo::GetSelect()  begin\n");

  POSITION		pos;
  CString			csFname, csFnameKey, csRarFullName, csRarFullNameKey;
  bool			fAdded = false;
  CVRarInfoCont	itemRarInfo;
  CVHighestCont	itemHighest;
  CVDiskCont		df;

  for (pos = csFnames->GetHeadPosition(); pos != NULL;) {
    csFname = csFnames->GetNext(pos);
    csFnameKey = csFname;
    csFnameKey.MakeLower();

    if (CVRarInfo::map.Lookup(csFnameKey, itemRarInfo)) {
      // Found a rarinfo file.

      // Add all RAR and PAR files that this rarinfo file contains info about.
      CVParParentItem* pItemParent;
      CVParSetItem* pItemSet;
      CMd5	md5Parent;

      CVHighest::map.Lookup(csFnameKey, itemHighest);

      s32 iLastPart = itemHighest.nLast;

      for (s32 iPart = -1 /*rar*/ ; iPart <= iLastPart; iPart++) {
        csRarFullName = csFname + "." + Int2Rar(iPart);
        csRarFullNameKey = csRarFullName;
        csRarFullNameKey.MakeLower();

        // PAR.
        if (mapChildNameToSet.Lookup(csRarFullNameKey, pItemSet)) {
          // Add all parents.
          POSITION	pos = pItemSet->mapParents.GetStartPosition();

          while (pos != NULL) {
            pItemSet->mapParents.GetNextAssoc(pos, md5Parent, pItemParent);
            (*mapReal)[pItemParent->csDisplayFname] = NULL;
            TRACE("Added: %s\n", pItemParent->csDisplayFname);
          }
        }

        // RAR.
        (*mapReal)[csRarFullName] = NULL;
        TRACE("Added: %s\n", csRarFullName);

        fAdded = true;
      }
    }
  }

  FindRarInfo();

  TRACE("CVRarInfo::GetSelect()  end\n");

  return fAdded;
}

/*
	Notify RARINFO about file state changes.

	When the state of a rar part changes, the information in the RARINFO
	file that encompass that file changes.

	Returns true and the name of the rarinfo entry if rarinfo entry changed.
	False otherwise.
*/
bool CVRarInfo::NotifyChange(CString* csFnameKey) {
  CString csRarFirstNameKey, csRarLastNameKey;

  if (SplitRAR(*csFnameKey, &csRarFirstNameKey, &csRarLastNameKey)) {
    // File was a RAR part.
    FindRarInfoOneArchive(csRarFirstNameKey);
    *csFnameKey = csRarFirstNameKey;

    return true;
  }

  CVParParentItem* pItemParent;

  if (mapParentNameToItem.Lookup(*csFnameKey, pItemParent)) {
    // File was a PAR parent. Find any RAR file in set and update rar info.
    CMd5	md5Set;
    CVParSetItem* pItemSet;

    if (mapParentToSet.Lookup(pItemParent->md5, md5Set) && mapSets.Lookup(md5Set, pItemSet)) {
      CVParChildItem* pItemChild;
      CMd5		md5Child;
      POSITION	pos = pItemSet->mapChildren.GetStartPosition();

      while (pos != NULL) {
        pItemSet->mapChildren.GetNextAssoc(pos, md5Child, pItemChild);

        if (SplitRAR(pItemChild->csDisplayFname, &csRarFirstNameKey, &csRarLastNameKey)) {
          csRarFirstNameKey.MakeLower();
          FindRarInfoOneArchive(csRarFirstNameKey);
          *csFnameKey = csRarFirstNameKey;

          return true;
        }
      }
    }
  }

  return false;
}
