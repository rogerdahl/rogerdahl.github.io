#pragma once

#include "VDescr.h"

// Container CVSfvCont represents one file listed in an SFV file.

class CVSfvCont {
  public:
    // Filename for display (key is lower case).
    CString csDisplayFname;
    u32 crc;
    // Parent SFV file.
    CString csSFVFile;
};

// Map collection represents all physical files in DL folder.

class CVSfv : public CVDescr {
  public:
    CVSfv();
    virtual ~CVSfv();

    bool LoadFolder(bool fQuick);
    bool LoadSFVFiles();
    bool LoadFile(CString csFile);
    bool RemoveChildless();
    bool GetSelect(CStringList* csFnames, CMapStringToPtr* mapReal);

    CMap<CString, LPCSTR, CVSfvCont, CVSfvCont&> map;

    virtual bool ProgressStart() = 0;
    virtual bool ProgressStop() = 0;
    virtual bool ProgressSet(CString, u32) = 0;
    virtual void PostMessageView(u32, WPARAM, LPARAM) = 0;
    virtual CString GetWorkingFolder() = 0;
  private:
};
