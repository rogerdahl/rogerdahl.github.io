#pragma once

enum enumRadio {RADIO_EXISTING, RADIO_VIRTUAL, RADIO_EXISTINGANDVIRTUAL};

class CCopyDlg : public CDialog {
  public:
    // Standard constructor.
    CCopyDlg(CWnd* pParent = NULL);

    // Dialog Data.
    enum { IDD = id_dlg_copy };
    CStatic	pic_question;
    BOOL	chk_nomore;
    int		radio_existing;

  public:
    virtual INT_PTR DoModal();
  protected:
    // DDX/DDV support.
    virtual void DoDataExchange(CDataExchange* pDX);

    // Implementation.
  protected:
    virtual BOOL OnInitDialog();
    virtual void OnOK();

    DECLARE_MESSAGE_MAP()
};
