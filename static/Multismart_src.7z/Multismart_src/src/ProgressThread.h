#pragma once

#include "ProgressDlg.h"

#define UWM_UPDATEPROGRESS (WM_APP + 1848)


// CProgressThread thread.

class CProgressThread : public CWinThread {
    DECLARE_DYNCREATE(CProgressThread)
  protected:
    // Protected constructor used by dynamic creation.
    CProgressThread();

  public:
    virtual BOOL InitInstance();
    virtual int ExitInstance();

    // Implementation.
  protected:
    virtual ~CProgressThread();

    DECLARE_MESSAGE_MAP()

    CProgressDlg* pDlg;
    void OnMsgUpdateProgress(WPARAM wParam, LPARAM lParam);
};
