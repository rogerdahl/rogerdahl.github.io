#pragma once

#include <afxtempl.h>
class CVParSetItem;
class CVParParentItem;
class CVParChildItem;
class CMd5;

//template<> void AFXAPI ConstructElements<CVParChildItem*>(CVParChildItem** pElements, int nCount);

//template<> DestructElements<CVParSetItem*>(CVParSetItem** pElements, int nCount);
//template<> DestructElements<CVParParentItem*>(CVParParentItem** pElements, int nCount);
//template<> DestructElements<CVParChildItem*>(CVParChildItem** pElements, int nCount);

//template<CVParSetItem*> void AFXAPI DestructElements(CVParSetItem** pElements, int nCount);
//template<CVParParentItem*> void AFXAPI DestructElements(CVParParentItem** pElements, int nCount);
//template<CVParChildItem*> void AFXAPI DestructElements(CVParChildItem** pElements, int nCount);
