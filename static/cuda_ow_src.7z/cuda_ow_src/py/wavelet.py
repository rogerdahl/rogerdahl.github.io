# Display the individual images involved in a wavelet transform.
from struct import unpack
from graphics import *
import sys

w = 352
h = 240

win = GraphWin("", w * 6, h * 4)

for level in range (7):
	print 'level: ' + str (level)
	for i in range (4):
		if level == 0 and i > 0:
			continue
		print 'i: ' + str (i)
		p = Pixmap (w, h)
		step = 1 << level
		f = open('wavelet_%d_%d.dat' % (level, i), 'rb')
		for y in xrange (h):
			for x in xrange (w):
				c = unpack('d', f.read(8)) # f = 32 bit float
				# Because the pixel values only ever get added up in the transformation, we need to divide by 2^step
				# before displaying.
				d = int (c [0] / (2 ** level))
				if d < 0: d = 0
				if d > 255: d = 255
				p.setPixel (x, y, (d, d, d))
		i = Image (Point(level * w + (w / 2), i * h + (h / 2)), p)
		i.draw (win)
		#win.update ()
		
win.getMouse ()
