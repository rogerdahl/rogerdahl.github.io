#pragma once

#include <vector_types.h>
#include "int_types.h"

#define CUDA_CHECK_CALL( call ) {                                      \
    cudaError err = call;                                              \
    if( cudaSuccess != err) {                                          \
        printf("Cuda error in file '%s' in line %i : %s.\n",           \
                __FILE__, __LINE__, cudaGetErrorString( err) );        \
    } }

extern "C" {
	bool ow_init ();
	bool ow_dinit ();
	bool ow_filter (float* img, int w, int h, int depth, float strength);
}
