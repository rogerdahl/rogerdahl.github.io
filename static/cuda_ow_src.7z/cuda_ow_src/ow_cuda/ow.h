// DLL interface.

#ifdef OW_DLL_BUILD
#define OW_DLL_API __declspec (dllexport)
#else
#define OW_DLL_API __declspec (dllimport)
#endif

#ifdef __cplusplus
extern "C" {
#endif

// __stdcall 

// CUDA
int OW_DLL_API gpu_init (int cuda_device);
int OW_DLL_API gpu_dinit ();

// OW
int OW_DLL_API gpu_ow_init ();
int OW_DLL_API gpu_ow_dinit ();
int OW_DLL_API gpu_ow_filter (float* img, int w, int h, int depth, float strength);

#ifdef __cplusplus
}
#endif
