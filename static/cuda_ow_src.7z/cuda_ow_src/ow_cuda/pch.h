#pragma once

// Win.
#include "targetver.h"
#include <windows.h>

// My specific integer types.
#include "int_types.h"

// Std.
#include <string>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>

// CUDA
#include <cuda_runtime_api.h>
#include <cutil.h>
