#include <vector>

class wxColor;

void yuv420p_frame_to_rgb_mono_frame (std::vector<u8>& rgb, const std::vector<u8>& yuv, u32 w, u32 h);
void yuv420p_frame_to_mono_frame (std::vector<u8>& mono, const std::vector<u8>& yuv, u32 w, u32 h);
void yuv420p_frame_to_float_mono_frame (std::vector<float>& mono, const std::vector<u8>& yuv, u32 w, u32 h);

void yuv422_frame_to_mono_frame (std::vector<u8>& mono, const std::vector<u8>& yuv, u32 w, u32 h);
void yuv422_frame_to_rgb_frame (std::vector<u8>& rgb, const std::vector<u8>& yuv, u32 w, u32 h);
void yuv422_to_rgb (wxColor& c1, wxColor& c2, const std::vector<u8>& yuv, u32 idx);
wxColor yuv422_to_rgb (const s32 y, const s32 u, const s32 v);
