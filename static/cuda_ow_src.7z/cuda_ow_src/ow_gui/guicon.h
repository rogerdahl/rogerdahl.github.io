void RedirectIOToConsole();
