bool cpu_ow_init (int width, int height, int depth);
bool cpu_ow_dinit ();
bool cpu_ow_filter (float* img, float strength);
