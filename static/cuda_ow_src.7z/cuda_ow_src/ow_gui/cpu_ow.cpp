#include <pch.h>

// This filter uses the Cohen-Daubechies-Fauraue (CDF) 9/7 wavelet (the same
// wavelet used for lossy compression in JPEG2000) to smooth out the low
// frequencies in an image.

/**
* @todo try to change to int
* @todo try lifting based implementation
* @todo optimize optimize optimize
* @todo hard tresholding
* @todo use QP to decide filter strength
* @todo wavelet normalization / least squares optimal signal vs. noise thresholds
*/

#include <stdio.h>
#include <string.h>
#include <math.h>

#include <boost/timer.hpp>
using namespace boost;

const u8 dither [8][8] = {
	{  0,  48,  12,  60,   3,  51,  15,  63, },
	{ 32,  16,  44,  28,  35,  19,  47,  31, },
	{  8,  56,   4,  52,  11,  59,   7,  55, },
	{ 40,  24,  36,  20,  43,  27,  39,  23, },
	{  2,  50,  14,  62,   1,  49,  13,  61, },
	{ 34,  18,  46,  30,  33,  17,  45,  29, },
	{ 10,  58,   6,  54,   9,  57,   5,  53, },
	{ 42,  26,  38,  22,  41,  25,  37,  21, },
};

struct priv_s {
	int depth;
	float* plane [16][4];
} priv;

int w_;
int h_;

#define S 1.41421356237f // sqrt (2)

// Daubechies 9/7 Coefficients.

// lopass Filter hL(i)
const float coeff_lopass [] = {
	+0.60294901823635790f * S,
	+0.26686411844287230f * S,
	-0.07822326652898785f * S,
	-0.01686411844287495f * S,
	+0.02674875741080976f * S
};

// hipass Filter hn(i).
// 0.0 at the end is to fix bug in code that also looks up a value at this position. Is 0.0 the right value?
const float coeff_hipass [] = {
	+1.11508705245699400f / S,
	-0.59127176311424700f / S,
	-0.05754352622849957f / S,
	+0.09127176311424948f / S,
	+0.0
};

// lopass Filter hL(i)
// 0.0 at the end is to fix bug in code that also looks up a value at this position. Is 0.0 the right value?
const float coeff_inv_lopass [] = {
	+1.11508705245699400f / S,
	+0.59127176311424700f / S,
	-0.05754352622849957f / S,
	-0.09127176311424948f / S,
	+0.0
};

	// hipass Filter hn(i).
const float coeff_inv_hipass [] = {
	+0.60294901823635790f * S,
	-0.26686411844287230f * S,
	-0.07822326652898785f * S,
	+0.01686411844287495f * S,
	+0.02674875741080976f * S
};

#undef S

// Table for 1919:
//
// -1 = 1
// -2 = 2
// -3 = 3
// -4 = 4
//
// 0 - 1919 = unchanged
//
// 1920 = 1918
// 1921 = 1917
// 1922 = 1916
// 1923 = 1915

// Mirroring:
// <--> <-     REGULAR     -> <-->
// edcb abcdefgh....rstuvwxyz yxwv
//
// A loop is required because a given x may have to be "folded"
// over multiple times before it fits within w.

int mirror (int x, int w) {
	--w;
	while ((unsigned)x > (unsigned)w) {
		x = -x;
		if (x < 0)
			x += 2 * w;
	}
	return x;
}

//int mirror (int x, int w) {
//	if (x < 0)
//		return -x;
//	if (x > w)
//		return w + w - x;
//	return x;
//
//	//::wxLogDebug (L"%d\t%d\t%d\t%s", t, x, w, (x == t ? L"" : L"*"));
//}

// wavelet_transform.


// Exact.
//float s ((src [mirror (x - i, w - 1) * stride] + src [mirror (x + i, w - 1) * stride]));
// 	//::wxLogDebug (L"2d");

void wavelet_transform_2d (float *dst_lo, float *dst_hi, float *src, int stride_x, int stride_y, int step, int w, int h) {
	int step_stride (step * stride_x);
	for (int y (0); y < h; ++y) {
		for (int x (0); x < w; ++x) {
			// pos_center is:
			// - the CENTER position for 5 source values.
			// - the EXACT position for 1 highpass and 1 lowpass destination value.
			int pos_center (x * stride_x + y * stride_y); // pos + step_idx * step_stride
			//printf ("%02d\t%02d\n", step, pos_center);
			// Process source values in center position.
			float sum_lo (src [pos_center] * coeff_lopass [0]);
			float sum_hi (src [pos_center] * coeff_hipass [0]);
			// Process source values above and below center.
			int pos_below (pos_center - step_stride);
			int pos_above (pos_center + step_stride);
			for (int i (1); i <= 4; ++i) {
				// Mirror function goes away on the GPU, with mirror addressing mode.
				if (pos_below < 0) pos_below = 0;
				if (pos_above >= w * h) pos_above = w * h - 1;

				float s (src [pos_below] + src [pos_above]);

				pos_below -= step_stride;
				pos_above += step_stride;

				sum_lo += coeff_lopass [i] * s;
				sum_hi += coeff_hipass [i] * s;
			}
			dst_lo [pos_center] = sum_lo;
			dst_hi [pos_center] = sum_hi;
		}
	}
}

// src = plane 0
// tmp 0 = plane 1
// tmp 1 = plane 2

void wavelet_transform () {
	float **tmp = priv.plane [0] + 1;
	for (int i (0); i < priv.depth; ++i) {
		float *src (priv.plane [i][0]);
		float **dst = priv.plane [i + 1];
		int step (1 << i);
		wavelet_transform_2d (tmp [0], tmp [1], src,     1, w_, step, w_, h_);
		wavelet_transform_2d (dst [0], dst [1], tmp [0], w_, 1, step, h_, w_);
		wavelet_transform_2d (dst [2], dst [3], tmp [1], w_, 1, step, h_, w_);
	}
}

// inv_wavelet_transform.
// Comments are in wavelet_transform_2d().

void inv_wavelet_transform_2d (float *dst, float *src_lo, float *src_hi, int stride_x, int stride_y, int step, int w, int h) {
	int step_stride (step * stride_x);
	for (int y (0); y < h; ++y) {
		for (int x (0); x < w; ++x) {
			int pos_center (x * stride_x + y * stride_y);

			float sum_lo (src_lo [pos_center] * coeff_inv_lopass [0]);
			float sum_hi (src_hi [pos_center] * coeff_inv_hipass [0]);

			int pos_below (pos_center - step_stride);
			int pos_above (pos_center + step_stride);

			for (int i (1); i <= 4; ++i) {
				if (pos_below < 0) pos_below = 0;
				if (pos_above >= w * h) pos_above = w * h - 1;

				sum_lo += coeff_inv_lopass [i] * (src_lo [pos_below] + src_lo [pos_above]);
				sum_hi += coeff_inv_hipass [i] * (src_hi [pos_below] + src_hi [pos_above]);

				pos_below -= step_stride;
				pos_above += step_stride;
			}
			dst [pos_center] = (sum_lo + sum_hi) * 0.5;
		}
	}
}

void inv_wavelet_transform () {
	float **tmp = priv.plane [0] + 1;
	for (int i (priv.depth - 1); i >= 0; --i) {
		float *dst (priv.plane [i][0]);
		float **src = priv.plane [i + 1];
		int step (1 << i);
		inv_wavelet_transform_2d (tmp [0], src [0], src [1], w_, 1, step, h_, w_);
		inv_wavelet_transform_2d (tmp [1], src [2], src [3], w_, 1, step, h_, w_);
		inv_wavelet_transform_2d (dst,     tmp [0], tmp [1], 1, w_, step, w_, h_);
	}
}

bool cpu_ow_init (int w, int h, int depth) {
	memset (&priv, 0, sizeof (priv));

	// Adjust depth.
	while (1 << depth > w || 1 << depth > h) {
		--depth;
	}

	w_ = w;
	h_ = h;

	priv.depth = depth;

	for (int j (0); j < 4; ++j) {
		for (int i (0); i <= priv.depth; ++i) {
			priv.plane [i][j] = (float*) malloc (w_ * h_ * sizeof (priv.plane [0][0][0]));
		}
	}

	return true;
}

bool cpu_ow_dinit () {
	for (int j (0); j < 4; ++j) {
		for (int i (0); i <= priv.depth; ++i) {
			free (priv.plane [i][j]);
			priv.plane [i][j] = NULL;
		}
	}

	return false;
}

bool cpu_ow_filter (float* img, float strength) {
	// Copy image plane (Y, U or V) from img.
	for (int y (0); y < h_; ++y) {
		for (int x (0); x < w_; ++x) {
			priv.plane [0][0][x + w_ * y] = img [x + w_ * y];
		}
	}
	
	wavelet_transform ();

	// Smooth the low frequencies.
	for (int i (0); i < priv.depth; ++i) {
		for (int j (1); j < 4; ++j) {
			for (int y (0); y < h_; ++y) {
				for (int x (0); x < w_; ++x) {
					float v (priv.plane [i + 1][j][x + w_ * y]);
					if (v > strength) {
						v -= strength;
					}
					else if (v < -strength) {
						v += strength;
					}
					else {
						v = 0;
					}
					priv.plane [i + 1][j][x + w_ * y] = v;
				}
			}
		}
	}

	inv_wavelet_transform ();

	// Apply dithering to image and copy it to dst.
	for (int y (0); y < h_; ++y) {
		for (int x (0); x < w_; ++x){
			// Yes the rounding is insane but optimal :)
			int i (priv.plane [0][0][x + w_ * y] + dither [x & 7][y & 7] * (1.0 / 64.0) + 1.0 / 128.0);
			if ((unsigned)i > 255U) i = ~ (i >> 31);
			img [x + w_ * y] = i;
		}
	}

	return false;
}
