#include "pch.h"
#include "yuv.h"

// - YUV420 (YV12): For every four luma (Y) bytes there are two chroma bytes
//   (alternating Cr and Cb)
// - YUV422 (UYUV): For every luma byte there is one chroma byte (alternating Cr
//   and Cb). 
//
// - In YUV420, 6 bytes describe 4 pixels (buffer is 1.5x the size of w * h).
// - In YUV422, 4 bytes describe 2 pixels (buffer is 2x the size of w * h).
// - In RGB, 3 bytes describe 1 pixel  (buffer is 3x the size of w * h).
// - In a monochrome buffer, 1 float describes one pixel.

using namespace std;

void yuv420p_frame_to_rgb_mono_frame (vector<u8>& rgb, const vector<u8>& yuv, u32 w, u32 h) {
	u32 idx (0);
	for (u32 i (0); i < w * h; ++i) {
		u8 y (yuv [i]);
		rgb [idx++] = y;
		rgb [idx++] = y;
		rgb [idx++] = y;
	}
}

void yuv420p_frame_to_mono_frame (vector<u8>& mono, const vector<u8>& yuv, u32 w, u32 h) {
	for (u32 i (0); i < w * h; ++i) {
		mono [i] = yuv [i];
	}
}

void yuv420p_frame_to_float_mono_frame (vector<float>& mono, const vector<u8>& yuv, u32 w, u32 h) {
	for (u32 i (0); i < w * h; ++i) {
		mono [i] = static_cast <float> (yuv [i]);
	}
}

void yuv422_frame_to_mono_frame (vector<u8>& mono, const vector<u8>& yuv, u32 w, u32 h) {
	assert (yuv.size () == 2 * w * h);
	u32 idx (0);
	for (u32 i (0); i < w * h * 2; i += 4) {
		mono[idx++] = yuv[i + 1];
		mono[idx++] = yuv[i + 3];
	}
	assert (mono.size () == w * h);
}

void yuv422_frame_to_rgb_frame (vector<u8>& rgb, const vector<u8>& yuv, u32 w, u32 h) {
	u32 idx (0);
	for (u32 i(0); i < w * h * 2; i += 4) {
		wxColor rgb1, rgb2;
		yuv422_to_rgb (rgb1, rgb2, yuv, i);
		rgb[idx++] = rgb1.Red ();
		rgb[idx++] = rgb1.Green ();
		rgb[idx++] = rgb1.Blue ();
		rgb[idx++] = rgb2.Red ();
		rgb[idx++] = rgb2.Green ();
		rgb[idx++] = rgb2.Blue ();
	}
}

void yuv422_to_rgb (wxColor& c1, wxColor& c2, const vector<u8>& yuv, u32 idx) {
	u8 u (yuv[idx + 0]);
	u8 y1 (yuv[idx + 1]);
	u8 v (yuv[idx + 2]);
	u8 y2 (yuv[idx + 3]);
	c1 = yuv422_to_rgb (y1, u, v);
	c2 = yuv422_to_rgb (y2, u, v);
}

wxColor yuv422_to_rgb (const s32 y, const s32 u, const s32 v) {
	s32 r, g, b;

	s32 um (u - 128);
	s32 vm (v - 128);

	r = y + 1.370705 * vm;
	g = y - 0.698001 * vm - 0.337633 * um;
	b = y + 1.732446 * um;

	// clamp
	if (r < 0) r = 0;
	if (g < 0) g = 0;
	if (b < 0) b = 0;
	if (r > 255) r = 255;
	if (g > 255) g = 255;
	if (b > 255) b = 255;

	return wxColor (r, g, b);
}
