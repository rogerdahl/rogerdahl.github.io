#pragma once

#include <boost/shared_array.hpp>
#include "ffmpeg_wrap.h"

#define video_frame_ctrl_string L"video_frame_ctrl"

class video_frame_ctrl : public wxControl {
	void OnPaint (wxPaintEvent& event);
	void OnSize (wxSizeEvent& event);
	void OnEraseBackground (wxEraseEvent& event);
	void OnMotion (wxMouseEvent& event);

	//std::vector<u8> screenshot_data;
	//wxImage screenshot_image_original;
	//wxImage screenshot_image_filtered;

	//bool display_original;
	//u32 screenshot_w, screenshot_h;

  ffmpeg_wrap ff;
	std::vector<u8> rgb_frame;

  boost::filesystem::wpath video_path_;
	u64 w_;
	u64 h_;
	u32 frame_idx_;
  bool filter;

  // ow
  u32 depth;
  float strength;

	DECLARE_DYNAMIC_CLASS (video_frame_ctrl)
	DECLARE_EVENT_TABLE ()

public:
	video_frame_ctrl ();

	bool Create (wxWindow *parent,
		wxWindowID id,
		const wxPoint& pos = wxDefaultPosition,
		const wxSize& size = wxDefaultSize,
		const wxString& name = video_frame_ctrl_string);

	virtual ~video_frame_ctrl ();
	virtual bool Destroy ();

	void open_video (boost::filesystem::wpath);
	void set_frame_idx (u64 idx);
  void next();
  void swap();
  void ow_param(int depth, float strength);
	//void get_mono_frame (std::vector<u8>& mono, u32 idx);
	//void get_frame_size (u32& w, u32& h);
};
