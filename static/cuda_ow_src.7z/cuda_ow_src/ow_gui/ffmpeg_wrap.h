#include "pch.h"

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
}

class ffmpeg_wrap {
private:
  AVFormatContext *pFormatCtx;
  int             i, videoStream;
  AVCodecContext  *pCodecCtx;
  AVCodec         *pCodec;
  AVFrame         *pFrame; 
  AVFrame         *pFrameRGB;
  int             numBytes;
  u8              *buffer;

public:
  ffmpeg_wrap();
  ~ffmpeg_wrap();
  bool save_frame_to_ppm(boost::filesystem::wpath path, u64 w, u64 h, u8* rgb);
  bool open_video(boost::filesystem::wpath path);
  bool get_dim(u64& w, u64& h);
  bool close();
  bool next(u8* rgb);
};
