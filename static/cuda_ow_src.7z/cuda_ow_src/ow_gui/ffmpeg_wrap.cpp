#include "pch.h"

#include "ffmpeg_wrap.h"

using namespace std;
using namespace boost;
namespace fs = boost::filesystem;

ffmpeg_wrap::ffmpeg_wrap() {
  // Register all formats and codecs
  av_register_all();

  // Use pCodecCtx as flag for if we have an open file.
  pCodecCtx = 0;
}

ffmpeg_wrap::~ffmpeg_wrap() {
}

// Write frame to a PPM file.
bool ffmpeg_wrap::save_frame_to_ppm(fs::wpath path, u64 w, u64 h, u8* rgb) {

  // Open file
  ofstream f(path.file_string().c_str(), ios::binary);
  if (!f.good()) {
    return false;
  }

  // Write header.
  f << "P6\n" << w << " " << h << "\n255\n";

  // Write pixel data.
  for (int y = 0; y < h; ++y) {
    f.write(reinterpret_cast<char*>(rgb + y * w * 3), w * 3);
  }

  f.close();

  return true;
}

bool ffmpeg_wrap::open_video(fs::wpath path) {
  // Open video file
  wstring ws(path.file_string());
  string s(ws.begin(), ws.end());
  if (av_open_input_file(&pFormatCtx, s.c_str(), NULL, 0, NULL) != 0) {
    // Couldn't open file
    return false;
  }

  // Retrieve stream information
  if (av_find_stream_info(pFormatCtx) < 0) {
    // Couldn't find stream information
    return false;
  }

  //// Dump information about file onto standard error
  //dump_format(pFormatCtx, 0, video_file, 0);

  // Find the first video stream
  videoStream =- 1;
  for (unsigned int i = 0; i < pFormatCtx->nb_streams; ++i) {
    if(pFormatCtx->streams[i]->codec->codec_type==CODEC_TYPE_VIDEO) {
      videoStream=i;
      break;
    }
  }
  if(videoStream == -1) {
    // Didn't find a video stream
    return false;
  }

  // Get a pointer to the codec context for the video stream
  pCodecCtx=pFormatCtx->streams[videoStream]->codec;

  // Find the decoder for the video stream
  pCodec=avcodec_find_decoder(pCodecCtx->codec_id);
  if(!pCodec) {
    // Codec not found
    return false;
  }

  // Open codec
  if(avcodec_open(pCodecCtx, pCodec) < 0) {
    // Could not open codec
    return false;
  }

  // Allocate video frame
  pFrame = avcodec_alloc_frame();

  // Allocate an AVFrame structure
  pFrameRGB = avcodec_alloc_frame();
  if(!pFrameRGB) {
    return false;
  }

  // Determine required buffer size and allocate buffer
  numBytes=avpicture_get_size(PIX_FMT_RGB24, pCodecCtx->width,
    pCodecCtx->height);
  buffer = reinterpret_cast<u8*>(av_malloc(numBytes*sizeof(u8)));

  // Assign appropriate parts of buffer to image planes in pFrameRGB
  // Note that pFrameRGB is an AVFrame, but AVFrame is a superset
  // of AVPicture
  avpicture_fill((AVPicture *)pFrameRGB, buffer, PIX_FMT_RGB24,
    pCodecCtx->width, pCodecCtx->height);

  return true;
}

bool ffmpeg_wrap::close() {
  // Silently ignore if there's no open file.
  if (!pCodecCtx) {
    return true;
  }

  // Free the RGB image
  av_free(buffer);
  av_free(pFrameRGB);

  // Free the YUV frame
  av_free(pFrame);

  // Close the codec
  avcodec_close(pCodecCtx);
  pCodecCtx = 0;

  // Close the video file
  av_close_input_file(pFormatCtx);

  return true;
}

// Get next frame.
bool ffmpeg_wrap::next(u8* rgb) {
  // Silently ignore if there's no open file.
  if (!pCodecCtx) {
    return true;
  }

  // Get packets from stream until we have a complete frame
  AVPacket packet;
  while (true) {
    int res = av_read_frame(pFormatCtx, &packet);
    if (res < 0) {
      return 0;
    }
    // Is this a packet from the video stream?
    if (packet.stream_index == videoStream) {
      // Got a video packet. Decode it.
      int frame_finished;
      avcodec_decode_video(pCodecCtx, pFrame, &frame_finished, packet.data, packet.size);
      if (frame_finished) {
        av_free_packet(&packet);
        break;
      }
    }
    av_free_packet(&packet);
  }

  // Convert the image from its native format to RGB
  struct SwsContext *ct = sws_getContext(
    pCodecCtx->width,
    pCodecCtx->height, 
    pCodecCtx->pix_fmt,
    pCodecCtx->width,
    pCodecCtx->height, 
    PIX_FMT_RGB24,
    SWS_LANCZOS | SWS_ACCURATE_RND,
    NULL, NULL, NULL
    );

  // Change pointer to point directly to our buffer.
  pFrameRGB->data[0] = rgb;

  sws_scale(
    ct,
    pFrame->data,
    pFrame->linesize,
    0,
    pCodecCtx->height,
    pFrameRGB->data,
    pFrameRGB->linesize);

  return 1;
}

bool ffmpeg_wrap::get_dim(u64& w, u64& h) {
  w = pCodecCtx->width;
  h = pCodecCtx->height;
  return true;
}
