void read_file_to_vector (const boost::filesystem::wpath& f_path, std::vector<u8>& buf, bool binary);

