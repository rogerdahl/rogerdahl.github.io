#include "pch.h"

#include "guicon.h"
#include "video_frame.h"

using namespace std;
using namespace boost;
namespace fs = boost::filesystem;

// Controls.
video_frame_ctrl* video_frame;

wxSlider* strength_slider;
wxStaticText* strength_slider_text;
wxSlider* depth_slider;
wxStaticText* depth_slider_text;

//wxButton* previous_button;
wxButton* next_button;
wxButton* run_button;
wxButton* stop_button;
wxButton* swap_button;
wxTimer* run_timer;

// Sizer.
wxSizer* topsizer;


// Define a new application type, each program should derive a class from wxApp
class app : public wxApp {
public:
  // override base class virtuals.
  //
  // This one is called on application startup and is a good place for the app
  // initialization (doing it here and not in the ctor allows to have an error
  // return: if OnInit () returns false, the application terminates).
  int FilterEvent (wxEvent& event);
  void OnFatalException();
  virtual bool OnInit ();
};

// Define our main frame.
class main_frame : public wxFrame {
  // Any class wishing to process wxWindows events must use this macro.
  DECLARE_EVENT_TABLE ()

  int frame_idx;
  wstring old_cmd1;
  int old_pos1;
  wstring old_cmd2;
  int old_pos2;

public:
  main_frame (const wxString& title, const wxPoint& pos, const wxSize& size,
    long style = wxDEFAULT_FRAME_STYLE | wxFULL_REPAINT_ON_RESIZE);

  // Event handlers (these functions should _not_ be virtual).
  void OnOpenVideo (wxCommandEvent& event);
  void OnQuit (wxCommandEvent& event);
  void OnAbout (wxCommandEvent& event);

  void OnStrengthSlider (wxCommandEvent& event);
  void OnDepthSlider (wxCommandEvent& event);

  //void OnPreviousButton (wxCommandEvent& event);
  void OnNextButton (wxCommandEvent& event);
  void OnRunButton (wxCommandEvent& event);
  void OnStopButton (wxCommandEvent& event);
  void OnSwapButton (wxCommandEvent& event);
  void OnTimerEvent (wxTimerEvent& event);
};

main_frame* frame;

// IDs for the controls and the menu commands.
enum {
  // Menu items.
  exit_id = 1,
  open_video_id,
  //previous_button_id,
  // Sliders
  strength_slider_id,
  strength_slider_text_id,
  depth_slider_id,
  depth_slider_text_id,
  // Buttons.
  next_button_id,
  run_button_id,
  stop_button_id,
  swap_button_id,
  // Misc.
  run_timer_id,
  // It is important for the id corresponding to the "About" command to have
  // this standard value as otherwise it won't be handled properly under Mac
  // (where it is special and put into the "Apple" menu).
  about_id = wxID_ABOUT
};

// ----------------------------------------------------------------------------
// event tables and other macros for wxWindows
// ----------------------------------------------------------------------------

// the event tables connect the wxWindows events with the functions (event
// handlers) which process them.
BEGIN_EVENT_TABLE (main_frame, wxFrame)
EVT_MENU (open_video_id, main_frame::OnOpenVideo)
EVT_MENU (exit_id, main_frame::OnQuit)
EVT_MENU (about_id, main_frame::OnAbout)

EVT_SLIDER (strength_slider_id, main_frame::OnStrengthSlider)
EVT_SLIDER (depth_slider_id, main_frame::OnDepthSlider)

//EVT_BUTTON (previous_button_id, main_frame::OnPreviousButton)
EVT_BUTTON (next_button_id, main_frame::OnNextButton)
EVT_BUTTON (run_button_id, main_frame::OnRunButton)
EVT_BUTTON (stop_button_id, main_frame::OnStopButton)
EVT_BUTTON (swap_button_id, main_frame::OnSwapButton)

EVT_TIMER (run_timer_id, main_frame::OnTimerEvent)

END_EVENT_TABLE ()

// Create a new application object: this macro will allow wxWindows to create
// the application object during program execution.
IMPLEMENT_APP (app)

// Program entrypoint.
bool app::OnInit () {
  // Set current directory to where exe is and store it (current directory is a
  // global variable that should never be changed)
  char exe[MAX_PATH];
  GetModuleFileNameA (NULL, exe, MAX_PATH);
  fs::path exe_path (exe);
  SetCurrentDirectoryA (exe_path.branch_path ().native_directory_string ().c_str ());

  // switch from C locale to user's locale
  locale::global (locale ("")); // Will be used for all new streams, such as temp streams created by wformat ().
  wcout.imbue (locale ("")); // This stream was already created, so must imbue.

  // Set the standard precision for output of floats.
  wcout.precision (4);

  // Create a console window and redirect the standard output streams there.
  RedirectIOToConsole(); 

  // Create and show the main application window.
  frame = new main_frame (L"CUDA Overcomplete Wavelet Filter", wxPoint (-1, -1), wxSize (800, 600));
  // Frames, unlike simple controls, are not shown when created initially.
  frame->Show (TRUE);
  // Success: wxApp::OnRunButton () will be called which will enter the main message
  // loop and the application will run. If we returned FALSE here, the
  // application would exit immediately.
  return TRUE;
}

// Set up global accelerators.
int app::FilterEvent (wxEvent& event) {
  if (event.GetEventType () == wxEVT_KEY_DOWN) {
    //if ( ((wxKeyEvent&)event).GetKeyCode () == WXK_PAGEUP) {
    //  frame->OnPreviousButton ( (wxCommandEvent&) event);
    //  return true;
    //}
    if ( ((wxKeyEvent&)event).GetKeyCode () == WXK_PAGEDOWN) {
      frame->OnNextButton ( (wxCommandEvent&) event);
      return true;
    }
    if ( ((wxKeyEvent&)event).GetKeyCode () == WXK_RETURN) {
      frame->OnRunButton ( (wxCommandEvent&) event);
      return true;
    }
    if ( ((wxKeyEvent&)event).GetKeyCode () == WXK_ESCAPE) {
      frame->OnStopButton ( (wxCommandEvent&) event);
      return true;
    }
    if ( ((wxKeyEvent&)event).GetKeyCode () == WXK_SPACE) {
      frame->OnSwapButton ( (wxCommandEvent&) event);
      return true;
    }
  }
  return -1;
}

void app::OnFatalException() {
  // report the state during the last (fatal) exception
  //	GenerateDebugReport(wxDebugReport::Context_Exception);
}

// Frame constructor.
main_frame::main_frame (const wxString& title, const wxPoint& pos, const wxSize& size, long style)
: wxFrame (NULL, -1, title, pos, size, style), frame_idx (0)
{
  // set the frame icon
  SetIcon (wxICON (mondrian));

  // menu bar
  wxMenu *menuFile = new wxMenu;
  menuFile->Append (open_video_id, L"Open Video\tCtrl-O", L"Open a video file");
  menuFile->Append (exit_id, L"E&xit\tAlt-X", L"Quit this program");

  wxMenu *menuHelp = new wxMenu;
  menuHelp->Append (about_id, L"&About...\tF1", L"Show about dialog");

  wxMenuBar *menuBar = new wxMenuBar ();
  menuBar->Append (menuFile, L"&File");
  menuBar->Append (menuHelp, L"&Help");

  SetMenuBar (menuBar);

  // Create a vertical sizer.
  topsizer = new wxBoxSizer (wxVERTICAL);

  // video_frame_ctrl
  video_frame = new video_frame_ctrl ();
  video_frame->Create (this, -1, wxDefaultPosition, wxSize(800, 600));
  topsizer->Add (video_frame, 1, wxEXPAND);

  // sliders
  strength_slider = new wxSlider (this, strength_slider_id, 10, 0, 100);
  strength_slider_text = new wxStaticText (this, strength_slider_text_id, L"", wxDefaultPosition, wxSize(100, 20));
  depth_slider = new wxSlider (this, depth_slider_id, 1, 1, 10);
  depth_slider_text = new wxStaticText (this, depth_slider_text_id, L"", wxDefaultPosition, wxSize(100, 20));

  // Previous and Next buttons.
  //previous_button = new wxButton (this, previous_button_id, L"&Previous");
  next_button = new wxButton (this, next_button_id, L"Next");
  run_button = new wxButton (this, run_button_id, L"Run");
  stop_button = new wxButton (this, stop_button_id, L"Stop");
  swap_button = new wxButton (this, swap_button_id, L"Swap");

  wxBoxSizer* strength_slider_sizer = new wxBoxSizer (wxHORIZONTAL);
  strength_slider_sizer->Add (strength_slider, 1);
  strength_slider_sizer->Add (strength_slider_text, 0);
  topsizer->Add (strength_slider_sizer, 0, wxEXPAND | wxTOP | wxBOTTOM, 2);

  wxBoxSizer* depth_slider_sizer = new wxBoxSizer (wxHORIZONTAL);
  depth_slider_sizer->Add (depth_slider, 1);
  depth_slider_sizer->Add (depth_slider_text, 0);
  topsizer->Add (depth_slider_sizer, 0, wxEXPAND | wxTOP | wxBOTTOM, 2);

  wxBoxSizer* prev_next_button_sizer = new wxBoxSizer (wxHORIZONTAL);
  //prev_next_button_sizer->Add (previous_button, 0, wxLEFT | wxRIGHT, 2);
  prev_next_button_sizer->Add (next_button, 0, wxLEFT | wxRIGHT, 2);
  prev_next_button_sizer->Add (run_button, 0, wxLEFT | wxRIGHT, 2);
  prev_next_button_sizer->Add (stop_button, 0, wxLEFT | wxRIGHT, 2);
  prev_next_button_sizer->Add (swap_button, 0, wxLEFT | wxRIGHT, 2);
  topsizer->Add (prev_next_button_sizer, 0, wxEXPAND | wxTOP | wxBOTTOM, 2);

  SetSizer (topsizer);
  // give the sizer a minimal size
  //topsizer->SetMinSize (800, 800);
  // Tell the sizer to set (and Fit) the minimal size of the window to match the sizer's minimal size.
  //topsizer->SetSizeHints (this);

  SetBackgroundColour (wxColor (wxT ("WHITE")));

  run_timer = new wxTimer (this, run_timer_id);

  // Run automatically when called with video as argument.
  // We use this for running automatically from the profiler.
  if(wxTheApp->argc > 1) {
    if(wxTheApp->argc == 2) {
      wxString test_clip = wxTheApp->argv[2];
      wxMessageBox(test_clip);
      video_frame->open_video(test_clip.c_str());
      wxCommandEvent event;
      OnRunButton(event);
    }
    else {
      wxMessageBox(wxString().Format(L"Got %d args. Note: The profiler can not pass args with spaces.", wxTheApp->argc - 1));
    }
  }
}

// Event handlers.

void main_frame::OnOpenVideo (wxCommandEvent& event) {
  wxFileDialog d (this, L"Open video file", L"", L"", L"*", wxFD_OPEN);
  if (d.ShowModal () != wxID_OK) {
    return;
  }
  video_frame->open_video (d.GetPath ().c_str ());
}

void main_frame::OnQuit (wxCommandEvent& WXUNUSED (event)) {
  // TRUE is to force the frame to close.
  Close (TRUE);
}

void main_frame::OnAbout (wxCommandEvent& WXUNUSED (event)) {
  wxString msg;
  msg.Printf (L"CUDA Overcomplete Wavelet Filter - dahlsys.com\n\n%s", wxVERSION_STRING);
  wxMessageBox (msg, L"About", wxOK | wxICON_INFORMATION, this);
}

void main_frame::OnStrengthSlider (wxCommandEvent& event) {
  wxString s;
  s.Printf(L"%d", event.GetInt());
  strength_slider_text->SetLabel(s);
  video_frame->ow_param(depth_slider->GetValue(), event.GetInt());
}

void main_frame::OnDepthSlider (wxCommandEvent& event) {
  wxString s;
  s.Printf(L"%d", event.GetInt());
  depth_slider_text->SetLabel(s);
  video_frame->ow_param(event.GetInt(), strength_slider->GetValue());
}

//void main_frame::OnPreviousButton (wxCommandEvent& event) {
//  --frame_idx;
//  video_frame->set_frame_idx (frame_idx);
//}

void main_frame::OnNextButton (wxCommandEvent& event) {
  //++frame_idx;
  //video_frame->set_frame_idx (frame_idx);
  video_frame->next();
}

void main_frame::OnRunButton (wxCommandEvent& event) {
  run_timer->Start (10);
}

void main_frame::OnStopButton (wxCommandEvent& event) {
  run_timer->Stop ();
}

void main_frame::OnSwapButton (wxCommandEvent& event) {
  video_frame->swap();
}

void main_frame::OnTimerEvent (wxTimerEvent& event) {
  wxCommandEvent e;
  OnNextButton (e);
}
