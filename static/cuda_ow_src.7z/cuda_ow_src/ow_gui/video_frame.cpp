#include "pch.h"

#include "video_frame.h"
#include "util.h"
#include "..\ow_cuda\ow.h"

using namespace std;
using namespace boost;
using namespace boost::filesystem;

BEGIN_EVENT_TABLE (video_frame_ctrl, wxControl)
EVT_PAINT (video_frame_ctrl::OnPaint)
EVT_SIZE (video_frame_ctrl::OnSize)
EVT_ERASE_BACKGROUND (video_frame_ctrl::OnEraseBackground)
EVT_MOTION(video_frame_ctrl::OnMotion)
END_EVENT_TABLE ()

IMPLEMENT_DYNAMIC_CLASS (video_frame_ctrl, wxControl)


void ow(vector<u8>& rgb_filtered, vector<u8>& rgb, u64 w, u64 h, u32 depth, float strength) {
  vector<float>mono(w * h);
  for (int i = 0; i < 3; ++i) {
    for (int y = 0; y < h; ++y) {
      for (int x = 0; x < w; ++x) {
        mono[x + y * w] = static_cast<float>(rgb[(x * 3 + i) + y * w * 3]);
      }
    }
    gpu_ow_filter (&mono[0], w, h, depth, strength);
    for (int y = 0; y < h; ++y) {
      for (int x = 0; x < w; ++x) {
        rgb_filtered[(x * 3 + i) + y * w * 3] = static_cast<int>(mono[x + y * w]);
      }
    }
  }
}


video_frame_ctrl::video_frame_ctrl () : w_(0), h_ (0), filter(false), depth(1), strength(100.0)  {
	gpu_init (0);
	gpu_ow_init ();
}

video_frame_ctrl::~video_frame_ctrl () {
	gpu_ow_dinit ();
	gpu_dinit ();
}

bool video_frame_ctrl::Create (wxWindow *parent, wxWindowID id, const wxPoint& pos, const wxSize& size, const wxString& name) {
	if (!wxControl::Create (parent, id, pos, size,
		wxCLIP_CHILDREN | wxWANTS_CHARS,
		wxDefaultValidator, name))
	{
		return false;
	}

	SetBackgroundColour (*wxWHITE);
	SetFont (*wxSWISS_FONT);

	return true;
}

bool video_frame_ctrl::Destroy () {
	return wxControl::Destroy ();
}

void video_frame_ctrl::OnPaint (wxPaintEvent& event) {
	// Set up DC.
	wxPaintDC dc (this);

	dc.SetBackgroundMode (wxTRANSPARENT);
	dc.SetTextForeground (*wxWHITE);

  if (!rgb_frame.size()) {
  	dc.SetBackgroundMode (wxSOLID);
  	dc.SetTextForeground (*wxBLACK);
    dc.DrawRectangle(w_, 0, 10000, 10000);
    dc.DrawRectangle(0, h_, 10000, 10000);

  	wstring msg = L"Open a video file";
    int x, y;
    dc.GetTextExtent (msg.c_str (), &x, &y);
    dc.DrawText (msg.c_str (), GetClientSize ().x / 2 - x / 2, GetClientSize ().y - y);
    return;
  }

  if (filter) {
    vector<u8> rgb_filtered(w_ * h_ * 3);
    ow(rgb_filtered, rgb_frame, w_, h_, depth, strength);
	  wxImage disp_image (w_, h_, reinterpret_cast<unsigned char*> (&rgb_filtered[0]), true);
	  wxBitmap bmp (disp_image);
	  dc.DrawBitmap (bmp, 0, 0, true);
  	wstring msg = L"filtered";
    int x, y;
    dc.GetTextExtent (msg.c_str (), &x, &y);
    dc.DrawText (msg.c_str (), GetClientSize ().x / 2 - x / 2, GetClientSize ().y - y);
  }
  else {
  	wxImage disp_image (w_, h_, reinterpret_cast<unsigned char*> (&rgb_frame[0]), true);
	  wxBitmap bmp (disp_image);
	  dc.DrawBitmap (bmp, 0, 0, true);
  	wstring msg = L"unfiltered";
    int x, y;
    dc.GetTextExtent (msg.c_str (), &x, &y);
    dc.DrawText (msg.c_str (), GetClientSize ().x / 2 - x / 2, GetClientSize ().y - y);
  }
  // Clear unused area.
  //wxSize s = this->GetParent()->GetClientSize();
  //printf("%d\t%d\n", s.GetHeight(), s.GetWidth());
  dc.DrawRectangle(w_, 0, 10000, 10000);
  dc.DrawRectangle(0, h_, 10000, 10000);

}

void video_frame_ctrl::OnSize (wxSizeEvent& event) {
	Layout ();
}

void video_frame_ctrl::OnEraseBackground (wxEraseEvent& event) {
}

void video_frame_ctrl::OnMotion (wxMouseEvent& event) {
}

void video_frame_ctrl::open_video (wpath video_path) {
  // Close is silently ignored if there's nothing to close.
  ff.close();

	video_path_ = video_path;
  wstring ws = video_path.file_string();
  //string s(ws.begin(), ws.end());
  if (!ff.open_video(ws)) {
    wxMessageBox(wxString().Format(L"Could not open: %s", video_path.string().c_str()));
    return;
  }

  ff.get_dim(w_, h_);

  rgb_frame.resize(w_ * h_ * 3);

  ff.next(&rgb_frame[0]);

	frame_idx_ = 0;

  this->SetMinSize(wxSize(w_, h_));

  Refresh ();
}

void video_frame_ctrl::set_frame_idx (u64 idx) {
	frame_idx_ = idx;
	Refresh ();
}

void video_frame_ctrl::next() {
  if (!rgb_frame.size()) {
    return;
  }
  ff.next(&rgb_frame[0]);
  Refresh();
}

void video_frame_ctrl::swap() {
  filter = !filter;
  Refresh();
}

void video_frame_ctrl::ow_param(int depth, float strength) {
  video_frame_ctrl::depth = depth;
  video_frame_ctrl::strength = strength;
  Refresh();
}
