// app
#include "../../lib/int_types.h"

#define WINDOWS_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>

// std
#include <string>
#include <fstream>
#include <iostream>

// boost::filesystem
#include <boost/filesystem/operations.hpp>
#include <boost/filesystem/fstream.hpp>
#include <boost/filesystem/exception.hpp>

// boost::format
#include <boost/format.hpp>

// OpenGL
#include <GL/glew.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <GL/glext.h>

// CUDA.
#include <cuda_runtime.h>
#include <cutil_inline.h>
#include <cutil_gl_inline.h>
#include <cuda_gl_interop.h>
#include <vector_types.h>

