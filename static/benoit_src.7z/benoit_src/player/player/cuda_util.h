#pragma once

void GLDeviceInit(s32 device);
