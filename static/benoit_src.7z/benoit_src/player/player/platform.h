#pragma once

int GetDisplayRefreshRate();

