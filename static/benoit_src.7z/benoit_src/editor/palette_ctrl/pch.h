#pragma once
#pragma message("Compiling PCH - Should only happen once per project")

//#define _CRT_SECURE_NO_WARNINGS

// XMM support for Visual Studio.
#include <xmmintrin.h>

// wx
#include <wx/msw/setup.h>
#include <wx/wxprec.h>
#include <wx/control.h>         // the base class
#include <wx/dcclient.h>        // for wxPaintDC

// std
#include <vector>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <cmath>
#include <list>

// Boost.
//#define BOOST_LIB_DIAGNOSTIC
#include <boost/thread.hpp>
#include <boost/timer.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/random/mersenne_twister.hpp>
#include <boost/random/linear_congruential.hpp>
#include <boost/random/uniform_real.hpp>
#include <boost/random/variate_generator.hpp>
#include <boost/format.hpp>

// OpenMP.
#include <omp.h>

// CUDA.
//#include <cuda_runtime.h>
#include <cutil.h>

#include <cutil.h>
#include <cutil_math.h>
#include <cutil_inline_runtime.h>
