#pragma once

#pragma message("Compiling PCH - Should only happen once per project")

// wx
#include "wx/msw/setup.h"
#include "wx/wxprec.h"
#include "wx/slider.h"
#include "wx/image.h"
#include "wx/control.h"         // the base class
#include "wx/dcclient.h"        // for wxPaintDC
#include "wx/artprov.h"

// std
#include <list>
#include <sstream>
#include <fstream>

// boost
#include <boost/lexical_cast.hpp>
#include <boost/format.hpp>
